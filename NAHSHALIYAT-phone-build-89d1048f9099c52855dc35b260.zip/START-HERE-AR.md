# ابدأ من هنا — بناء NAHSHALIYAT من الهاتف

## الملفات المطلوبة بالضبط

ارفع محتويات مجلد `source/` كاملة إلى مستودع GitHub جديد أو إلى مستودع التطبيق الحالي. لا تغيّر المسارات.

الملف الأهم للبناء موجود هنا بالضبط:

```text
source/.github/workflows/android-apk.yml
```

## خطوات الهاتف

1. فك ضغط الحزمة.
2. افتح مستودع GitHub.
3. ارفع محتويات `source/` إلى جذر المستودع، وليس مجلدًا داخليًا.
4. افتح تبويب Actions.
5. اختر `Build Android APK`.
6. اضغط `Run workflow`.
7. بعد نجاح البناء افتح `Artifacts` ونزّل `nahshaliyat-debug-apk`.
8. فك ضغط Artifact وثبّت `app-debug.apk` على الهاتف.

## لا تغيّر هذه الملفات

- `app.config.ts`
- `package.json`
- `pnpm-lock.yaml`
- `.github/workflows/android-apk.yml`

معرّف Android في المشروع هو `nahshaliyat.app`.

هذا Workflow يبني APK تجريبيًا للتثبيت والاختبار. ملف Google Play AAB يحتاج إعداد توقيع إصدار دائم منفصل.
