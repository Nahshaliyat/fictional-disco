import AsyncStorage from "@react-native-async-storage/async-storage";

export type WatchedVideo = { id: string; title: string; meta: string; tag: string; watchedAt: number };
const KEY = "nahshaliyat_watch_history_v1";
const LIMIT = 30;

export async function rememberWatchedVideo(video: Omit<WatchedVideo, "watchedAt">) {
  try {
    const current = await readWatchHistory();
    const next = [{ ...video, watchedAt: Date.now() }, ...current.filter((item) => item.id !== video.id)].slice(0, LIMIT);
    await AsyncStorage.setItem(KEY, JSON.stringify(next));
  } catch { /* local history is best effort */ }
}

export async function readWatchHistory(): Promise<WatchedVideo[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((item) => item && typeof item.id === "string") : [];
  } catch { return []; }
}

export async function clearWatchHistory() {
  await AsyncStorage.removeItem(KEY);
}
