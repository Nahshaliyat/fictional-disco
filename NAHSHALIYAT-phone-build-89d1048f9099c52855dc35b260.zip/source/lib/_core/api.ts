import { Platform } from "react-native";
import { getApiBaseUrl } from "@/constants/oauth";
import * as Auth from "./auth";

type ApiResponse<T> = {
  data?: T;
  error?: string;
};

export async function apiCall<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...((options.headers as Record<string, string>) || {}),
  };

  // Determine the auth method:
  // - Native platform: use stored session token as Bearer auth
  // - Web (including iframe): use cookie-based auth (browser handles automatically)
  //   Cookie is set on backend domain via POST /api/auth/session after receiving token via postMessage
  if (Platform.OS !== "web") {
    const sessionToken = await Auth.getSessionToken();
    if (sessionToken) {
      headers["Authorization"] = `Bearer ${sessionToken}`;
    }
  } else {
  }

  const baseUrl = getApiBaseUrl();
  // Ensure no double slashes between baseUrl and endpoint
  const cleanBaseUrl = baseUrl.endsWith("/") ? baseUrl.slice(0, -1) : baseUrl;
  const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
  const url = baseUrl ? `${cleanBaseUrl}${cleanEndpoint}` : endpoint;
  try {
    const response = await fetch(url, {
      ...options,
      headers,
      credentials: "include",
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorMessage = errorText;
      try {
        const errorJson = JSON.parse(errorText);
        errorMessage = errorJson.error || errorJson.message || errorText;
      } catch {
        // Not JSON, use text as is
      }
      throw new Error(errorMessage || `API call failed: ${response.statusText}`);
    }

    const contentType = response.headers.get("content-type");
    if (contentType && contentType.includes("application/json")) {
      const data = await response.json();
      return data as T;
    }

    const text = await response.text();
    return (text ? JSON.parse(text) : {}) as T;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error("Unknown error occurred");
  }
}

// OAuth callback handler - exchange code for session token
// Calls /api/oauth/mobile endpoint which returns JSON with app_session_id and user
export async function exchangeOAuthCode(
  code: string,
  state: string,
): Promise<{ sessionToken: string; user: any }> {
  // Use GET with query params
  const params = new URLSearchParams({ code, state });
  const endpoint = `/api/oauth/mobile?${params.toString()}`;
  const result = await apiCall<{ app_session_id: string; user: any }>(endpoint);

  // Convert app_session_id to sessionToken for compatibility
  const sessionToken = result.app_session_id;

  return {
    sessionToken,
    user: result.user,
  };
}

// Logout
export async function logout(): Promise<void> {
  await Promise.allSettled([
    apiCall<void>("/api/auth/logout", { method: "POST" }),
    apiCall<void>("/api/auth/password-logout", { method: "POST" }),
  ]);
}

// Get current authenticated user (web uses cookie-based auth)
export async function getMe(): Promise<{
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  phone: string | null;
  avatarUrl: string | null;
  loginMethod: string | null;
  role: "user" | "admin";
  lastSignedIn: string;
} | null> {
  try {
    const result = await apiCall<{ user: any }>("/api/auth/me");
    return result.user || null;
  } catch {
    return null;
  }
}

// Establish session cookie on the backend (3000-xxx domain)
// Called after receiving token via postMessage to get a proper Set-Cookie from the backend
export async function establishSession(token: string): Promise<boolean> {
  try {
    const baseUrl = getApiBaseUrl();
    const url = `${baseUrl}/api/auth/session`;

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      credentials: "include", // Important: allows Set-Cookie to be stored
    });

    if (!response.ok) {
      return false;
    }

    return true;
  } catch {
    return false;
  }
}

export async function getHealthStatus(): Promise<{ ok: boolean; service?: string; timestamp?: string }> {
  return apiCall<{ ok: boolean; service?: string; timestamp?: string }>("/api/health");
}

export type EmailAuthResult = {
  sessionToken: string;
  user: {
    id: number;
    openId: string;
    name: string | null;
    email: string | null;
    phone: string | null;
    loginMethod: string | null;
    role: "user" | "admin";
    lastSignedIn: string;
  };
};

export function loginWithEmail(email: string, password: string, phone?: string, rememberMe = true) {
  return apiCall<EmailAuthResult>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, phone, password, rememberMe }),
  });
}

export function registerWithEmail(name: string, email: string, password: string, phone?: string, rememberMe = true) {
  return apiCall<EmailAuthResult>("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({ name, email, phone, password, rememberMe }),
  });
}

export function createServiceRequest(payload: { name: string; requestType: string; details: string; phone: string; email: string }) {
  return apiCall<{ requestNumber: string }>("/api/service-requests", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function getMyServiceRequests() {
  return apiCall<{ requests: Array<{ id: number; requestNumber: string; name: string; requestType: string; details: string; phone: string; email: string; status: "new" | "reviewing" | "contacted" | "completed"; createdAt: string }> }>("/api/service-requests/mine");
}

export function createFavorite(payload: { videoId: string; title: string; meta?: string; tag?: string }) {
  return apiCall<{ success: boolean }>("/api/favorites", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function removeFavorite(videoId: string) {
  return apiCall<{ success: boolean }>(`/api/favorites/${encodeURIComponent(videoId)}`, { method: "DELETE" });
}

export async function getFavorites() {
  return apiCall<{ favorites: Array<{ videoId: string; title: string; meta: string | null; tag: string | null }> }>("/api/favorites");
}

export async function getAdminRequests() {
  return apiCall<{ requests: Array<{ id: number; requestNumber: string; name: string; requestType: string; details: string; phone: string; email: string; status: "new" | "reviewing" | "contacted" | "completed"; createdAt: string }> }>("/api/admin/requests");
}
export async function updateAdminRequestStatus(id: number, status: "new" | "reviewing" | "contacted" | "completed") { return apiCall<{ success: boolean }>(`/api/admin/requests/${id}/status`, { method: "PUT", body: JSON.stringify({ status }) }); }
export async function deleteAdminRequest(id: number) { return apiCall<{ success: boolean }>(`/api/admin/requests/${id}`, { method: "DELETE" }); }

export type AdminUserRecord = { id: number; name: string | null; email: string | null; phone: string | null; role: "user" | "admin"; loginMethod: string | null; createdAt: string; lastSignedIn: string };
export async function getAdminUsers() { return apiCall<{ users: AdminUserRecord[] }>("/api/admin/users"); }
export async function updateProfileAvatar(avatarUrl: string) { return apiCall<{ success: boolean; avatarUrl: string }>("/api/profile/avatar", { method: "PUT", body: JSON.stringify({ avatarUrl }) }); }
export async function updateAdminUserRole(id: number, role: "user" | "admin") { return apiCall<{ success: boolean }>(`/api/admin/users/${id}/role`, { method: "PUT", body: JSON.stringify({ role }) }); }
export async function getAdminContent() { return apiCall<{ books: BookRecord[]; pens: PenPostRecord[]; messages: CouncilMessageRecord[]; reports: Array<{ report: { id: number; messageId: number; reporterId: number; reason: string; createdAt: string }; reporterName: string | null; reporterEmail: string | null }> }>("/api/admin/content"); }
export type AdminAuditLog = { log: { id: number; action: string; entityType: string; entityId: string | null; details: string | null; createdAt: string }; actorName: string | null; actorEmail: string | null };
export async function getAdminAuditLogs() { return apiCall<{ logs: AdminAuditLog[] }>("/api/admin/audit-logs"); }

export type BookRecord = { id: number; title: string; author: string | null; content: string; sourceUrl: string | null; coverUrl: string | null; fileKey: string | null; mimeType: string | null; fileSize: number | null; uploadedBy: number; createdAt: string; updatedAt: string };
export type PenPostRecord = { post: { id: number; userId: number; body: string; editCount: number; createdAt: string; updatedAt: string }; userName: string | null; userEmail: string | null };
export type CouncilMessageRecord = { message: { id: number; senderId: number; recipientId: number | null; body: string; createdAt: string; updatedAt: string }; userName: string | null; userEmail: string | null };

export async function getBooks() { return apiCall<{ books: BookRecord[] }>("/api/books"); }
export async function createBook(payload: { title: string; author?: string; content: string; sourceUrl?: string; coverUrl?: string; fileKey?: string; mimeType?: string; fileSize?: number }) { return apiCall<{ book: BookRecord }>("/api/books", { method: "POST", body: JSON.stringify(payload) }); }
export async function updateBook(id: number, payload: { title: string; author?: string; content: string; sourceUrl?: string; coverUrl?: string; fileKey?: string; mimeType?: string; fileSize?: number }) { return apiCall<{ success: boolean }>(`/api/books/${id}`, { method: "PUT", body: JSON.stringify(payload) }); }
export async function deleteBook(id: number) { return apiCall<{ success: boolean }>(`/api/books/${id}`, { method: "DELETE" }); }
export async function getPens() { return apiCall<{ posts: PenPostRecord[] }>("/api/pens"); }
export async function createPen(body: string) { return apiCall<{ success: boolean }>("/api/pens", { method: "POST", body: JSON.stringify({ body }) }); }
export async function updatePen(id: number, body: string) { return apiCall<{ success: boolean }>(`/api/pens/${id}`, { method: "PUT", body: JSON.stringify({ body }) }); }
export async function deletePen(id: number) { return apiCall<{ success: boolean }>(`/api/pens/${id}`, { method: "DELETE" }); }
export async function getCouncilMembers() { return apiCall<{ members: Array<{ id: number; name: string | null; email: string | null; role: "user" | "admin" }> }>("/api/council/members"); }
export async function getCouncilMessages() { return apiCall<{ messages: CouncilMessageRecord[] }>("/api/council/messages"); }
export async function sendCouncilMessage(body: string, recipientId?: number) { return apiCall<{ success: boolean }>("/api/council/messages", { method: "POST", body: JSON.stringify({ body, recipientId }) }); }
export async function deleteCouncilMessage(id: number) { return apiCall<{ success: boolean }>(`/api/council/messages/${id}`, { method: "DELETE" }); }
export async function updateCouncilMessage(id: number, body: string) { return apiCall<{ success: boolean }>(`/api/council/messages/${id}`, { method: "PUT", body: JSON.stringify({ body }) }); }
export async function reportCouncilMessage(messageId: number, reason: string) { return apiCall<{ success: boolean }>("/api/council/reports", { method: "POST", body: JSON.stringify({ messageId, reason }) }); }
export async function blockCouncilUser(userId: number) { return apiCall<{ success: boolean }>("/api/council/blocks", { method: "POST", body: JSON.stringify({ userId }) }); }
export async function getExternalServiceStatus() { return apiCall<{ providers: Record<string, boolean> }>("/api/auth/providers"); }
export async function startExternalOAuth(provider: "google" | "microsoft" | "facebook", origin?: string) { return apiCall<{ url: string }>(`/api/auth/oauth/${provider}/start?origin=${encodeURIComponent(origin || "")}`); }
export async function requestPhoneCode(phone: string) { return apiCall<{ success: boolean; expiresInSeconds: number }>("/api/auth/phone/request-code", { method: "POST", body: JSON.stringify({ phone }) }); }
export async function verifyPhoneCode(phone: string, code: string) { return apiCall<{ verified: boolean; phone: string }>("/api/auth/phone/verify-code", { method: "POST", body: JSON.stringify({ phone, code }) }); }
export async function listReminders() { return apiCall<{ reminders: Array<{ id: number; title: string; remindAt: string }> }>("/api/reminders"); }
export async function createReminder(title: string, remindAt: string) { return apiCall<{ reminder: { id: number; title: string; remindAt: string } }>("/api/reminders", { method: "POST", body: JSON.stringify({ title, remindAt }) }); }

export async function getCouncilSocketUrl() {
  const token = await Auth.getSessionToken();
  const base = getApiBaseUrl().replace(/^http/, "ws");
  return `${base}/ws/council?token=${encodeURIComponent(token || "")}`;
}
export async function getSyncedYouTubePlaylists() { return apiCall<{ playlists: Array<{ playlistId: string; title: string; thumbnailUrl: string | null; itemCount: number }>; liveSyncConfigured: boolean }>("/api/youtube/playlists"); }
export async function getYouTubePlaylistVideos(playlistId: string) { return apiCall<{ videos: Array<{ id: string; title: string; meta: string; tag: string }> }>(`/api/youtube/playlists/${encodeURIComponent(playlistId)}/videos`); }

export type AssistantTurn = { role: "user" | "assistant"; content: string };

export function askNahshaliyat(question: string) {
  return apiCall<{ answer: string; inScope: boolean }>("/api/ask-me", {
    method: "POST",
    body: JSON.stringify({ question }),
  });
}

export type AskMeRecord = { id: number; userId: number; question: string; answer: string; inScope: number; createdAt: string };
export type PrivateThread = { memberId: number; memberName: string | null; lastId: number };
export type SponsorMessageRecord = { id: number; memberId: number; senderId: number; body: string; createdAt: string };

export function getAskMeHistory() {
  return apiCall<{ messages: AskMeRecord[] }>("/api/ask-me/history");
}
export function getAdminAskMeThreads() {
  return apiCall<{ threads: PrivateThread[] }>("/api/admin/ask-me/threads");
}
export function getAdminAskMeHistory(memberId: number) {
  return apiCall<{ messages: AskMeRecord[] }>(`/api/admin/ask-me/history/${memberId}`);
}
export function getSponsorThreads() {
  return apiCall<{ threads: PrivateThread[] }>("/api/council/sponsor/threads");
}
export function getSponsorMessages(memberId?: number) {
  return apiCall<{ messages: SponsorMessageRecord[] }>(`/api/council/sponsor/messages${memberId ? `?memberId=${memberId}` : ""}`);
}
export function sendSponsorMessage(body: string, memberId?: number) {
  return apiCall<{ success: boolean }>("/api/council/sponsor/messages", {
    method: "POST",
    body: JSON.stringify({ body, memberId }),
  });
}
