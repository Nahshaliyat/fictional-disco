import AsyncStorage from "@react-native-async-storage/async-storage";
import { Linking } from "react-native";

import { CHANNEL_URL } from "@/constants/nahshaliyat";

export type CachedVideo = { id: string; title: string; meta: string; tag: string };
export type PlaylistCache = { savedAt: number; videos: CachedVideo[] };
const CACHE_PREFIX = "nahshaliyat_youtube_cache_v2_";
export const YOUTUBE_CACHE_TTL = 5 * 60 * 1000;

export function normalizeVideoId(value: string) {
  const trimmed = value.trim();
  const match = trimmed.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([^?&#/]+)/i);
  return (match?.[1] || trimmed).replace(/[^A-Za-z0-9_-]/g, "").slice(0, 32);
}
export function getVideoUrl(videoId: string) { return `https://www.youtube.com/watch?v=${encodeURIComponent(normalizeVideoId(videoId))}`; }
export function getVideoThumbnail(videoId: string) { return `https://i.ytimg.com/vi/${encodeURIComponent(normalizeVideoId(videoId))}/hqdefault.jpg`; }
export function getPlaylistUrl(playlistId: string) { return `https://www.youtube.com/playlist?list=${playlistId}`; }
export function openYouTube(url: string) { void Linking.openURL(url); }
export function openChannel() { openYouTube(CHANNEL_URL); }

export async function readCachedPlaylistVideos(playlistId: string): Promise<CachedVideo[]> {
  try {
    const raw = await AsyncStorage.getItem(`${CACHE_PREFIX}${playlistId}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Partial<PlaylistCache>;
    return Array.isArray(parsed.videos) ? parsed.videos : [];
  } catch { return []; }
}

export async function readPlaylistCache(playlistId: string): Promise<PlaylistCache | null> {
  try {
    const raw = await AsyncStorage.getItem(`${CACHE_PREFIX}${playlistId}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<PlaylistCache>;
    if (!Array.isArray(parsed.videos) || typeof parsed.savedAt !== "number") return null;
    return { savedAt: parsed.savedAt, videos: parsed.videos };
  } catch { return null; }
}

export function isPlaylistCacheFresh(cache: PlaylistCache | null, now = Date.now()) {
  return Boolean(cache && now - cache.savedAt < YOUTUBE_CACHE_TTL);
}

export async function cachePlaylistVideos(playlistId: string, videos: CachedVideo[]) {
  try {
    const unique = videos.filter((video, index, all) => video.id && all.findIndex((candidate) => candidate.id === video.id) === index);
    await AsyncStorage.setItem(`${CACHE_PREFIX}${playlistId}`, JSON.stringify({ savedAt: Date.now(), videos: unique } satisfies PlaylistCache));
  } catch { /* cache is best effort */ }
}
