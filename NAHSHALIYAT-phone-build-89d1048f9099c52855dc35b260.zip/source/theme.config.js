/** @type {const} */
const themeColors = {
  primary: { light: '#A95E3F', dark: '#D58B6C' },
  background: { light: '#F5F0E7', dark: '#1F1D1A' },
  surface: { light: '#FFFDF8', dark: '#2A2723' },
  foreground: { light: '#24221F', dark: '#F5F0E7' },
  muted: { light: '#777066', dark: '#B9AEA1' },
  border: { light: '#DED5CA', dark: '#4B433B' },
  success: { light: '#65715C', dark: '#AAB79A' },
  warning: { light: '#A95E3F', dark: '#D58B6C' },
  error: { light: '#A94B42', dark: '#E08C7C' },
};

module.exports = { themeColors };
