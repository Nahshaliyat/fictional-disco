import "@/global.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { router, Stack, usePathname } from "expo-router";
import * as Notifications from "expo-notifications";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useState } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import "react-native-reanimated";
import { Platform, Pressable, Text, View } from "react-native";
import "@/lib/_core/nativewind-pressable";
import { ThemeProvider } from "@/lib/theme-provider";
import { SafeAreaFrameContext, SafeAreaInsetsContext, SafeAreaProvider, SafeAreaView, useSafeAreaInsets, initialWindowMetrics } from "react-native-safe-area-context";
import type { EdgeInsets, Metrics, Rect } from "react-native-safe-area-context";

import { trpc, createTRPCClient } from "@/lib/trpc";
import { initManusRuntime, subscribeSafeAreaInsets } from "@/lib/_core/manus-runtime";
import { useAuth } from "@/hooks/use-auth";
import { AuthScreen } from "@/components/nahshaliyat/auth-screen";
import { BrandMark } from "@/components/nahshaliyat/brand-mark";
import { SectionStrip } from "@/components/nahshaliyat/section-strip";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { ConnectionStatus } from "@/components/nahshaliyat/connection-status";
import { COLORS, type TopSectionId } from "@/constants/nahshaliyat";

Notifications.setNotificationHandler({ handleNotification: async () => ({ shouldPlaySound: true, shouldSetBadge: true, shouldShowBanner: true, shouldShowList: true }) });

const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };
export const unstable_settings = { anchor: "(tabs)" };

export default function RootLayout() {
  const pathname = usePathname();
  const auth = useAuth();
  const initialInsets = initialWindowMetrics?.insets ?? DEFAULT_WEB_INSETS;
  const initialFrame = initialWindowMetrics?.frame ?? DEFAULT_WEB_FRAME;
  const [insets, setInsets] = useState<EdgeInsets>(initialInsets);
  const [frame, setFrame] = useState<Rect>(initialFrame);

  useEffect(() => { initManusRuntime(); }, []);
  const handleSafeAreaUpdate = useCallback((metrics: Metrics) => { setInsets(metrics.insets); setFrame(metrics.frame); }, []);
  useEffect(() => { if (Platform.OS !== "web") return; return subscribeSafeAreaInsets(handleSafeAreaUpdate); }, [handleSafeAreaUpdate]);
  const [queryClient] = useState(() => new QueryClient({ defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } } }));
  const [trpcClient] = useState(() => createTRPCClient());
  const providerInitialMetrics = useMemo(() => { const metrics = initialWindowMetrics ?? { insets: initialInsets, frame: initialFrame }; return { ...metrics, insets: { ...metrics.insets, top: Math.max(metrics.insets.top, 16), bottom: Math.max(metrics.insets.bottom, 12) } }; }, [initialInsets, initialFrame]);

  const content = <GestureHandlerRootView style={{ flex: 1 }}><trpc.Provider client={trpcClient} queryClient={queryClient}><QueryClientProvider client={queryClient}>
    <TopNavigation pathname={pathname} />
    <View style={{ flex: 1 }}><Stack screenOptions={{ headerShown: false }}><Stack.Screen name="(tabs)" /><Stack.Screen name="oauth/callback" /><Stack.Screen name="admin" /><Stack.Screen name="admin-ask-me" /><Stack.Screen name="profile" /><Stack.Screen name="settings" /><Stack.Screen name="search" /><Stack.Screen name="activity" /><Stack.Screen name="notifications" /><Stack.Screen name="video/[videoId]" /></Stack></View>
    <BottomNavigation pathname={pathname} />
    <StatusBar style="dark" />
  </QueryClientProvider></trpc.Provider></GestureHandlerRootView>;

  if (auth.loading && !pathname.includes("/oauth/callback")) return <SafeAreaProvider initialMetrics={providerInitialMetrics}><SafeAreaView edges={["top", "bottom"]} style={styles.authSafeArea}><View style={styles.loading}><IconSymbol name="auto-awesome" size={25} color={COLORS.copper} /><Text style={styles.loadingText}>نرتّب لك مساحة نهشليات...</Text></View></SafeAreaView></SafeAreaProvider>;
  if (!auth.user && !pathname.includes("/oauth/callback")) return <SafeAreaProvider initialMetrics={providerInitialMetrics}><SafeAreaView edges={["top", "bottom"]} style={styles.authSafeArea}><AuthScreen onSuccess={auth.refresh} /></SafeAreaView></SafeAreaProvider>;
  const shouldOverrideSafeArea = Platform.OS === "web";
  return <ThemeProvider><SafeAreaProvider initialMetrics={providerInitialMetrics}>{shouldOverrideSafeArea ? <SafeAreaFrameContext.Provider value={frame}><SafeAreaInsetsContext.Provider value={insets}>{content}</SafeAreaInsetsContext.Provider></SafeAreaFrameContext.Provider> : content}</SafeAreaProvider></ThemeProvider>;
}

function TopNavigation({ pathname }: { pathname: string }) {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const topInset = Math.max(insets.top, 22);
  const activeId: TopSectionId = pathname.includes("diary") ? "diary" : pathname.includes("services") ? "services" : "hena";
  return <View style={[styles.top, { paddingTop: topInset }]}><View style={styles.topRow}><BrandMark compact /><View style={styles.topActions}><Pressable accessibilityLabel="الإشعارات" onPress={() => router.push("/notifications")} style={({ pressed }) => [styles.profileButton, pressed && styles.pressed]}><IconSymbol name="notifications" size={20} color={COLORS.copper} /></Pressable><Pressable accessibilityLabel="بحث" onPress={() => router.push("/search")} style={({ pressed }) => [styles.profileButton, pressed && styles.pressed]}><IconSymbol name="search" size={20} color={COLORS.copper} /></Pressable>{user?.role === "admin" ? <Pressable onPress={() => router.push("/admin")} style={({ pressed }) => [styles.adminButton, pressed && styles.pressed]}><IconSymbol name="admin-panel-settings" size={17} color={COLORS.white} /><Text style={styles.adminText}>إدارة</Text></Pressable> : null}<Pressable accessibilityLabel="ملف العضو" onPress={() => router.push("/profile")} style={({ pressed }) => [styles.profileButton, pressed && styles.pressed]}><IconSymbol name="person" size={20} color={COLORS.copper} /></Pressable></View></View><ConnectionStatus /><SectionStrip activeId={activeId} onSelect={(id) => router.replace({ pathname: "/sections/[section]", params: { section: id, key: `${id}-${Date.now()}` } })} /></View>;
}

function BottomNavigation({ pathname }: { pathname: string }) {
  const insets = useSafeAreaInsets();
  const tabs = [
    { path: "/", label: "الرئيسية", icon: "house.fill" as const },
    { path: "/library", label: "المكتبة", icon: "bookshelf" as const },
    { path: "/pens", label: "أقلام", icon: "edit" as const },
    { path: "/council", label: "المجلس", icon: "forum" as const },
    { path: "/ask-me", label: "اسألني", icon: "auto-awesome" as const },
  ];
  const activePath = pathname.includes("/ask-me") ? "/ask-me" : pathname.includes("/library") ? "/library" : pathname.includes("/pens") ? "/pens" : pathname.includes("/council") ? "/council" : "/";
  const bottomInset = Math.max(insets.bottom, 20);
  const activeColor = activePath === "/library" || activePath === "/council" ? COLORS.midnight : COLORS.copper;
  return <View style={[styles.bottom, { paddingBottom: bottomInset }]}><View style={styles.bottomInner}>{tabs.map((tab) => { const active = activePath === tab.path; return <Pressable key={tab.path} onPress={() => router.push(tab.path as "/")} style={({ pressed }) => [styles.tab, pressed && styles.pressed]}><View style={[styles.tabIcon, active && { backgroundColor: activeColor }]}><IconSymbol color={active ? COLORS.white : COLORS.mutedInk} name={tab.icon} size={19} /></View><Text style={[styles.tabLabel, active && { color: activeColor }]}>{tab.label}</Text>{active ? <View style={[styles.tabMarker, { backgroundColor: activeColor }]} /> : null}</Pressable>; })}</View></View>;
}

const styles = {
  authSafeArea: { backgroundColor: COLORS.paper, flex: 1 } as const,
  loading: { alignItems: "center", backgroundColor: COLORS.paper, flex: 1, gap: 10, justifyContent: "center" } as const,
  loadingText: { color: COLORS.mutedInk, fontSize: 12 } as const,
  top: { backgroundColor: COLORS.paper, borderBottomColor: COLORS.line, borderBottomWidth: 1 } as const,
  topRow: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between", paddingHorizontal: 16, paddingTop: 4 } as const,
  topActions: { alignItems: "center", flexDirection: "row-reverse", gap: 7 } as const,
  adminButton: { alignItems: "center", backgroundColor: COLORS.ink, borderRadius: 12, flexDirection: "row-reverse", gap: 5, paddingHorizontal: 9, paddingVertical: 7 } as const,
  adminText: { color: COLORS.white, fontSize: 9, fontWeight: "900" } as const,
  profileButton: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, height: 34, justifyContent: "center", width: 34 } as const,
  bottom: { backgroundColor: COLORS.white, borderTopColor: COLORS.line, borderTopWidth: 1, paddingHorizontal: 8, paddingTop: 7 } as const,
  bottomInner: { alignItems: "stretch", flexDirection: "row-reverse", justifyContent: "space-around" } as const,
  tab: { alignItems: "center", flex: 1, justifyContent: "center", minHeight: 49, position: "relative" } as const,
  tabIcon: { alignItems: "center", borderRadius: 12, height: 28, justifyContent: "center", width: 34 } as const,
  tabIconActive: { backgroundColor: COLORS.copper } as const,
  tabLabel: { color: COLORS.mutedInk, fontSize: 9, fontWeight: "800", marginTop: 3 } as const,
  tabLabelActive: { color: COLORS.copper } as const,
  tabMarker: { backgroundColor: COLORS.copper, borderRadius: 2, bottom: 0, height: 3, position: "absolute", width: 18 } as const,
  pressed: { opacity: 0.75, transform: [{ scale: 0.97 }] } as const,
};
