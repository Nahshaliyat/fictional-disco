import { router, useLocalSearchParams } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { COLORS, playlists } from "@/constants/nahshaliyat";
import { ScreenContainer } from "@/components/screen-container";
import { YouTubePlayer } from "@/components/nahshaliyat/youtube-player";

export default function PlaylistScreen() {
  const { playlistId } = useLocalSearchParams<{ playlistId?: string }>();
  const playlist = playlists.find((item) => item.playlistId === playlistId) || playlists[0];
  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><View style={styles.content}><View style={styles.header}><Pressable onPress={() => router.back()}><Text style={styles.back}>→ رجوع</Text></Pressable><Text style={styles.kicker}>قائمة نهشليات</Text></View><Text style={styles.title}>{playlist.title}</Text><Text style={styles.count}>{playlist.countLabel}</Text><View style={styles.player}><YouTubePlayer videoId={playlist.featuredVideoId} title={playlist.title} /></View><Text style={styles.hint}>تظهر مقاطع القائمة هنا ويمكن تشغيلها داخل التطبيق.</Text></View></ScreenContainer>;
}

const styles = StyleSheet.create({
  content: { backgroundColor: COLORS.paper, flex: 1, padding: 18 },
  header: { alignItems: "center", flexDirection: "row", justifyContent: "space-between", paddingTop: 8 },
  back: { color: COLORS.copper, fontSize: 12, fontWeight: "800" },
  kicker: { color: COLORS.copper, fontSize: 11, fontWeight: "800" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 28, fontWeight: "800", marginTop: 24, textAlign: "right" },
  count: { color: COLORS.mutedInk, fontSize: 11, marginTop: 6, textAlign: "right" },
  player: { backgroundColor: "#000", borderRadius: 18, flex: 1, marginTop: 18, minHeight: 360, overflow: "hidden" },
  hint: { color: COLORS.mutedInk, fontSize: 11, marginTop: 12, textAlign: "right" },
});
