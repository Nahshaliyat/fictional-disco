import { router } from "expo-router";
import { ScrollView, Pressable, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { COLORS } from "@/constants/nahshaliyat";

export default function LegalScreen() {
  return (
    <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background">
      <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
        <Pressable onPress={() => router.back()}><Text style={styles.back}>→ العودة</Text></Pressable>
        <Text style={styles.kicker}>نهشليات</Text>
        <Text style={styles.title}>الخصوصية والشروط</Text>
        <Text style={styles.heading}>سياسة الخصوصية</Text>
        <Text style={styles.body}>نستخدم بيانات الحساب لتسجيل الدخول وتخصيص تجربة العضو وحماية المجتمع. لا تُعرض بيانات الأعضاء وطلبات الخدمات إلا للراعي المخوّل، ولا نبيع البيانات أو نشاركها لأغراض تسويقية.</Text>
        <Text style={styles.heading}>المحادثات</Text>
        <Text style={styles.body}>تُحفظ أسئلتك وإجابات «اسألني» في حسابك؛ لا يطّلع عليها إلا أنت وراعي نهشليات. تُحفظ رسائلك في «راسل راعي المجلس» بمحادثة منفصلة لا يراها إلا أنت والراعي. يُرسل سؤالك الحالي فقط إلى خدمة الإجابة، دون سجل محادثتك أو بيانات الأعضاء.</Text>
        <Text style={styles.heading}>المحتوى والملفات</Text>
        <Text style={styles.body}>تُستخدم الصور والكتب والمشاركات لتقديم ميزات التطبيق فقط. يحتفظ العضو بحق طلب تصحيح بياناته أو حذف حسابه وفق الإجراءات المتاحة في التطبيق.</Text>
        <Text style={styles.heading}>شروط الاستخدام</Text>
        <Text style={styles.body}>يلتزم العضو باحترام الآخرين، وعدم نشر محتوى مخالف أو مسيء أو منتهك للحقوق. يحق للراعي إدارة المحتوى المخالف وحماية سلامة المجلس.</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({ content: { backgroundColor: COLORS.paper, flexGrow: 1, padding: 20 }, back: { color: COLORS.copper, fontSize: 12, fontWeight: "800", textAlign: "right" }, kicker: { color: COLORS.copper, fontSize: 11, fontWeight: "800", marginTop: 30, textAlign: "right" }, title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 30, fontWeight: "800", marginTop: 4, textAlign: "right" }, heading: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 20, fontWeight: "800", marginTop: 27, textAlign: "right" }, body: { color: COLORS.mutedInk, fontSize: 13, lineHeight: 23, marginTop: 9, textAlign: "right" } });
