import { useEffect, useMemo, useState } from "react";
import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { COLORS, playlists } from "@/constants/nahshaliyat";
import { getVideoUrl, openYouTube, readCachedPlaylistVideos, type CachedVideo } from "@/lib/youtube";
import { readWatchHistory, type WatchedVideo } from "@/lib/watch-history";
import * as Api from "@/lib/_core/api";
import { IconSymbol } from "@/components/ui/icon-symbol";

export default function SearchScreen() {
  const [query, setQuery] = useState("");
  const [videos, setVideos] = useState<CachedVideo[]>([]);
  const [history, setHistory] = useState<WatchedVideo[]>([]);
  const [books, setBooks] = useState<Api.BookRecord[]>([]);
  useEffect(() => {
    void Promise.all(playlists.map((playlist) => readCachedPlaylistVideos(playlist.playlistId))).then((sets) => setVideos(sets.flat().filter((item, index, all) => all.findIndex((candidate) => candidate.id === item.id) === index)));
    void readWatchHistory().then(setHistory);
    void Api.getBooks().then((result) => setBooks(result.books)).catch(() => undefined);
  }, []);
  const term = query.trim().toLowerCase();
  const videoResults = useMemo(() => term ? videos.filter((item) => item.title.toLowerCase().includes(term) || item.tag.toLowerCase().includes(term)) : [], [term, videos]);
  const bookResults = useMemo(() => term ? books.filter((book) => `${book.title} ${book.author || ""}`.toLowerCase().includes(term)) : [], [term, books]);
  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><View style={styles.header}><Pressable onPress={() => router.back()}><Text style={styles.back}>→ رجوع</Text></Pressable><View><Text style={styles.kicker}>كل المحتوى</Text><Text style={styles.title}>بحث نهشليات</Text></View></View><View style={styles.searchBox}><IconSymbol name="search" size={20} color={COLORS.copper} /><TextInput autoFocus onChangeText={setQuery} placeholder="ابحث في الفيديوهات والكتب" placeholderTextColor={COLORS.mutedInk} style={styles.input} textAlign="right" value={query} /></View>{term ? <View><Text style={styles.sectionTitle}>الفيديوهات ({videoResults.length})</Text>{videoResults.map((video) => <Pressable key={video.id} onPress={() => openYouTube(getVideoUrl(video.id))} style={styles.result}><IconSymbol name="play-circle" size={20} color={COLORS.copper} /><View style={styles.resultCopy}><Text style={styles.resultTitle}>{video.title}</Text><Text style={styles.resultMeta}>{video.tag} · فتح في يوتيوب</Text></View></Pressable>)}{!videoResults.length ? <Text style={styles.empty}>لا توجد فيديوهات مطابقة.</Text> : null}<Text style={styles.sectionTitle}>الكتب ({bookResults.length})</Text>{bookResults.map((book) => <View key={book.id} style={styles.result}><IconSymbol name="menu-book" size={20} color={COLORS.midnight} /><View style={styles.resultCopy}><Text style={styles.resultTitle}>{book.title}</Text><Text style={styles.resultMeta}>{book.author || "نهشليات"}</Text></View></View>)}{!bookResults.length ? <Text style={styles.empty}>لا توجد كتب مطابقة.</Text> : null}</View> : <View><Text style={styles.sectionTitle}>آخر ما شاهدت</Text>{history.slice(0, 8).map((video) => <Pressable key={video.id} onPress={() => openYouTube(getVideoUrl(video.id))} style={styles.result}><IconSymbol name="play-circle" size={20} color={COLORS.copper} /><View style={styles.resultCopy}><Text style={styles.resultTitle}>{video.title}</Text><Text style={styles.resultMeta}>آخر مشاهدة · {new Date(video.watchedAt).toLocaleDateString("ar-SA")}</Text></View></Pressable>)}{!history.length ? <Text style={styles.empty}>ابدأ بمشاهدة مقطع ليظهر هنا.</Text> : null}</View>}</ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({
  content: { backgroundColor: COLORS.paper, flexGrow: 1, padding: 16 },
  header: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between", paddingTop: 8 },
  back: { color: COLORS.copper, fontSize: 11, fontWeight: "800" },
  kicker: { color: COLORS.copper, fontSize: 10, fontWeight: "900", textAlign: "right" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 25, fontWeight: "800", marginTop: 2, textAlign: "right" },
  searchBox: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 16, borderWidth: 1, flexDirection: "row-reverse", gap: 8, marginTop: 22, paddingHorizontal: 12 },
  input: { color: COLORS.ink, flex: 1, fontSize: 13, minHeight: 48 },
  sectionTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 17, fontWeight: "800", marginTop: 24, textAlign: "right" },
  result: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 14, borderWidth: 1, flexDirection: "row-reverse", gap: 10, marginTop: 8, padding: 12 },
  resultCopy: { flex: 1 },
  resultTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 12, fontWeight: "800", textAlign: "right" },
  resultMeta: { color: COLORS.mutedInk, fontSize: 9, marginTop: 4, textAlign: "right" },
  empty: { color: COLORS.mutedInk, fontSize: 11, marginTop: 10, textAlign: "right" },
});
