import { router, useLocalSearchParams } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { COLORS, featuredVideos } from "@/constants/nahshaliyat";
import { normalizeVideoId } from "@/lib/youtube";
import { ScreenContainer } from "@/components/screen-container";
import { YouTubePlayer } from "@/components/nahshaliyat/youtube-player";

export default function VideoScreen() {
  const { videoId } = useLocalSearchParams<{ videoId?: string }>();
  const id = normalizeVideoId(Array.isArray(videoId) ? videoId[0] || "" : videoId || "");
  const video = featuredVideos.find((item) => item.id === id);
  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><View style={styles.content}><View style={styles.header}><Pressable onPress={() => router.back()}><Text style={styles.back}>→ رجوع</Text></Pressable><Text style={styles.kicker}>تشغيل داخل التطبيق</Text></View><Text style={styles.title}>{video?.title || "فيديو نهشليات"}</Text><View style={styles.player}><YouTubePlayer videoId={id} title={video?.title || "فيديو نهشليات"} /></View><Text style={styles.hint}>يمكنك متابعة المقطع دون مغادرة تطبيق نهشليات.</Text></View></ScreenContainer>;
}

const styles = StyleSheet.create({
  content: { backgroundColor: COLORS.paper, flex: 1, padding: 18 },
  header: { alignItems: "center", flexDirection: "row", justifyContent: "space-between", paddingTop: 8 },
  back: { color: COLORS.copper, fontSize: 12, fontWeight: "800" },
  kicker: { color: COLORS.copper, fontSize: 11, fontWeight: "800" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 23, fontWeight: "800", marginTop: 22, textAlign: "right" },
  player: { backgroundColor: "#000", borderRadius: 18, height: 230, marginTop: 18, overflow: "hidden" },
  hint: { color: COLORS.mutedInk, fontSize: 11, marginTop: 12, textAlign: "right" },
});
