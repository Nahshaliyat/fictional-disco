import { router } from "expo-router";
import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { COLORS } from "@/constants/nahshaliyat";
import { useAuth } from "@/hooks/use-auth";
import { getAdminAskMeHistory, getAdminAskMeThreads, type AskMeRecord, type PrivateThread } from "@/lib/_core/api";

export default function AdminAskMeScreen() {
  const { user, loading } = useAuth();
  const authorized = user?.role === "admin" && user.email?.toLowerCase() === "nahshaliyat@gmail.com";
  const [threads, setThreads] = useState<PrivateThread[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [messages, setMessages] = useState<AskMeRecord[]>([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  async function loadThreads() {
    if (!authorized) return;
    try { setThreads((await getAdminAskMeThreads()).threads); setNotice(""); }
    catch { setNotice("تعذر تحميل محادثات اسألني"); }
  }

  useEffect(() => {
    setThreads([]); setSelected(null); setMessages([]);
    if (authorized) void loadThreads();
  }, [user?.id, authorized]);

  async function openThread(memberId: number) {
    setSelected(memberId);
    setMessages([]);
    setBusy(true);
    try { setMessages((await getAdminAskMeHistory(memberId)).messages); setNotice(""); }
    catch { setNotice("تعذر تحميل هذه المحادثة"); }
    finally { setBusy(false); }
  }

  if (loading) return <ScreenContainer><ActivityIndicator color={COLORS.copper} /></ScreenContainer>;
  if (!authorized) return <ScreenContainer><View style={styles.center}><Text style={styles.info}>هذه الصفحة لراعي نهشليات فقط</Text></View></ScreenContainer>;

  return (
    <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background">
      <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
        <Pressable onPress={() => router.back()}><Text style={styles.back}>→ العودة للإدارة</Text></Pressable>
        <Text style={styles.title}>محادثات اسألني</Text>
        <Pressable onPress={() => { void loadThreads(); if (selected) void openThread(selected); }} style={styles.refresh}><Text style={styles.refreshText}>تحديث</Text></Pressable>
        {notice ? <Text style={styles.notice}>{notice}</Text> : null}
        {threads.map((thread) => (
          <Pressable key={thread.memberId} onPress={() => { void openThread(thread.memberId); }} style={[styles.thread, selected === thread.memberId && styles.selected]}>
            <Text style={styles.threadText}>{thread.memberName || `عضو ${thread.memberId}`}</Text>
          </Pressable>
        ))}
        {threads.length === 0 ? <Text style={styles.info}>لا توجد محادثات بعد</Text> : null}
        {busy ? <ActivityIndicator color={COLORS.copper} style={styles.loading} /> : null}
        {messages.map((entry) => (
          <View key={entry.id} style={styles.card}>
            <Text style={styles.question}>{entry.question}</Text>
            <Text style={styles.answer}>{entry.answer}</Text>
            <Text style={styles.date}>{new Date(entry.createdAt).toLocaleString("ar-SA")}</Text>
          </View>
        ))}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { backgroundColor: COLORS.paper, flexGrow: 1, padding: 18 },
  center: { alignItems: "center", flex: 1, justifyContent: "center" },
  back: { color: COLORS.copper, fontSize: 12, fontWeight: "800", textAlign: "right" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 22, fontWeight: "800", marginTop: 12, textAlign: "right" },
  refresh: { alignSelf: "flex-end", marginTop: 10, padding: 8 },
  refreshText: { color: COLORS.copper, fontSize: 11, fontWeight: "800" },
  notice: { color: "#A84336", fontSize: 12, marginTop: 10, textAlign: "right" },
  info: { color: COLORS.mutedInk, fontSize: 12, marginTop: 16, textAlign: "right" },
  thread: { alignItems: "flex-end", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, marginTop: 7, padding: 11 },
  selected: { borderColor: COLORS.copper },
  threadText: { color: COLORS.ink, fontSize: 12, fontWeight: "800" },
  loading: { marginTop: 16 },
  card: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, marginTop: 9, padding: 11 },
  question: { color: COLORS.copper, fontSize: 12, lineHeight: 20, textAlign: "right" },
  answer: { color: COLORS.ink, fontSize: 12, lineHeight: 21, marginTop: 7, textAlign: "right" },
  date: { color: COLORS.mutedInk, fontSize: 10, marginTop: 7, textAlign: "right" },
});
