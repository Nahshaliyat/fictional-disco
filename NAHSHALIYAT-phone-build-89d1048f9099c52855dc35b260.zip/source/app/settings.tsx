import AsyncStorage from "@react-native-async-storage/async-storage";
import Constants from "expo-constants";
import { router } from "expo-router";
import { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { StatusPill, SoftCard } from "@/components/nahshaliyat/ui";
import { COLORS } from "@/constants/nahshaliyat";
import { useAuth } from "@/hooks/use-auth";
import * as Api from "@/lib/_core/api";

const NIGHT_MODE_KEY = "nahshaliyat_night_mode";
const NOTIFICATIONS_KEY = "nahshaliyat_notifications";

export default function SettingsScreen() {
  const { user } = useAuth();
  const [serverState, setServerState] = useState<"checking" | "online" | "offline">("checking");
  const [lastChecked, setLastChecked] = useState<Date | null>(null);
  const [nightMode, setNightMode] = useState(false);
  const [notifications, setNotifications] = useState(true);

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(NIGHT_MODE_KEY), AsyncStorage.getItem(NOTIFICATIONS_KEY)]).then(([night, alerts]) => {
      setNightMode(night === "true");
      setNotifications(alerts !== "false");
    });
    void checkServer();
  }, []);

  async function checkServer() {
    setServerState("checking");
    try {
      const result = await Api.getHealthStatus();
      setServerState(result.ok ? "online" : "offline");
    } catch {
      setServerState("offline");
    } finally {
      setLastChecked(new Date());
    }
  }

  async function toggleNightMode() {
    const next = !nightMode;
    setNightMode(next);
    await AsyncStorage.setItem(NIGHT_MODE_KEY, String(next));
  }

  async function toggleNotifications() {
    const next = !notifications;
    setNotifications(next);
    await AsyncStorage.setItem(NOTIFICATIONS_KEY, String(next));
  }

  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background">
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Pressable onPress={() => router.back()} style={styles.back}><IconSymbol name="arrow-forward" size={16} color={COLORS.copper} /><Text style={styles.backText}>العودة</Text></Pressable>
      <View style={styles.heading}><View style={styles.headingIcon}><IconSymbol name="admin-panel-settings" size={20} color={COLORS.copper} /></View><View><Text style={styles.kicker}>تخصيص تجربتك</Text><Text style={styles.title}>الإعدادات</Text></View></View>
      <SoftCard style={styles.accountCard}><View style={styles.accountTop}><StatusPill label="الجلسة محفوظة" tone="success" /><View><Text style={styles.accountName}>{user?.name || "عضو نهشليات"}</Text><Text style={styles.accountContact}>{user?.email || user?.phone || ""}</Text></View></View><Text style={styles.accountHint}>بياناتك ومحادثاتك الخاصة مرتبطة بحسابك ولا تظهر للأعضاء الآخرين.</Text></SoftCard>
      <Text style={styles.sectionLabel}>حالة التطبيق</Text>
      <SoftCard style={styles.statusCard}><StatusRow icon="wifi" label="اتصال الخادم" value={serverState === "online" ? "متصل" : serverState === "checking" ? "جارٍ الفحص" : "غير متصل"} tone={serverState === "online" ? "success" : serverState === "checking" ? "neutral" : "error"} /><StatusRow icon="notifications" label="الإشعارات" value={notifications ? "مفعّلة" : "متوقفة"} tone={notifications ? "success" : "neutral"} /><StatusRow icon="auto-awesome" label="إصدار التطبيق" value={Constants.expoConfig?.version || "1.0.0"} tone="neutral" /><Text style={styles.checked}>آخر فحص: {lastChecked ? lastChecked.toLocaleTimeString("ar-SA") : "—"}</Text><Pressable onPress={() => void checkServer()} style={styles.refreshButton}><IconSymbol name="refresh" size={15} color={COLORS.midnight} /><Text style={styles.refreshText}>فحص الاتصال الآن</Text></Pressable></SoftCard>
      <Text style={styles.sectionLabel}>التفضيلات</Text>
      <View style={styles.preferenceStack}><PreferenceRow icon="notifications" title="إشعارات التطبيق" body="التذكيرات والرسائل وتحديثات الطلبات" value={notifications} onPress={() => void toggleNotifications()} /><PreferenceRow icon="dark-mode" title="الوضع الليلي" body="تفضيل محفوظ لهذا الجهاز" value={nightMode} onPress={() => void toggleNightMode()} /></View>
      <Text style={styles.sectionLabel}>الحساب والخصوصية</Text>
      <View style={styles.preferenceStack}><LinkRow icon="person" title="الملف الشخصي" onPress={() => router.push("/profile")} /><LinkRow icon="shield" title="الخصوصية وشروط الاستخدام" onPress={() => router.push("/legal")} /></View>
    </ScrollView>
  </ScreenContainer>;
}

function StatusRow({ icon, label, value, tone }: { icon: any; label: string; value: string; tone: "success" | "neutral" | "error" }) { return <View style={styles.statusRow}><StatusPill label={value} tone={tone} /><View style={styles.rowLabel}><Text style={styles.rowText}>{label}</Text><IconSymbol name={icon} size={17} color={COLORS.mutedInk} /></View></View>; }
function PreferenceRow({ icon, title, body, value, onPress }: { icon: any; title: string; body: string; value: boolean; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.preference, pressed && styles.pressed]}><View style={[styles.switch, value && styles.switchOn]}><View style={[styles.switchKnob, value && styles.switchKnobOn]} /></View><View style={styles.preferenceCopy}><Text style={styles.preferenceTitle}>{title}</Text><Text style={styles.preferenceBody}>{body}</Text></View><IconSymbol name={icon} size={18} color={COLORS.copper} /></Pressable>; }
function LinkRow({ icon, title, onPress }: { icon: any; title: string; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.preference, pressed && styles.pressed]}><IconSymbol name="arrow-back" size={15} color={COLORS.mutedInk} /><Text style={styles.linkTitle}>{title}</Text><IconSymbol name={icon} size={18} color={COLORS.copper} /></Pressable>; }

const styles = StyleSheet.create({ content: { backgroundColor: COLORS.paper, flexGrow: 1, paddingBottom: 34, paddingHorizontal: 16 }, back: { alignItems: "center", flexDirection: "row-reverse", gap: 4, marginTop: 8 }, backText: { color: COLORS.copper, fontSize: 10, fontWeight: "800" }, heading: { alignItems: "center", flexDirection: "row-reverse", gap: 9, marginTop: 17 }, headingIcon: { alignItems: "center", backgroundColor: COLORS.copperSoft, borderRadius: 17, height: 40, justifyContent: "center", width: 40 }, kicker: { color: COLORS.copper, fontSize: 10, fontWeight: "900", textAlign: "right" }, title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 25, fontWeight: "800", textAlign: "right" }, accountCard: { marginTop: 16, padding: 15 }, accountTop: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between" }, accountName: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 17, fontWeight: "800", textAlign: "right" }, accountContact: { color: COLORS.mutedInk, fontSize: 10, marginTop: 3, textAlign: "right" }, accountHint: { color: COLORS.mutedInk, fontSize: 10, lineHeight: 17, marginTop: 12, textAlign: "right" }, sectionLabel: { color: COLORS.ink, fontSize: 12, fontWeight: "900", marginBottom: 7, marginTop: 17, textAlign: "right" }, statusCard: { padding: 13 }, statusRow: { alignItems: "center", borderBottomColor: COLORS.line, borderBottomWidth: 1, flexDirection: "row", justifyContent: "space-between", paddingVertical: 9 }, rowLabel: { alignItems: "center", flexDirection: "row-reverse", gap: 7 }, rowText: { color: COLORS.ink, fontSize: 11, fontWeight: "800" }, checked: { color: COLORS.mutedInk, fontSize: 9, marginTop: 9, textAlign: "right" }, refreshButton: { alignItems: "center", alignSelf: "flex-end", backgroundColor: COLORS.midnightSoft, borderRadius: 10, flexDirection: "row-reverse", gap: 5, marginTop: 10, paddingHorizontal: 10, paddingVertical: 8 }, refreshText: { color: COLORS.midnight, fontSize: 10, fontWeight: "800" }, preferenceStack: { gap: 8 }, preference: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 13, borderWidth: 1, flexDirection: "row-reverse", gap: 9, padding: 12 }, preferenceCopy: { flex: 1 }, preferenceTitle: { color: COLORS.ink, fontSize: 11, fontWeight: "800", textAlign: "right" }, preferenceBody: { color: COLORS.mutedInk, fontSize: 9, marginTop: 3, textAlign: "right" }, switch: { backgroundColor: COLORS.line, borderRadius: 10, height: 20, justifyContent: "center", padding: 2, width: 36 }, switchOn: { backgroundColor: COLORS.olive }, switchKnob: { backgroundColor: COLORS.white, borderRadius: 8, height: 16, width: 16 }, switchKnobOn: { alignSelf: "flex-end" }, linkTitle: { color: COLORS.ink, flex: 1, fontSize: 11, fontWeight: "800", textAlign: "right" }, pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] } });
