import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { COLORS } from "@/constants/nahshaliyat";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 63 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: COLORS.copper,
        tabBarInactiveTintColor: colors.muted,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: "700",
          marginTop: -2,
        },
        tabBarStyle: {
          display: "none",
          backgroundColor: COLORS.white,
          borderTopColor: COLORS.line,
          borderTopWidth: 1,
          height: tabBarHeight,
          paddingBottom: bottomPadding,
          paddingTop: 8,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "الرئيسية",
          tabBarIcon: ({ color }) => <IconSymbol size={23} name="house.fill" color={color} />,
        }}
      />
      <Tabs.Screen
        name="library"
        options={{
          title: "المكتبة",
          tabBarIcon: ({ color }) => <IconSymbol size={23} name="bookshelf" color={color} />,
        }}
      />
      <Tabs.Screen
        name="pens"
        options={{
          title: "أقلام",
          tabBarIcon: ({ color }) => <IconSymbol size={23} name="edit" color={color} />,
        }}
      />
      <Tabs.Screen
        name="council"
        options={{
          title: "المجلس",
          tabBarIcon: ({ color }) => <IconSymbol size={23} name="forum" color={color} />,
        }}
      />
      <Tabs.Screen
        name="ask-me"
        options={{
          title: "اسألني",
          tabBarIcon: ({ color }) => <IconSymbol size={23} name="help-outline" color={color} />,
        }}
      />
    </Tabs>
  );
}
