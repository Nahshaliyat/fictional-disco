import { useCallback, useEffect, useMemo, useState } from "react";
import { Animated, Easing, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";

import { DottedDivider, EmptyState, NoticeBar, SectionTitle, StatusPill } from "@/components/nahshaliyat/ui";
import { COLORS, dailyMessages, featuredVideos, playlists } from "@/constants/nahshaliyat";
import { ScreenContainer } from "@/components/screen-container";
import { getVideoUrl, openYouTube, readCachedPlaylistVideos, cachePlaylistVideos, type CachedVideo } from "@/lib/youtube";
import * as Api from "@/lib/_core/api";

type HomeVideo = { id: string; title: string; meta: string; tag: string };

export default function HomeScreen() {
  const [featured, setFeatured] = useState<HomeVideo[]>(() => featuredVideos.slice(0, 4));
  const [liveSyncConfigured, setLiveSyncConfigured] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const dailyMessage = useMemo(() => dailyMessages[Math.floor(Date.now() / 86400000) % dailyMessages.length], []);
  const tickerX = useMemo(() => new Animated.Value(0), []);

  const refreshLatest = useCallback(async (manual = false) => {
    if (manual) setRefreshing(true); else setLoading(true);
    setError("");
    try {
      const cached = (await Promise.all(playlists.map((playlist) => readCachedPlaylistVideos(playlist.playlistId)))).flat().filter((video, index, all) => all.findIndex((candidate) => candidate.id === video.id) === index).slice(0, 4);
      if (cached.length && !manual) { setFeatured(cached); setLoading(false); }
      const results = await Promise.all(playlists.map((playlist) => Api.getYouTubePlaylistVideos(playlist.playlistId)));
      const latest = results.flatMap((result) => result.videos).filter((video, index, all) => all.findIndex((candidate) => candidate.id === video.id) === index).slice(0, 4);
      if (latest.length) { setFeatured(latest); await Promise.all(playlists.map((playlist, index) => cachePlaylistVideos(playlist.playlistId, results[index].videos as CachedVideo[]))); }
      setLastUpdated(new Date());
    } catch {
      const cached = (await Promise.all(playlists.map((playlist) => readCachedPlaylistVideos(playlist.playlistId)))).flat().slice(0, 4);
      if (cached.length) setFeatured(cached); else setError("تعذر تحديث الجديد الآن؛ ستظهر المقاطع المحفوظة عند توفرها.");
    } finally { setLoading(false); setRefreshing(false); }
  }, []);

  useEffect(() => { void refreshLatest(); const timer = setInterval(() => void refreshLatest(), 60_000); void Api.getSyncedYouTubePlaylists().then((result) => setLiveSyncConfigured(result.liveSyncConfigured)).catch(() => undefined); return () => clearInterval(timer); }, [refreshLatest]);
  useEffect(() => { if (!featured.length) return; const animation = Animated.loop(Animated.sequence([Animated.timing(tickerX, { toValue: -260, duration: 9000, easing: Easing.linear, useNativeDriver: true }), Animated.timing(tickerX, { toValue: 0, duration: 0, useNativeDriver: true })])); animation.start(); return () => animation.stop(); }, [featured.length, tickerX]);

  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void refreshLatest(true)} tintColor={COLORS.copper} />} contentContainerStyle={styles.content}>
    <View style={styles.welcome}><View><Text style={styles.eyebrow}>مساحة الصوت والحرف</Text><Text style={styles.heroTitle}>خذ وقتك مع الحرف</Text><Text style={styles.heroBody}>آخر ما وصل إلى رفوف نهشليات، في واجهة هادئة لك.</Text></View><View style={styles.heroSeal}><Text style={styles.sealMark}>ن</Text><Text style={styles.sealText}>منذ الحرف</Text></View></View>
    <View style={styles.syncRow}><StatusPill label={liveSyncConfigured ? "متصل بالمصدر" : "آخر نسخة محفوظة"} tone={liveSyncConfigured ? "success" : "neutral"} />{lastUpdated ? <Text style={styles.updated}>آخر تحديث {lastUpdated.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}</Text> : null}</View>
    {error ? <NoticeBar message={error} tone="error" onRetry={() => void refreshLatest(true)} /> : null}
    <View style={styles.ticker}><View style={styles.tickerLabel}><Text style={styles.tickerLabelText}>جديد نهشليات</Text></View><View style={styles.tickerWindow}>{loading && !featured.length ? <Text style={styles.loadingText}>جارٍ التحديث...</Text> : featured.length ? <Animated.View style={[styles.tickerTrack, { transform: [{ translateX: tickerX }] }]}>{[...featured, ...featured].map((video, index) => <Pressable key={`${video.id}-${index}`} onPress={() => openYouTube(getVideoUrl(video.id))} style={styles.tickerItem}><Text numberOfLines={1} style={styles.tickerTitle}>{video.title}</Text><Text style={styles.tickerDot}>•</Text></Pressable>)}</Animated.View> : <Text style={styles.loadingText}>لا توجد عناوين متاحة الآن</Text>}</View></View>
    <View style={styles.dailyCard}><View style={styles.dailyTop}><View style={styles.dailyLabel}><View style={styles.dailyDot} /><Text style={styles.dailyKicker}>رسالة اليوم</Text></View><Text style={styles.dailyMeta}>تتجدد كل 24 ساعة</Text></View><Text style={styles.dailyText}>{dailyMessage.text}</Text><DottedDivider color="#D58B6C" /><Pressable onPress={() => openYouTube(getVideoUrl(dailyMessage.sourceId))} style={({ pressed }) => [styles.dailySource, pressed && styles.pressed]}><Text style={styles.dailySourceText}>مصدر الإلهام</Text><Text numberOfLines={1} style={styles.dailySourceTitle}>{dailyMessage.sourceTitle}  ←</Text></Pressable></View>
  </ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({
  content: { backgroundColor: COLORS.paper, flexGrow: 1, paddingBottom: 24, paddingHorizontal: 16 },
  welcome: { alignItems: "center", backgroundColor: COLORS.midnight, borderRadius: 19, flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 15, overflow: "hidden", padding: 16 },
  eyebrow: { color: "#DDA98E", fontSize: 10, fontWeight: "800", textAlign: "right" },
  heroTitle: { color: COLORS.white, fontFamily: "Georgia", fontSize: 24, fontWeight: "800", lineHeight: 31, marginTop: 5, textAlign: "right" },
  heroBody: { color: "#C8BEB3", fontSize: 11, lineHeight: 18, marginTop: 4, maxWidth: 210, textAlign: "right" },
  heroSeal: { alignItems: "center", borderColor: "#725B4E", borderRadius: 46, borderWidth: 1, height: 78, justifyContent: "center", transform: [{ rotate: "-7deg" }], width: 78 },
  sealMark: { color: COLORS.copper, fontFamily: "Georgia", fontSize: 40, fontWeight: "800", lineHeight: 43 },
  sealText: { color: "#DDA98E", fontSize: 8, fontWeight: "800" },
  syncRow: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 12 },
  updated: { color: COLORS.mutedInk, fontSize: 9 },
  ticker: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 14, borderWidth: 1, flexDirection: "row-reverse", marginTop: 12, minHeight: 46, overflow: "hidden" },
  tickerLabel: { backgroundColor: COLORS.copper, justifyContent: "center", minHeight: 46, paddingHorizontal: 10 },
  tickerLabelText: { color: COLORS.white, fontSize: 10, fontWeight: "900" },
  tickerWindow: { flex: 1, overflow: "hidden" },
  tickerTrack: { alignItems: "center", flexDirection: "row", minWidth: 900 },
  tickerItem: { alignItems: "center", flexDirection: "row", gap: 8, paddingHorizontal: 12 },
  tickerTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 11, fontWeight: "800", maxWidth: 190 },
  tickerDot: { color: COLORS.copper, fontSize: 16 },
  loadingLine: { alignItems: "center", paddingVertical: 25 },
  loadingText: { color: COLORS.mutedInk, fontSize: 11 },
  dailyCard: { backgroundColor: COLORS.copper, borderRadius: 20, marginTop: 22, padding: 16 },
  dailyTop: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between" },
  dailyLabel: { alignItems: "center", flexDirection: "row-reverse", gap: 6 },
  dailyDot: { backgroundColor: "#F5CCB7", borderRadius: 5, height: 8, width: 8 },
  dailyKicker: { color: COLORS.white, fontSize: 11, fontWeight: "900" },
  dailyMeta: { color: "#F5D5C4", fontSize: 9 },
  dailyText: { color: COLORS.white, fontFamily: "Georgia", fontSize: 18, fontWeight: "800", lineHeight: 28, marginTop: 13, textAlign: "right" },
  dailySource: { alignItems: "flex-end", borderColor: "#D58B6C", borderRadius: 11, borderWidth: 1, marginTop: 13, paddingHorizontal: 10, paddingVertical: 7 },
  dailySourceText: { color: "#F5D5C4", fontSize: 9, fontWeight: "800" },
  dailySourceTitle: { color: COLORS.white, fontSize: 10, fontWeight: "800", marginTop: 2, maxWidth: "90%" },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
});
