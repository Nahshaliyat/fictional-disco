import { useEffect, useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { EmptyState, NoticeBar, PrimaryButton, SectionTitle, SoftCard } from "@/components/nahshaliyat/ui";
import { COLORS } from "@/constants/nahshaliyat";
import * as Api from "@/lib/_core/api";
import { useAuth } from "@/hooks/use-auth";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";

export default function PensScreen() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Api.PenPostRecord[]>([]);
  const [body, setBody] = useState("");
  const [editing, setEditing] = useState<number | null>(null);
  const [composeOpen, setComposeOpen] = useState(false);
  const [message, setMessage] = useState("");

  async function load() { try { const result = await Api.getPens(); setPosts([...result.posts].sort((a, b) => new Date(b.post.createdAt).getTime() - new Date(a.post.createdAt).getTime())); } catch { setMessage("تعذر تحميل المشاركات؛ حاول مرة أخرى."); } }
  useEffect(() => { void load(); }, []);
  async function submit() { const trimmed = body.trim(); if (!trimmed || trimmed.length > 300) { setMessage("المشاركة لا تتجاوز 300 حرف"); return; } try { if (editing) await Api.updatePen(editing, trimmed); else await Api.createPen(trimmed); setBody(""); setEditing(null); setComposeOpen(false); setMessage("تم حفظ مشاركتك"); await load(); } catch (error) { setMessage(error instanceof Error ? error.message : "تعذر حفظ المشاركة"); } }
  async function remove(id: number) { try { await Api.deletePen(id); await load(); } catch (error) { setMessage(error instanceof Error ? error.message : "تعذر حذف المشاركة"); } }

  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.keyboard}><ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.intro}><View style={styles.introIcon}><IconSymbol name="edit-note" size={22} color={COLORS.copper} /></View><View style={styles.introCopy}><Text style={styles.kicker}>حبرٌ على مهل</Text><Text style={styles.subtitle}>مساحة قصيرة لما يلامس قلبك.</Text></View></View>
    <SectionTitle title="أقلام" kicker="مشاركتك اليومية" />
    {!composeOpen ? <Pressable onPress={() => { setMessage(""); setComposeOpen(true); }} style={({ pressed }) => [styles.writePrompt, pressed && styles.pressed]}><IconSymbol name="edit" size={16} color={COLORS.white} /><Text style={styles.writePromptText}>اكتب مشاركتك</Text></Pressable> : <SoftCard style={styles.compose}><View style={styles.composeTop}><Text style={styles.composeTitle}>{editing ? "تعديل مشاركتك" : "اكتب مشاركة"}</Text><Text style={styles.counter}>{body.length}/300</Text></View><TextInput autoFocus multiline maxLength={300} onChangeText={setBody} placeholder="ماذا تريد أن تشارك مع مجتمع نهشليات؟" placeholderTextColor={COLORS.mutedInk} style={styles.input} textAlign="right" textAlignVertical="top" value={body} /><View style={styles.composeActions}><PrimaryButton label={editing ? "حفظ التعديل" : "نشر المشاركة"} icon="check-circle" onPress={() => void submit()} /><Pressable onPress={() => { setEditing(null); setBody(""); setComposeOpen(false); }} style={styles.cancel}><Text style={styles.cancelText}>إلغاء</Text></Pressable></View></SoftCard>}
    {message ? <NoticeBar message={message} tone={message.includes("تم") ? "success" : "error"} /> : null}
    <View style={styles.stack}>{posts.map(({ post, userName }) => <SoftCard key={post.id} style={styles.post}><View style={styles.postTop}><View style={styles.authorDot}><Text style={styles.authorInitial}>{(userName || "ن").slice(0, 1)}</Text></View><View style={styles.authorCopy}><Text style={styles.postAuthor}>{userName || "عضو نهشليات"}</Text><Text style={styles.postDate}>{new Date(post.createdAt).toLocaleDateString("ar-SA")}</Text></View></View><Text style={styles.postBody}>{post.body}</Text><View style={styles.postActions}>{user?.id === post.userId && post.editCount === 0 && Date.now() - new Date(post.createdAt).getTime() <= 15 * 60 * 1000 ? <Pressable onPress={() => { setEditing(post.id); setBody(post.body); setComposeOpen(true); }}><Text style={styles.edit}>تعديلك الأول</Text></Pressable> : null}{user?.role === "admin" ? <><Pressable onPress={() => { setEditing(post.id); setBody(post.body); setComposeOpen(true); }}><Text style={styles.edit}>تعديل</Text></Pressable><Pressable onPress={() => void remove(post.id)}><Text style={styles.delete}>حذف</Text></Pressable></> : null}</View></SoftCard>)}</View>
    {!posts.length ? <EmptyState icon="edit-note" title="لا توجد مشاركات بعد" body="كن أول من يترك سطرًا لطيفًا اليوم." action="اكتب مشاركتك" onAction={() => setComposeOpen(true)} /> : null}
  </ScrollView></KeyboardAvoidingView></ScreenContainer>;
}

const styles = StyleSheet.create({
  keyboard: { flex: 1 },
  content: { backgroundColor: COLORS.paper, flexGrow: 1, paddingBottom: 24, paddingHorizontal: 16 },
  intro: { alignItems: "center", flexDirection: "row-reverse", gap: 10, marginTop: 16 },
  introIcon: { alignItems: "center", backgroundColor: COLORS.copperSoft, borderRadius: 18, height: 42, justifyContent: "center", width: 42 },
  introCopy: { flex: 1 },
  kicker: { color: COLORS.copper, fontSize: 11, fontWeight: "900", textAlign: "right" },
  subtitle: { color: COLORS.mutedInk, fontSize: 11, marginTop: 3, textAlign: "right" },
  writePrompt: { alignItems: "center", alignSelf: "flex-start", backgroundColor: COLORS.ink, borderRadius: 12, flexDirection: "row-reverse", gap: 6, marginTop: 14, paddingHorizontal: 12, paddingVertical: 8 },
  writePromptText: { color: COLORS.white, fontSize: 10, fontWeight: "800" },
  compose: { marginTop: 13, padding: 12 },
  composeTop: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between" },
  composeTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 16, fontWeight: "800" },
  counter: { color: COLORS.copper, fontSize: 10, fontWeight: "800" },
  input: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 13, borderWidth: 1, color: COLORS.ink, fontSize: 13, height: 110, lineHeight: 22, marginTop: 10, padding: 12 },
  composeActions: { alignItems: "center", flexDirection: "row-reverse", gap: 8, marginTop: 10 },
  cancel: { borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, paddingHorizontal: 15, paddingVertical: 11 },
  cancelText: { color: COLORS.mutedInk, fontSize: 10, fontWeight: "800" },
  stack: { gap: 9, marginTop: 16 },
  post: { padding: 13 },
  postTop: { alignItems: "center", flexDirection: "row-reverse", gap: 8 },
  authorDot: { alignItems: "center", backgroundColor: COLORS.oliveSoft, borderRadius: 16, height: 32, justifyContent: "center", width: 32 },
  authorInitial: { color: COLORS.olive, fontFamily: "Georgia", fontSize: 15, fontWeight: "800" },
  authorCopy: { flex: 1 },
  postAuthor: { color: COLORS.ink, fontSize: 11, fontWeight: "800", textAlign: "right" },
  postDate: { color: COLORS.mutedInk, fontSize: 9, marginTop: 2, textAlign: "right" },
  postBody: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 14, lineHeight: 23, marginTop: 11, textAlign: "right" },
  postActions: { alignItems: "center", flexDirection: "row-reverse", gap: 14, marginTop: 10 },
  edit: { color: COLORS.olive, fontSize: 10, fontWeight: "800" },
  delete: { color: COLORS.error, fontSize: 10, fontWeight: "800" },
  pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
});
