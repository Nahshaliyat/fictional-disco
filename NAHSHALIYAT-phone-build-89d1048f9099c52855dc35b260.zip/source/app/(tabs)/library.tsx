import { useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { WebView } from "react-native-webview";

import { COLORS } from "@/constants/nahshaliyat";
import * as Api from "@/lib/_core/api";
import { useAuth } from "@/hooks/use-auth";
import { ScreenContainer } from "@/components/screen-container";

export default function LibraryScreen() {
  const { user } = useAuth();
  const [books, setBooks] = useState<Api.BookRecord[]>([]);
  const [selected, setSelected] = useState<Api.BookRecord | null>(null);
  const [form, setForm] = useState({ title: "", author: "", content: "", mimeType: "", fileSize: "", fileKey: "" });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const [pdfHeight, setPdfHeight] = useState(620);
  const [readerPage, setReaderPage] = useState(1);

  async function loadBooks() {
    try { const result = await Api.getBooks(); setBooks(result.books); } catch { setMessage("تعذر تحميل الكتب الآن"); }
  }
  useEffect(() => { loadBooks(); }, []);
  const visibleBooks = books;

  async function openBook(book: Api.BookRecord) {
    setSelected(book);
    const saved = await AsyncStorage.getItem(`nahshaliyat_book_page_${book.id}`);
    const page = Number(saved);
    setReaderPage(Number.isFinite(page) && page > 0 ? page : 1);
  }

  async function saveBook() {
    if (!form.title.trim() || !form.content.trim()) { setMessage("أدخل عنوان الكتاب ومحتواه"); return; }
    try {
      const payload = { ...form, fileSize: form.fileSize ? Number(form.fileSize) : undefined };
      if (editingId) await Api.updateBook(editingId, payload);
      else await Api.createBook(payload);
      setForm({ title: "", author: "", content: "", mimeType: "", fileSize: "", fileKey: "" }); setEditingId(null); setMessage("تم حفظ الكتاب"); await loadBooks();
    } catch (error) { setMessage(error instanceof Error ? error.message : "تعذر حفظ الكتاب"); }
  }

  async function removeBook(id: number) {
    const confirmed = await new Promise<boolean>((resolve) => Alert.alert("تأكيد حذف الكتاب", "هل تريد حذف هذا الكتاب؟", [{ text: "إلغاء", onPress: () => resolve(false), style: "cancel" }, { text: "حذف", onPress: () => resolve(true), style: "destructive" }]));
    if (!confirmed) return;
    try { await Api.deleteBook(id); setSelected(null); setMessage("تم حذف الكتاب"); await loadBooks(); } catch (error) { setMessage(error instanceof Error ? error.message : "تعذر حذف الكتاب"); }
  }

  async function pickBook() {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: ["text/plain", "application/pdf", "application/epub+zip"], copyToCacheDirectory: true });
      if (result.canceled || !result.assets[0]) return;
      const asset = result.assets[0];
      const mimeType = asset.mimeType || "application/octet-stream";
      let content = "";
      if (mimeType === "text/plain") {
        content = Platform.OS === "web" ? await (await fetch(asset.uri)).text() : await FileSystem.readAsStringAsync(asset.uri);
      } else if (mimeType === "application/pdf") {
        if (Platform.OS === "web") {
          const blob = await (await fetch(asset.uri)).blob();
          content = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = () => reject(new Error("تعذر قراءة ملف PDF")); reader.readAsDataURL(blob); });
        } else {
          content = `data:application/pdf;base64,${await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 })}`;
        }
      } else {
        content = `تم اختيار ملف ${asset.name}.`;
      }
      setForm((current) => ({ ...current, title: current.title || asset.name.replace(/\.[^.]+$/, ""), content, mimeType, fileSize: asset.size ? String(asset.size) : current.fileSize, fileKey: Platform.OS === "web" ? asset.name : asset.uri } as typeof current));
      setMessage(`تم اختيار ${asset.name}، اضغط «رفع الكتاب» لاعتماده`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "تعذر قراءة الملف المختار");
    }
  }

  function renderPdf(content: string, initialPage: number) {
    const base64 = content.split(",", 2)[1] || "";
    const html = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:#f7f2e8}#pages{padding:10px}canvas{display:block;width:100%;height:auto;margin:0 auto 12px;background:#fff;box-shadow:0 1px 5px #cfc4b5}</style></head><body><div id="pages"></div><script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script><script>const initial=${Math.max(1, Math.floor(initialPage))};const raw=atob(${JSON.stringify(base64)}),data=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)data[i]=raw.charCodeAt(i);pdfjsLib.getDocument({data}).promise.then(async pdf=>{for(let n=1;n<=pdf.numPages;n++){const page=await pdf.getPage(n),viewport=page.getViewport({scale:1.35}),canvas=document.createElement('canvas');canvas.dataset.page=String(n);canvas.width=viewport.width;canvas.height=viewport.height;document.getElementById('pages').appendChild(canvas);await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;if(n===initial)canvas.scrollIntoView({block:'start'});window.ReactNativeWebView&&window.ReactNativeWebView.postMessage('page:'+n+'|'+document.body.scrollHeight);}}).catch(()=>{document.body.innerHTML='<p style="padding:24px;text-align:center">تعذر عرض هذا الملف داخل التطبيق</p>'});</script></body></html>`;
    return <WebView originWhitelist={["*"]} javaScriptEnabled onMessage={(event) => { const value = String(event.nativeEvent.data); const [kind, raw] = value.split(":", 2); if (kind === "page") { const [page, height] = raw.split("|").map(Number); if (Number.isFinite(page)) { setReaderPage(page); void AsyncStorage.setItem(`nahshaliyat_book_page_${selected?.id || ""}`, String(page)); } if (Number.isFinite(height)) setPdfHeight(Math.max(620, height + 24)); } else { const height = Number(value); if (Number.isFinite(height)) setPdfHeight(Math.max(620, height + 24)); } }} source={{ html }} style={[styles.pdfReader, { height: pdfHeight }]} />;
  }

  if (selected) {
    return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.keyboard}><ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}><Pressable onPress={() => setSelected(null)} style={styles.back}><Text style={styles.backText}>→ العودة إلى المكتبة</Text></Pressable><Text style={styles.kicker}>قراءة داخل التطبيق</Text><Text style={styles.title}>{selected.title}</Text>{selected.content.startsWith("data:application/pdf") ? <Text style={styles.resumeHint}>آخر موضع: صفحة {readerPage}</Text> : null}<View style={styles.reader}>{selected.content.startsWith("data:application/pdf") ? renderPdf(selected.content, readerPage) : <Text style={styles.readerText}>{selected.content}</Text>}</View></ScrollView></KeyboardAvoidingView></ScreenContainer>;
  }

  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.keyboard}><ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <Text style={styles.kicker}>رفوف المعرفة</Text>
    {message ? <Text style={styles.message}>{message}</Text> : null}
    {books.length === 0 ? <View style={styles.empty}><Text style={styles.emptyTitle}>لم تُرفع كتب بعد</Text><Text style={styles.emptyBody}>ستظهر الكتب هنا عند رفعها.</Text></View> : visibleBooks.length === 0 ? <EmptySearch /> : <View style={styles.bookList}>{visibleBooks.map((book) => <View key={book.id} style={styles.bookCard}><Pressable onPress={() => void openBook(book)} style={styles.bookMain}><Text style={styles.bookIcon}>▤</Text><View style={styles.bookCopy}><Text style={styles.bookTitle}>{book.title}</Text><Text style={styles.bookAuthor}>{book.author || "منشورات نهشليات"}</Text><Text style={styles.read}>فتح للقراءة  ←</Text></View></Pressable>{user?.role === "admin" ? <View style={styles.manageRow}><Pressable onPress={() => { setEditingId(book.id); setForm({ title: book.title, author: book.author || "", content: book.content, mimeType: book.mimeType || "", fileSize: book.fileSize ? String(book.fileSize) : "", fileKey: book.fileKey || "" }); }}><Text style={styles.manageText}>تحديث</Text></Pressable><Pressable onPress={() => removeBook(book.id)}><Text style={styles.deleteText}>حذف</Text></Pressable></View> : null}</View>)}</View>}
    {user?.role === "admin" ? <View style={styles.adminPanel}><Text style={styles.panelTitle}>{editingId ? "تحديث كتاب" : "رفع كتاب جديد"}</Text><TextInput onChangeText={(value) => setForm((current) => ({ ...current, title: value }))} placeholder="عنوان الكتاب" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={form.title} /><TextInput onChangeText={(value) => setForm((current) => ({ ...current, author: value }))} placeholder="اسم المؤلف" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={form.author} /><Pressable onPress={pickBook} style={styles.pickButton}><Text style={styles.pickButtonText}>رفع الكتاب</Text></Pressable>{form.content ? <Text style={styles.selectedFile}>تم اختيار الملف</Text> : null}<View style={styles.buttonRow}><Pressable onPress={saveBook} style={styles.primary}><Text style={styles.primaryText}>{editingId ? "تحديث الكتاب" : "نشر الكتاب"}</Text></Pressable>{editingId ? <Pressable onPress={() => { setEditingId(null); setForm({ title: "", author: "", content: "", mimeType: "", fileSize: "", fileKey: "" }); }} style={styles.secondary}><Text style={styles.secondaryText}>إلغاء</Text></Pressable> : null}</View></View> : null}
  </ScrollView></KeyboardAvoidingView></ScreenContainer>;
}

function EmptySearch() { return <View style={styles.empty}><Text style={styles.emptyTitle}>لا توجد نتائج</Text><Text style={styles.emptyBody}>جرّب كلمة بحث أخرى.</Text></View>; }

const styles = StyleSheet.create({
  keyboard: { flex: 1 },
  content: { backgroundColor: COLORS.paper, flexGrow: 1, padding: 18 },
  kicker: { color: COLORS.copper, fontSize: 11, fontWeight: "800", marginTop: 8, textAlign: "right" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 25, fontWeight: "800", marginTop: 3, textAlign: "right" },
  searchInput: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, color: COLORS.ink, fontSize: 12, marginTop: 14, paddingHorizontal: 12, paddingVertical: 11 },
  body: { color: COLORS.mutedInk, fontSize: 13, lineHeight: 21, marginTop: 8, textAlign: "right" },
  adminPanel: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 14, borderWidth: 1, marginTop: 16, padding: 11 },
  panelTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 16, fontWeight: "800", textAlign: "right" },
  pickButton: { alignItems: "center", backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 9, borderWidth: 1, marginTop: 8, paddingVertical: 8 },
  pickButtonText: { color: COLORS.copper, fontSize: 10, fontWeight: "800" },
  selectedFile: { color: COLORS.olive, fontSize: 10, marginTop: 6, textAlign: "right" },
  input: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 9, borderWidth: 1, color: COLORS.ink, fontSize: 11, height: 37, marginTop: 7, paddingHorizontal: 10 },
  contentInput: { height: 130, paddingTop: 12 },
  buttonRow: { flexDirection: "row", gap: 8, marginTop: 11 },
  primary: { alignItems: "center", backgroundColor: COLORS.midnight, borderRadius: 9, flex: 1, paddingVertical: 9 },
  primaryText: { color: COLORS.paper, fontSize: 10, fontWeight: "800" },
  secondary: { alignItems: "center", borderColor: COLORS.line, borderRadius: 9, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 9 },
  secondaryText: { color: COLORS.mutedInk, fontSize: 10, fontWeight: "800" },
  message: { color: COLORS.copper, fontSize: 11, marginTop: 10, textAlign: "right" },
  headingRow: { alignItems: "flex-end", flexDirection: "row", justifyContent: "space-between", marginTop: 28 },
  heading: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 20, fontWeight: "800", textAlign: "right" },
  headingHint: { color: COLORS.mutedInk, fontSize: 11 },
  bookList: { gap: 10, marginTop: 13 },
  bookCard: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 15, borderWidth: 1, overflow: "hidden", padding: 11 },
  bookMain: { alignItems: "center", flexDirection: "row-reverse", gap: 10 },
  bookIcon: { alignItems: "center", backgroundColor: COLORS.midnightSoft, borderRadius: 12, color: COLORS.midnight, fontSize: 22, height: 43, paddingTop: 7, textAlign: "center", width: 43 },
  bookCopy: { flex: 1 },
  bookTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 15, fontWeight: "800", textAlign: "right" },
  bookAuthor: { color: COLORS.mutedInk, fontSize: 11, marginTop: 4, textAlign: "right" },
  read: { color: COLORS.olive, fontSize: 11, fontWeight: "800", marginTop: 8, textAlign: "right" },
  manageRow: { borderTopColor: COLORS.line, borderTopWidth: 1, flexDirection: "row", gap: 16, justifyContent: "flex-start", marginTop: 12, paddingTop: 10 },
  manageText: { color: COLORS.olive, fontSize: 11, fontWeight: "800" },
  deleteText: { color: "#B45445", fontSize: 11, fontWeight: "800" },
  empty: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, marginTop: 13, padding: 22 },
  emptyTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 17, fontWeight: "800" },
  emptyBody: { color: COLORS.mutedInk, fontSize: 11, lineHeight: 17, marginTop: 5, textAlign: "center" },
  sectionLabel: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 20, fontWeight: "800", marginTop: 28, textAlign: "right" },
  stack: { gap: 10, marginTop: 13 },
  back: { alignSelf: "flex-end", marginBottom: 18 },
  backText: { color: COLORS.copper, fontSize: 12, fontWeight: "800" },
  cover: { alignSelf: "center", borderRadius: 14, height: 180, marginBottom: 18, width: 130 },
  author: { color: COLORS.mutedInk, fontSize: 12, marginTop: 5, textAlign: "right" },
  reader: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 19, borderWidth: 1, marginTop: 12, padding: 18 },
  resumeHint: { color: COLORS.midnight, fontSize: 10, marginTop: 8, textAlign: "right" },
  pdfReader: { height: 620, width: "100%" },
  readerText: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 16, lineHeight: 31, textAlign: "right" },
  source: { color: COLORS.olive, fontSize: 10, marginTop: 12, textAlign: "right" },
});
