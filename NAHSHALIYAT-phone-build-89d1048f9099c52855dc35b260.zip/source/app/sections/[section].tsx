import { useLocalSearchParams } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { useEffect, useState } from "react";
import {
  Animated,
  Easing,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

import { PlaylistCard } from "@/components/nahshaliyat/playlist-card";
import { VideoCard } from "@/components/nahshaliyat/video-card";
import { EmptyState, LoadingState, NoticeBar, SectionTitle, StatusPill } from "@/components/nahshaliyat/ui";
import {
  COLORS,
  playlists,
  savedVideos,
  type TopSectionId,
} from "@/constants/nahshaliyat";
import { cachePlaylistVideos, openChannel, readCachedPlaylistVideos } from "@/lib/youtube";
import * as Api from "@/lib/_core/api";
import { ScreenContainer } from "@/components/screen-container";
import { FreeServicesSection } from "@/components/nahshaliyat/free-services";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { YouTubePlayer } from "@/components/nahshaliyat/youtube-player";

export default function SectionScreen() {
  const { section } = useLocalSearchParams<{ section?: string | string[] }>();
  const sectionId = (Array.isArray(section) ? section[0] : section ?? "hena").toLowerCase() as TopSectionId;
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [playlistVideos, setPlaylistVideos] = useState<Array<{ id: string; title: string; meta: string; tag: string }>>([]);
  const [playlistLoading, setPlaylistLoading] = useState(false);
  const [playingVideo, setPlayingVideo] = useState<{ id: string; title: string; meta: string; tag: string } | null>(null);
  const selectedPlaylist = playlists.find((playlist) => playlist.id === selectedPlaylistId);

  useEffect(() => {
    if (!selectedPlaylist) { setPlaylistVideos([]); setPlayingVideo(null); return; }
    let active = true;
    const refreshPlaylist = async (initial = false) => {
      if (initial) {
        setPlaylistLoading(true);
        const cached = await readCachedPlaylistVideos(selectedPlaylist.playlistId);
        if (active && cached.length) { setPlaylistVideos(cached); setPlaylistLoading(false); }
      }
      Api.getYouTubePlaylistVideos(selectedPlaylist.playlistId)
        .then(async (result) => { if (active) setPlaylistVideos(result.videos); await cachePlaylistVideos(selectedPlaylist.playlistId, result.videos); })
        .catch(async () => { const cached = await readCachedPlaylistVideos(selectedPlaylist.playlistId); if (active) setPlaylistVideos(cached); })
        .finally(() => { if (active && initial) setPlaylistLoading(false); });
    };
    refreshPlaylist(true);
    const refreshTimer = setInterval(() => refreshPlaylist(), 30_000);
    return () => { active = false; clearInterval(refreshTimer); };
  }, [selectedPlaylistId]);

  return (
    <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background">
      <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {sectionId === "hena" ? (
          <>
            <SectionTitle kicker="اختر رفًا واحدًا" title="هنا نهشليات" />
            <Text style={styles.sectionLead}>صوتٌ أصيل، قصائد، وشيلات مرتبة لتعود إليها متى شئت.</Text>
            <View style={styles.stack}>
              {playlists.map((playlist) => <PlaylistCard key={playlist.id} active={playlist.id === selectedPlaylistId} onSelect={() => setSelectedPlaylistId(playlist.id)} playlist={playlist} />)}
            </View>
            <SectionTicker />
            {selectedPlaylist ? <View style={styles.playlistShelf}><View style={styles.shelfHeader}><View><Text style={styles.playlistShelfTitle}>{selectedPlaylist.title}</Text><Text style={styles.playlistShelfMeta}>{selectedPlaylist.description}</Text></View><StatusPill label={playlistVideos.length ? `${playlistVideos.length} مقطع` : "المصدر"} tone={playlistVideos.length ? "success" : "neutral"} /></View>{playingVideo ? <InlinePlayer video={playingVideo} /> : <View style={styles.playerPlaceholder}><Text style={styles.playerPlaceholderText}>اختر فيديو ليعمل هنا</Text></View>}{playlistLoading ? <LoadingState label="نستدعي كل المقاطع من الرف..." /> : playlistVideos.length ? <View style={styles.playlistVideos}>{playlistVideos.map((video) => <VideoCard key={video.id} video={video} compact onPlay={setPlayingVideo} />)}</View> : <EmptyState icon="wifi-off" title="تعذر تحميل هذه القائمة" body="تحقق من الاتصال ثم حاول مرة أخرى." />}</View> : null}
          </>
        ) : sectionId === "diary" ? (
          <DiarySection />
        ) : (
          <ServicesSection />
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

function SectionTicker() {
  const offset = useState(() => new Animated.Value(0))[0];
  const items = ["جديد نهشليات يصل أولًا إلى رفوفك", "استكشف الطرب والقصائد والشيلات في مكان واحد", "المكتبة للقراءة، وأقلام للمشاركة، والمجلس للحوار", "اسألني عن طريقة استخدام أي قسم داخل التطبيق"];
  useEffect(() => {
    const animation = Animated.loop(Animated.sequence([
      Animated.timing(offset, { toValue: -520, duration: 14500, easing: Easing.linear, useNativeDriver: true }),
      Animated.timing(offset, { toValue: 0, duration: 0, useNativeDriver: true }),
    ]));
    animation.start();
    return () => animation.stop();
  }, [offset]);
  return <View style={styles.sectionTicker}><View style={styles.sectionTickerLabel}><Text style={styles.sectionTickerLabelText}>نهشليات</Text></View><View style={styles.sectionTickerWindow}><Animated.View style={[styles.sectionTickerTrack, { transform: [{ translateX: offset }] }]}>{[...items, ...items].map((item, index) => <Text key={`${item}-${index}`} numberOfLines={1} style={styles.sectionTickerItem}>{item}  •  </Text>)}</Animated.View></View></View>;
}

function InlinePlayer({ video }: { video: { id: string; title: string } }) {
  return <View style={styles.inlinePlayer}><Text style={styles.nowPlaying} numberOfLines={1}>يعمل الآن: {video.title}</Text><YouTubePlayer videoId={video.id} title={video.title} compact /></View>;
}

function DiarySection() {
  const year = new Date().getFullYear();
  const [month, setMonth] = useState(new Date().getMonth());
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [reminderText, setReminderText] = useState("");
  const [reminderType, setReminderType] = useState("موعد");
  const [reminderTime, setReminderTime] = useState("09:00");
  const [reminders, setReminders] = useState<Array<{ date: string; text: string }>>([]);
  const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay();
  useEffect(() => { AsyncStorage.getItem("nahshaliyat_reminders").then((value) => { if (value) setReminders(JSON.parse(value)); }); }, []);
  async function addReminder() {
    if (!selectedDay || !reminderText.trim()) return;
    const reminderTitle = `${reminderType}: ${reminderText.trim()}`;
    const reminderDate = `${year}-${String(month + 1).padStart(2, "0")}-${String(selectedDay).padStart(2, "0")}`;
    const next = [...reminders, { date: reminderDate, text: reminderTitle }];
    setReminders(next); setReminderText(""); setSelectedDay(null); await AsyncStorage.setItem("nahshaliyat_reminders", JSON.stringify(next));
    const [hour, minute] = reminderTime.split(":").map(Number);
    const remindAt = new Date(year, month, selectedDay, Number.isFinite(hour) ? hour : 9, Number.isFinite(minute) ? minute : 0, 0);
    try { await Api.createReminder(reminderTitle, remindAt.toISOString()); } catch { /* local reminder remains available when server sync is unavailable */ }
    const permission = await Notifications.getPermissionsAsync();
    if (permission.status !== "granted") await Notifications.requestPermissionsAsync();
    if (remindAt.getTime() > Date.now()) await Notifications.scheduleNotificationAsync({ content: { title: `تذكير: ${reminderType}`, body: reminderText.trim(), data: { date: next[next.length - 1].date } }, trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: remindAt } });
  }
  return (
    <View style={styles.sectionBlock}>
      <View style={styles.intro}>
        <Text style={styles.eyebrow}>مساحتك الخاصة</Text>
        <Text style={styles.heading}>دفتر نهشليات</Text>
        <Text style={styles.body}>مكان هادئ تجمع فيه ما تريد تذكّره وما ينتظرك من مواعيد.</Text>
      </View>
      <View style={styles.diaryGrid}>
        <View style={styles.diaryCard}>
          <Text style={styles.diaryIcon}>◷</Text>
          <Text style={styles.diaryTitle}>التنبيهات</Text>
          <Text style={styles.diaryBody}>{reminders.length ? `لديك ${reminders.length} تذكير` : "تنبيهات التقويم وأخبار التطبيق"}</Text>
          {reminders.slice(-3).map((item) => <Text key={`${item.date}-${item.text}`} style={styles.alertItem}>{item.date} · {item.text}</Text>)}
        </View>
        <View style={[styles.diaryCard, styles.diaryCardOlive]}>
          <Text style={styles.diaryIcon}>▦</Text>
          <Text style={styles.diaryTitle}>التقويم</Text>
          <Text style={styles.diaryBody}>تقويم {year} السنوي</Text>
        </View>
      </View>
      <View style={styles.calendarCard}>
        <Text style={styles.calendarTitle}>تقويم {year}</Text>
        <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.monthsRow}>{monthNames.map((name, index) => <Pressable key={name} onPress={() => { setMonth(index); setSelectedDay(null); }} style={[styles.monthChip, month === index && styles.monthChipActive]}><Text style={[styles.monthText, month === index && styles.monthTextActive]}>{name}</Text></Pressable>)}</ScrollView>
        <View style={styles.weekRow}>{["أحد", "اثن", "ثلا", "أرب", "خمي", "جمع", "سبت"].map((day) => <Text key={day} style={styles.weekText}>{day}</Text>)}</View>
        <View style={styles.daysGrid}>{Array.from({ length: firstDay }).map((_, index) => <View key={`empty-${index}`} style={styles.dayCell} />)}{Array.from({ length: daysInMonth }, (_, index) => index + 1).map((day) => <Pressable key={day} onPress={() => setSelectedDay(day)} style={[styles.dayCell, selectedDay === day && styles.daySelected]}><Text style={[styles.dayText, selectedDay === day && styles.daySelectedText]}>{day}</Text></Pressable>)}</View>
        {selectedDay ? <View style={styles.reminderBox}><Text style={styles.reminderLabel}>تذكير يوم {selectedDay} {monthNames[month]}</Text><View style={styles.reminderTypes}>{["موعد", "مناسبة", "عيد ميلاد"].map((type) => <Pressable key={type} onPress={() => setReminderType(type)} style={[styles.reminderType, reminderType === type && styles.reminderTypeActive]}><Text style={[styles.reminderTypeText, reminderType === type && styles.reminderTypeTextActive]}>{type}</Text></Pressable>)}</View><TextInput onChangeText={setReminderText} placeholder="اكتب تفاصيل التذكير" placeholderTextColor="#A59A8D" style={styles.reminderInput} textAlign="right" value={reminderText} /><TextInput keyboardType="numbers-and-punctuation" onChangeText={setReminderTime} placeholder="الوقت 09:00" placeholderTextColor="#A59A8D" style={styles.reminderInput} textAlign="right" value={reminderTime} /><Pressable onPress={addReminder} style={styles.reminderButton}><Text style={styles.reminderButtonText}>حفظ التذكير</Text></Pressable></View> : <Text style={styles.calendarHint}>اختر يومًا لإضافة موعد أو مناسبة أو عيد ميلاد.</Text>}
      </View>
      <View style={styles.subscriptionCard}>
        <View style={styles.subscriptionBadge}><Text style={styles.subscriptionBadgeText}>ن</Text></View><View style={styles.subscriptionCopy}><Text style={styles.subscriptionTitle}>اشترك في نهشليات</Text><Text style={styles.subscriptionBody}>تابع جديد نهشليات من داخل دفتر نهشليات.</Text></View><Pressable onPress={openChannel} style={styles.subscribeButton}><Text style={styles.subscribeButtonText}>اشتراك</Text></Pressable>
      </View>
      <View style={styles.savedDiaryCard}>
        <Text style={styles.savedDiaryTitle}>محفوظاتي</Text>
        <Text style={styles.savedDiaryBody}>المقاطع التي حفظتها للعودة إليها.</Text>
        <View style={styles.videoStack}>{savedVideos.map((video) => <VideoCard key={video.id} video={video} compact />)}</View>
      </View>
    </View>
  );
}

function SavedSection() {
  return (
    <View style={styles.sectionBlock}>
      <View style={styles.intro}>
        <Text style={styles.eyebrow}>رفك الشخصي</Text>
        <Text style={styles.heading}>محفوظاتي</Text>
        <Text style={styles.body}>كل ما أحببته أو أردت العودة إليه، في مكان واحد.</Text>
      </View>
      <Text style={styles.subTitle}>محفوظاتك الأخيرة</Text>
      <View style={styles.videoStack}>
        {savedVideos.map((video) => <VideoCard key={video.id} video={video} compact />)}
      </View>
    </View>
  );
}

function ServicesSection() {
  const [form, setForm] = useState({ name: "", requestType: "", details: "", phone: "", email: "" });
  const [busy, setBusy] = useState(false);
  const [requestNumber, setRequestNumber] = useState("");
  const [showFreeServices, setShowFreeServices] = useState(false);
  const [myRequests, setMyRequests] = useState<Array<{ requestNumber: string; requestType: string; status: "new" | "reviewing" | "contacted" | "completed"; createdAt: string }>>([]);
  const update = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }));
  useEffect(() => { Api.getMyServiceRequests().then((result) => setMyRequests(result.requests)).catch(() => undefined); }, []);

  async function submit() {
    if (Object.values(form).some((value) => !value.trim())) return;
    setBusy(true);
    try {
      const result = await Api.createServiceRequest(form);
      setRequestNumber(result.requestNumber);
      const subject = encodeURIComponent(`طلب خدمة نهشليات ${result.requestNumber}`);
      const body = encodeURIComponent(`رقم الطلب: ${result.requestNumber}\nالاسم: ${form.name}\nنوع الطلب: ${form.requestType}\nالهاتف: ${form.phone}\nالإيميل: ${form.email}\n\nالتفاصيل:\n${form.details}`);
      await Linking.openURL(`mailto:nahshaliyat@gmail.com?subject=${subject}&body=${body}`);
    } finally {
      setBusy(false);
    }
  }

  if (requestNumber) {
    return (
      <View style={styles.successBox}>
        <Text style={styles.successMark}>✓</Text>
        <Text style={styles.successTitle}>تم استلام طلبك</Text>
        <Text style={styles.successBody}>سيتم التواصل معك بأسرع وقت عبر البيانات التي أدخلتها.</Text>
        <View style={styles.requestNumberBox}><Text style={styles.requestNumberLabel}>رقم الطلب</Text><Text style={styles.requestNumber}>{requestNumber}</Text></View>
        <Text style={styles.successHint}>فُتحت رسالة بريد مهيأة إلى nahshaliyat@gmail.com لإرسال تفاصيل الطلب.</Text>
      </View>
    );
  }

  if (showFreeServices) return <FreeServicesSection onBack={() => setShowFreeServices(false)} />;

  return (
    <View style={styles.sectionBlock}>
      {myRequests.length ? <View style={styles.requestTracker}><View style={styles.requestTrackerTop}><Text style={styles.requestTrackerTitle}>طلباتي</Text><Text style={styles.requestTrackerMeta}>{myRequests.length} طلب</Text></View>{myRequests.slice(0, 3).map((item) => <View key={item.requestNumber} style={styles.requestRow}><Text style={styles.requestStatus}>{item.status === "new" ? "جديد" : item.status === "reviewing" ? "قيد المراجعة" : item.status === "contacted" ? "تم التواصل" : "مكتمل"}</Text><View style={styles.requestCopy}><Text style={styles.requestNumberCompact}>{item.requestNumber}</Text><Text style={styles.requestType}>{item.requestType} · {new Date(item.createdAt).toLocaleDateString("ar-SA")}</Text></View></View>)}</View> : null}
      <Pressable onPress={() => setShowFreeServices(true)} style={({ pressed }) => [styles.freeServicesCard, pressed && styles.pressed]}><View style={styles.freeServicesIcon}><IconSymbol name="auto-awesome" size={20} color={COLORS.midnight} /></View><View style={styles.freeServicesCopy}><Text style={styles.freeServicesTitle}>خدمات مجانية</Text><Text style={styles.freeServicesBody}>تصوير المستندات ومتابعة المصاريف من صفحة مستقلة.</Text></View><IconSymbol name="arrow-back" size={17} color={COLORS.midnight} /></Pressable>
      <View style={styles.servicesList}>
        <ServiceItem title="أغاني وشيلات وقصائد خاصة" body="باسمك ولجميع المناسبات بكلمات وأداء يناسب ذوقك." />
        <ServiceItem title="بناء التطبيقات" body="نحول فكرتك إلى تطبيق بشكل احترافي يناسب مشروعك واحتياجك." />
        <ServiceItem title="تصميمات إبداعية" body="شعارات إعلانات منشورات وتصاميم مناسبات وغيرها." />
        <ServiceItem title="أخرى" body="بحوث، ترجمة خدمات مكتبية أنشطة وواجبات مدرسية والكثير." last />
      </View>
      <View style={styles.formCard}>
        <Text style={styles.formTitle}>بيانات الطلب</Text>
        <TextInput onChangeText={(value) => update("name", value)} placeholder="الاسم" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={form.name} />
        <TextInput onChangeText={(value) => update("requestType", value)} placeholder="نوع الطلب" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={form.requestType} />
        <TextInput multiline onChangeText={(value) => update("details", value)} placeholder="تفاصيل الطلب" placeholderTextColor="#A59A8D" style={[styles.input, styles.detailsInput]} textAlign="right" textAlignVertical="top" value={form.details} />
        <TextInput keyboardType="phone-pad" onChangeText={(value) => update("phone", value)} placeholder="رقم الهاتف" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={form.phone} />
        <TextInput autoCapitalize="none" keyboardType="email-address" onChangeText={(value) => update("email", value)} placeholder="الإيميل" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={form.email} />
        <Pressable disabled={busy} onPress={submit} style={[styles.sendButton, busy && styles.disabledButton]}>
          <Text style={styles.sendButtonText}>{busy ? "جارٍ إرسال الطلب..." : "إرسال الطلب  ←"}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function ServiceItem({ title, body, last = false }: { title: string; body: string; last?: boolean }) {
  return <View style={[styles.serviceItem, !last && styles.serviceDivider]}><View style={styles.serviceIcon}><Text style={styles.serviceIconText}>✦</Text></View><View style={styles.serviceCopy}><Text style={styles.serviceTitle}>{title}</Text><Text style={styles.serviceBody}>{body}</Text></View></View>;
}

const styles = StyleSheet.create({
  content: {
    backgroundColor: COLORS.paper,
    minHeight: "100%",
    paddingBottom: 36,
    paddingHorizontal: 18,
  },
  intro: {
    alignItems: "flex-end",
    marginTop: 19,
  },
  eyebrow: {
    color: COLORS.copper,
    fontSize: 11,
    fontWeight: "800",
  },
  heading: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 30,
    fontWeight: "800",
    marginTop: 4,
  },
  body: {
    color: COLORS.mutedInk,
    fontSize: 13,
    lineHeight: 21,
    marginTop: 8,
    maxWidth: 340,
    textAlign: "right",
  },
  stack: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    justifyContent: "space-between",
    marginTop: 19,
  },
  sectionTicker: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 14, borderWidth: 1, flexDirection: "row-reverse", marginTop: 12, minHeight: 42, overflow: "hidden" },
  sectionTickerLabel: { alignItems: "center", backgroundColor: COLORS.copperSoft, justifyContent: "center", minHeight: 42, paddingHorizontal: 10 },
  sectionTickerLabelText: { color: COLORS.copper, fontFamily: "Georgia", fontSize: 10, fontWeight: "900" },
  sectionTickerWindow: { flex: 1, overflow: "hidden" },
  sectionTickerTrack: { alignItems: "center", flexDirection: "row", minWidth: 1100 },
  sectionTickerItem: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 10, fontWeight: "800", paddingHorizontal: 12 },
  sectionLead: {
    color: COLORS.mutedInk,
    fontSize: 12,
    lineHeight: 20,
    marginTop: 5,
    textAlign: "right",
  },
  playlistShelf: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.line,
    borderRadius: 18,
    borderWidth: 1,
    marginTop: 15,
    padding: 11,
  },
  shelfHeader: {
    alignItems: "flex-start",
    flexDirection: "row-reverse",
    gap: 10,
    justifyContent: "space-between",
  },
  playlistShelfTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 17,
    fontWeight: "800",
    textAlign: "right",
  },
  playlistShelfMeta: {
    color: COLORS.mutedInk,
    fontSize: 10,
    lineHeight: 16,
    marginTop: 3,
    textAlign: "right",
  },
  playlistVideos: { gap: 10, marginTop: 10 },
  playlistLoading: { color: COLORS.mutedInk, fontSize: 11, marginTop: 12, textAlign: "right" },
  subHeading: {
    alignItems: "flex-end",
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 31,
  },
  subTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 20,
    fontWeight: "800",
    marginTop: 24,
    textAlign: "right",
  },
  subKicker: {
    color: COLORS.mutedInk,
    fontSize: 11,
    fontWeight: "700",
  },
  videoStack: {
    gap: 10,
    marginTop: 13,
  },
  sectionBlock: {
    paddingBottom: 20,
  },
  diaryGrid: {
    flexDirection: "row",
    gap: 11,
    marginTop: 21,
  },
  diaryCard: {
    backgroundColor: "#F5E5DA",
    borderColor: "#E4C2AF",
    borderRadius: 20,
    borderWidth: 1,
    flex: 1,
    minHeight: 175,
    padding: 15,
  },
  diaryCardOlive: {
    backgroundColor: "#EAE9D9",
    borderColor: "#D9D8C1",
  },
  diaryIcon: {
    color: COLORS.copper,
    fontSize: 26,
    marginBottom: 25,
    textAlign: "right",
  },
  diaryTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 18,
    fontWeight: "800",
    textAlign: "right",
  },
  diaryBody: {
    color: COLORS.mutedInk,
    fontSize: 11,
    marginTop: 4,
    textAlign: "right",
  },
  alertItem: {
    color: COLORS.ink,
    fontSize: 10,
    lineHeight: 16,
    marginTop: 8,
    textAlign: "right",
  },
  diaryAction: {
    color: COLORS.copper,
    fontSize: 11,
    fontWeight: "800",
    marginTop: 18,
    textAlign: "right",
  },
  comingSoon: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.line,
    borderRadius: 18,
    borderWidth: 1,
    marginTop: 13,
    padding: 17,
  },
  comingSoonTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 16,
    fontWeight: "800",
    textAlign: "right",
  },
  comingSoonBody: {
    color: COLORS.mutedInk,
    fontSize: 12,
    lineHeight: 19,
    marginTop: 5,
    textAlign: "right",
  },
  calendarCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.line,
    borderRadius: 20,
    borderWidth: 1,
    marginTop: 15,
    padding: 15,
  },
  calendarTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 19, fontWeight: "800", textAlign: "right" },
  monthsRow: { gap: 7, paddingTop: 12 },
  monthChip: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 10, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 8 },
  monthChipActive: { backgroundColor: COLORS.ink, borderColor: COLORS.ink },
  monthText: { color: COLORS.mutedInk, fontSize: 10, fontWeight: "800" },
  monthTextActive: { color: COLORS.paper },
  weekRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 15 },
  weekText: { color: COLORS.copper, flex: 1, fontSize: 9, fontWeight: "800", textAlign: "center" },
  daysGrid: { flexDirection: "row", flexWrap: "wrap", marginTop: 7 },
  dayCell: { alignItems: "center", borderRadius: 10, height: 37, justifyContent: "center", margin: 2, width: "13.3%" },
  daySelected: { backgroundColor: COLORS.copper },
  dayText: { color: COLORS.ink, fontSize: 12, fontWeight: "700" },
  daySelectedText: { color: COLORS.paper },
  calendarHint: { color: COLORS.mutedInk, fontSize: 10, marginTop: 12, textAlign: "right" },
  reminderBox: { backgroundColor: COLORS.paper, borderRadius: 14, marginTop: 12, padding: 11 },
  reminderTypes: { flexDirection: "row", gap: 6, marginTop: 8 },
  reminderType: { borderColor: COLORS.line, borderRadius: 9, borderWidth: 1, flex: 1, paddingVertical: 8 },
  reminderTypeActive: { backgroundColor: COLORS.ink, borderColor: COLORS.ink },
  reminderTypeText: { color: COLORS.mutedInk, fontSize: 10, textAlign: "center" },
  reminderTypeTextActive: { color: COLORS.paper, fontWeight: "800" },
  reminderLabel: { color: COLORS.ink, fontSize: 11, fontWeight: "800", textAlign: "right" },
  reminderInput: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 10, borderWidth: 1, color: COLORS.ink, fontSize: 11, marginTop: 8, padding: 10 },
  reminderButton: { alignItems: "center", backgroundColor: COLORS.olive, borderRadius: 10, marginTop: 8, paddingVertical: 9 },
  reminderButtonText: { color: COLORS.paper, fontSize: 11, fontWeight: "800" },
  subscriptionCard: {
    alignItems: "center",
    backgroundColor: COLORS.ink,
    borderRadius: 20,
    flexDirection: "row",
    gap: 10,
    marginTop: 22,
    padding: 14,
  },
  savedDiaryCard: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 18, borderWidth: 1, marginTop: 14, padding: 13 },
  savedDiaryTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 20, fontWeight: "800", textAlign: "right" },
  savedDiaryBody: { color: COLORS.mutedInk, fontSize: 11, marginTop: 4, textAlign: "right" },
  subscriptionBadge: {
    alignItems: "center",
    backgroundColor: COLORS.copper,
    borderRadius: 16,
    height: 42,
    justifyContent: "center",
    width: 42,
  },
  subscriptionBadgeText: {
    color: COLORS.paper,
    fontFamily: "Georgia",
    fontSize: 23,
    fontWeight: "800",
  },
  subscriptionCopy: {
    flex: 1,
  },
  subscriptionTitle: {
    color: COLORS.paper,
    fontFamily: "Georgia",
    fontSize: 15,
    fontWeight: "800",
    textAlign: "right",
  },
  subscriptionBody: {
    color: "#C5BBAE",
    fontSize: 10,
    lineHeight: 16,
    marginTop: 3,
    textAlign: "right",
  },
  subscribeButton: {
    backgroundColor: COLORS.paper,
    borderRadius: 11,
    paddingHorizontal: 10,
    paddingVertical: 9,
  },
  subscribeButtonText: {
    color: COLORS.ink,
    fontSize: 10,
    fontWeight: "800",
  },
  formCard: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.line,
    borderRadius: 15,
    borderWidth: 1,
    marginTop: 14,
    padding: 11,
  },
  formTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 16,
    fontWeight: "800",
    textAlign: "right",
  },
  servicesList: {
    backgroundColor: COLORS.white,
    borderColor: COLORS.line,
    borderRadius: 15,
    borderWidth: 1,
    marginTop: 14,
    paddingHorizontal: 11,
  },
  requestTracker: { backgroundColor: COLORS.midnightSoft, borderColor: "#C7D1D8", borderRadius: 15, borderWidth: 1, marginTop: 10, padding: 11 },
  requestTrackerTop: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between" },
  requestTrackerTitle: { color: COLORS.midnight, fontFamily: "Georgia", fontSize: 15, fontWeight: "800" },
  requestTrackerMeta: { color: COLORS.midnight, fontSize: 10, fontWeight: "800" },
  requestRow: { alignItems: "center", borderTopColor: "#C7D1D8", borderTopWidth: 1, flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 8, paddingTop: 8 },
  requestCopy: { flex: 1 },
  requestNumberCompact: { color: COLORS.ink, fontFamily: "monospace", fontSize: 10, fontWeight: "800", textAlign: "right" },
  requestType: { color: COLORS.mutedInk, fontSize: 9, marginTop: 2, textAlign: "right" },
  requestStatus: { color: COLORS.olive, fontSize: 9, fontWeight: "900", marginLeft: 8 },
  serviceItem: {
    alignItems: "center",
    flexDirection: "row",
    gap: 10,
    paddingVertical: 10,
  },
  serviceDivider: {
    borderBottomColor: COLORS.line,
    borderBottomWidth: 1,
    borderStyle: "dotted",
  },
  serviceIcon: {
    alignItems: "center",
    backgroundColor: "#F5E5DA",
    borderRadius: 12,
    height: 29,
    justifyContent: "center",
    width: 29,
  },
  serviceIconText: {
    color: COLORS.copper,
    fontSize: 14,
  },
  serviceCopy: {
    flex: 1,
  },
  serviceTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 13,
    fontWeight: "800",
    textAlign: "right",
  },
  serviceBody: {
    color: COLORS.mutedInk,
    fontSize: 10,
    lineHeight: 15,
    marginTop: 3,
    textAlign: "right",
  },
  formLabel: {
    color: COLORS.ink,
    fontSize: 13,
    fontWeight: "800",
    textAlign: "right",
  },
  input: {
    backgroundColor: COLORS.paper,
    borderColor: COLORS.line,
    borderRadius: 10,
    color: COLORS.ink,
    fontSize: 11,
    height: 38,
    lineHeight: 17,
    marginTop: 7,
    padding: 9,
  },
  detailsInput: {
    height: 82,
  },
  sendButton: {
    alignItems: "center",
    backgroundColor: COLORS.copper,
    borderRadius: 10,
    marginTop: 9,
    paddingVertical: 9,
  },
  sendButtonText: {
    color: COLORS.paper,
    fontSize: 12,
    fontWeight: "800",
  },
  disabledButton: {
    opacity: 0.62,
  },
  successBox: {
    alignItems: "center",
    backgroundColor: COLORS.white,
    borderColor: COLORS.line,
    borderRadius: 23,
    borderWidth: 1,
    marginTop: 28,
    padding: 23,
  },
  successMark: {
    alignItems: "center",
    backgroundColor: COLORS.olive,
    borderRadius: 30,
    color: COLORS.paper,
    fontSize: 28,
    height: 58,
    paddingTop: 10,
    textAlign: "center",
    width: 58,
  },
  successTitle: {
    color: COLORS.ink,
    fontFamily: "Georgia",
    fontSize: 23,
    fontWeight: "800",
    marginTop: 15,
  },
  successBody: {
    color: COLORS.mutedInk,
    fontSize: 12,
    lineHeight: 19,
    marginTop: 8,
    textAlign: "center",
  },
  requestNumberBox: {
    alignItems: "center",
    backgroundColor: "#F5E5DA",
    borderColor: "#E4C2AF",
    borderRadius: 14,
    marginTop: 20,
    paddingHorizontal: 25,
    paddingVertical: 12,
  },
  requestNumberLabel: {
    color: COLORS.copper,
    fontSize: 10,
    fontWeight: "800",
  },
  requestNumber: {
    color: COLORS.ink,
    fontFamily: "monospace",
    fontSize: 18,
    fontWeight: "800",
    marginTop: 4,
  },
  successHint: {
    color: COLORS.mutedInk,
    fontSize: 10,
    lineHeight: 16,
    marginTop: 17,
    textAlign: "center",
  },
  inlinePlayer: {
    backgroundColor: "#000",
    borderRadius: 15,
    height: 230,
    marginBottom: 12,
    overflow: "hidden",
    paddingTop: 20,
  },
  nowPlaying: {
    backgroundColor: "rgba(0,0,0,0.65)",
    color: COLORS.white,
    fontSize: 10,
    left: 9,
    paddingHorizontal: 7,
    paddingVertical: 4,
    position: "absolute",
    right: 9,
    textAlign: "right",
    top: 0,
    zIndex: 2,
  },
  webview: { flex: 1 },
  playerPlaceholder: {
    alignItems: "center",
    backgroundColor: COLORS.midnightSoft,
    borderRadius: 15,
    justifyContent: "center",
    marginBottom: 12,
    minHeight: 82,
  },
  playerPlaceholderText: { color: COLORS.midnight, fontSize: 11, fontWeight: "800" },
  freeServicesCard: { alignItems: "center", backgroundColor: COLORS.midnightSoft, borderColor: "#B7C5CF", borderRadius: 17, borderWidth: 1, flexDirection: "row-reverse", gap: 10, marginBottom: 12, padding: 12 },
  freeServicesIcon: { alignItems: "center", backgroundColor: COLORS.white, borderRadius: 13, height: 38, justifyContent: "center", width: 38 },
  freeServicesCopy: { flex: 1 },
  freeServicesTitle: { color: COLORS.midnight, fontFamily: "Georgia", fontSize: 16, fontWeight: "800", textAlign: "right" },
  freeServicesBody: { color: COLORS.mutedInk, fontSize: 10, lineHeight: 16, marginTop: 3, textAlign: "right" },
  pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
});
