import { useEffect, useState } from "react";
import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { COLORS } from "@/constants/nahshaliyat";
import { IconSymbol } from "@/components/ui/icon-symbol";
import * as Api from "@/lib/_core/api";

type Request = Awaited<ReturnType<typeof Api.getMyServiceRequests>>["requests"][number];
type Reminder = { id: number; title: string; remindAt: string };
export default function NotificationsScreen() {
  const [requests, setRequests] = useState<Request[]>([]); const [reminders, setReminders] = useState<Reminder[]>([]);
  useEffect(() => { void Api.getMyServiceRequests().then((r) => setRequests(r.requests)).catch(() => undefined); void Api.listReminders().then((r) => setReminders(r.reminders)).catch(() => undefined); }, []);
  const items = [...reminders.map((r) => ({ id: `r-${r.id}`, title: r.title, detail: new Date(r.remindAt).toLocaleString("ar-SA"), tone: "olive" as const, icon: "calendar" as const })), ...requests.map((r) => ({ id: `q-${r.id}`, title: `تحديث الطلب ${r.requestNumber}`, detail: `${statusLabel(r.status)} · ${r.requestType}`, tone: "copper" as const, icon: "business-center" as const }))];
  return <ScreenContainer containerClassName="bg-background" safeAreaClassName="bg-background"><ScrollView contentContainerStyle={styles.content}><Pressable onPress={() => router.back()} style={styles.back}><Text style={styles.backText}>→ العودة</Text></Pressable><View style={styles.header}><IconSymbol name="notifications" size={23} color={COLORS.copper} /><View><Text style={styles.kicker}>تنبيهاتك</Text><Text style={styles.title}>مركز الإشعارات</Text></View></View>{items.map((item) => <View key={item.id} style={styles.item}><View style={[styles.icon, item.tone === "olive" ? styles.olive : styles.copper]}><IconSymbol name={item.icon} size={19} color={COLORS.white} /></View><View style={styles.copy}><Text style={styles.itemTitle}>{item.title}</Text><Text style={styles.itemMeta}>{item.detail}</Text></View></View>)}{!items.length ? <View style={styles.empty}><IconSymbol name="check-circle" size={25} color={COLORS.olive} /><Text style={styles.emptyText}>لا توجد تنبيهات جديدة الآن.</Text></View> : null}</ScrollView></ScreenContainer>;
}
function statusLabel(status: Request["status"]) { return ({ new: "جديد", reviewing: "قيد المراجعة", contacted: "تم التواصل", completed: "مكتمل" })[status]; }
const styles = StyleSheet.create({ content: { backgroundColor: COLORS.paper, flexGrow: 1, padding: 16 }, back: { alignSelf: "flex-start", marginTop: 7 }, backText: { color: COLORS.copper, fontSize: 11, fontWeight: "800" }, header: { alignItems: "center", flexDirection: "row-reverse", gap: 10, marginTop: 22 }, kicker: { color: COLORS.copper, fontSize: 10, fontWeight: "900", textAlign: "right" }, title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 25, fontWeight: "800", marginTop: 2, textAlign: "right" }, item: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 15, borderWidth: 1, flexDirection: "row-reverse", gap: 10, marginTop: 10, padding: 12 }, icon: { alignItems: "center", borderRadius: 14, height: 34, justifyContent: "center", width: 34 }, copper: { backgroundColor: COLORS.copper }, olive: { backgroundColor: COLORS.olive }, copy: { flex: 1 }, itemTitle: { color: COLORS.ink, fontSize: 12, fontWeight: "800", textAlign: "right" }, itemMeta: { color: COLORS.mutedInk, fontSize: 9, marginTop: 4, textAlign: "right" }, empty: { alignItems: "center", gap: 9, marginTop: 60 }, emptyText: { color: COLORS.mutedInk, fontSize: 11 } });
