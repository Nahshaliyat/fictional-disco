import { describe, expect, it } from "vitest";
import { canReadAskMeHistory, canReadSponsorThread, isValidConversationMember } from "../server/_core/private-chat-access";

describe("خصوصية محادثات الأعضاء", () => {
  const sponsorId = 10;
  const memberId = 20;
  const otherMemberId = 30;

  it("يعرض سجل اسألني لصاحب الحساب والراعي فقط", () => {
    expect(canReadAskMeHistory(memberId, memberId, sponsorId)).toBe(true);
    expect(canReadAskMeHistory(sponsorId, memberId, sponsorId)).toBe(true);
    expect(canReadAskMeHistory(otherMemberId, memberId, sponsorId)).toBe(false);
    expect(canReadAskMeHistory(otherMemberId, memberId)).toBe(false);
  });

  it("يعزل محادثة راعي المجلس بين عضو بعينه والراعي", () => {
    expect(canReadSponsorThread(memberId, memberId, sponsorId)).toBe(true);
    expect(canReadSponsorThread(sponsorId, memberId, sponsorId)).toBe(true);
    expect(canReadSponsorThread(otherMemberId, memberId, sponsorId)).toBe(false);
    expect(canReadSponsorThread(otherMemberId, memberId)).toBe(false);
  });

  it("يرفض معرّفات المحادثات غير الصالحة ومحادثة الراعي مع نفسه", () => {
    expect(isValidConversationMember(memberId, sponsorId)).toBe(true);
    expect(isValidConversationMember(sponsorId, sponsorId)).toBe(false);
    expect(isValidConversationMember(NaN, sponsorId)).toBe(false);
    expect(isValidConversationMember(0, sponsorId)).toBe(false);
    expect(isValidConversationMember(1.2, sponsorId)).toBe(false);
  });
});
