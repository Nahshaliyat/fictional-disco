import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import express from "express";
import type { Server } from "node:http";

const fixtures = vi.hoisted(() => ({
  viewer: { id: 20, role: "user", email: "member@example.test" } as { id: number; role: string; email: string } | null,
  getMessages: vi.fn(async (id: number) => [{ id, memberId: id, senderId: id, body: `رسالة ${id}` }]),
  save: vi.fn(async (_input: { memberId: number; senderId: number; body: string }) => undefined),
  broadcast: vi.fn(),
}));

vi.mock("../server/db", () => ({
  getSponsorAccount: vi.fn(async () => ({ id: 10, email: "nahshaliyat@gmail.com", role: "admin" })),
  getUserById: vi.fn(async (id: number) => ({ id, role: "user" })),
  listSponsorMessages: fixtures.getMessages,
  listSponsorThreads: vi.fn(async () => [{ memberId: 20, memberName: "عضو", lastId: 1 }]),
  createSponsorMessage: fixtures.save,
}));
vi.mock("../server/_core/password-auth", () => ({ authenticateAnyRequest: vi.fn(async () => fixtures.viewer) }));
vi.mock("../server/_core/council-ws", () => ({ broadcastCouncilToUsers: fixtures.broadcast }));

import { registerSponsorChatRoutes } from "../server/_core/sponsor-chat";

let server: Server;
let base: string;

beforeEach(async () => {
  fixtures.viewer = { id: 20, role: "user", email: "member@example.test" };
  fixtures.getMessages.mockClear();
  fixtures.save.mockClear();
  fixtures.broadcast.mockClear();
  const app = express();
  registerSponsorChatRoutes(app);
  server = app.listen(0);
  await new Promise<void>((resolve) => server.once("listening", resolve));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("missing test port");
  base = `http://127.0.0.1:${address.port}`;
});

afterEach(async () => {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
});

describe("مسارات مراسلة الراعي الخاصة", () => {
  it("يتجاهل تغيير العضو لمعرّف المحادثة ويعرض له محادثته وحده", async () => {
    const response = await fetch(`${base}/api/council/sponsor/messages?memberId=30`);
    expect(response.status).toBe(200);
    expect((await response.json()).messages).toEqual([{ id: 20, memberId: 20, senderId: 20, body: "رسالة 20" }]);
    expect(fixtures.getMessages).toHaveBeenCalledWith(20);
  });

  it("يربط رسالة العضو بنفسه حتى إذا حاول توجيهها لغيره", async () => {
    const response = await fetch(`${base}/api/council/sponsor/messages`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ memberId: 30, body: "مرحبا" }),
    });
    expect(response.status).toBe(200);
    expect(fixtures.save).toHaveBeenCalledWith({ memberId: 20, senderId: 20, body: "مرحبا" });
    expect(fixtures.broadcast).toHaveBeenCalledWith([20, 10]);
  });

  it("لا يتيح قائمة المحادثات إلا للراعي الأساسي", async () => {
    expect((await fetch(`${base}/api/council/sponsor/threads`)).status).toBe(403);
    fixtures.viewer = { id: 40, role: "admin", email: "another@example.test" };
    expect((await fetch(`${base}/api/council/sponsor/messages?memberId=20`)).status).toBe(403);
    fixtures.viewer = { id: 10, role: "admin", email: "nahshaliyat@gmail.com" };
    expect((await fetch(`${base}/api/council/sponsor/threads`)).status).toBe(200);
    expect((await fetch(`${base}/api/council/sponsor/messages?memberId=20`)).status).toBe(200);
  });

  it("يرفض الوصول دون جلسة", async () => {
    fixtures.viewer = null;
    expect((await fetch(`${base}/api/council/sponsor/messages`)).status).toBe(401);
    expect((await fetch(`${base}/api/council/sponsor/messages`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ body: "رسالة" }) })).status).toBe(401);
  });
});
