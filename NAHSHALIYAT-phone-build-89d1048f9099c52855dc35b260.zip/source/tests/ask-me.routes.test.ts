import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import express from "express";
import type { Server } from "node:http";

const fixtures = vi.hoisted(() => ({
  viewer: { id: 20, role: "user", email: "member@example.test" } as { id: number; role: string; email: string } | null,
  history: vi.fn(async (id: number) => [{ id, userId: id, question: `سؤال ${id}`, answer: "إجابة" }]),
  save: vi.fn(async (_input: { userId: number; question: string; answer: string; inScope: boolean }) => undefined),
  model: vi.fn(),
}));

vi.mock("../server/db", () => ({
  getSponsorAccount: vi.fn(async () => ({ id: 10, email: "nahshaliyat@gmail.com", role: "admin" })),
  listAskMeMessages: fixtures.history,
  listAskMeThreads: vi.fn(async () => [{ memberId: 20, memberName: "عضو", lastId: 1 }]),
  createAskMeMessage: fixtures.save,
}));
vi.mock("../server/_core/password-auth", () => ({ authenticateAnyRequest: vi.fn(async () => fixtures.viewer) }));
vi.mock("../server/_core/llm", () => ({ invokeLLM: fixtures.model }));

import { registerAskMeRoutes } from "../server/_core/ask-me";

let server: Server;
let base: string;
beforeEach(async () => {
  fixtures.viewer = { id: 20, role: "user", email: "member@example.test" };
  fixtures.history.mockClear();
  fixtures.save.mockClear();
  fixtures.model.mockClear();
  const app = express();
  registerAskMeRoutes(app);
  server = app.listen(0);
  await new Promise<void>((resolve) => server.once("listening", resolve));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("missing test port");
  base = `http://127.0.0.1:${address.port}`;
});
afterEach(async () => {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
});

describe("خصوصية محادثة اسألني", () => {
  it("يعرض سجل العضو الحالي فقط ولو حاول إضافة معرّف عضو آخر", async () => {
    const response = await fetch(`${base}/api/ask-me/history?memberId=30`);
    expect(response.status).toBe(200);
    expect((await response.json()).messages[0].userId).toBe(20);
    expect(fixtures.history).toHaveBeenCalledWith(20);
  });

  it("يحجب قائمة الأسئلة وسجل العضو الآخر عن غير الراعي", async () => {
    expect((await fetch(`${base}/api/admin/ask-me/threads`)).status).toBe(403);
    expect((await fetch(`${base}/api/admin/ask-me/history/30`)).status).toBe(403);
    fixtures.viewer = { id: 40, role: "admin", email: "another@example.test" };
    expect((await fetch(`${base}/api/admin/ask-me/history/20`)).status).toBe(403);
    fixtures.viewer = { id: 10, role: "admin", email: "nahshaliyat@gmail.com" };
    expect((await fetch(`${base}/api/admin/ask-me/threads`)).status).toBe(200);
    const response = await fetch(`${base}/api/admin/ask-me/history/20`);
    expect(response.status).toBe(200);
    expect((await response.json()).messages[0].userId).toBe(20);
  });

  it("يحفظ السؤال المرفوض في سجل العضو ولا يرسله للنموذج", async () => {
    const response = await fetch(`${base}/api/ask-me`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: "كم سعر الذهب اليوم؟" }) });
    expect(response.status).toBe(200);
    expect((await response.json()).answer).toContain("راسل راعي المجلس");
    expect(fixtures.save).toHaveBeenCalledWith(expect.objectContaining({ userId: 20, inScope: false }));
    expect(fixtures.model).not.toHaveBeenCalled();
  });

  it("لا يسمح بالسؤال دون تسجيل الدخول", async () => {
    fixtures.viewer = null;
    expect((await fetch(`${base}/api/ask-me/history`)).status).toBe(401);
    expect((await fetch(`${base}/api/ask-me`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: "أقلام" }) })).status).toBe(401);
  });
});
