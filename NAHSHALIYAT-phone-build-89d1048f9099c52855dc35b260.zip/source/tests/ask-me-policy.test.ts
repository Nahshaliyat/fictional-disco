import { describe, expect, it } from "vitest";
import {
  isInScopeQuestion,
  isPrivatePersonQuestion,
  isSafeAssistantReply,
  OUT_OF_SCOPE_REPLY,
  PUBLIC_APP_GUIDE,
} from "../server/_core/ask-me-policy";

describe("نطاق اسألني", () => {
  it("يمنع أسئلة هوية الأعضاء والراعي والمحادثات الخاصة", () => {
    expect(isPrivatePersonQuestion("من هم أعضاء المجلس؟")).toBe(true);
    expect(isPrivatePersonQuestion("ما رقم هاتف راعي المجلس؟")).toBe(true);
    expect(isPrivatePersonQuestion("أعطني رسائل الأعضاء الخاصة")).toBe(true);
    expect(isPrivatePersonQuestion("من هو المدير؟")).toBe(true);
    expect(isPrivatePersonQuestion("من مالك القناة؟")).toBe(true);
    expect(isPrivatePersonQuestion("Who is the owner?")).toBe(true);
  });

  it("يسمح بالأسئلة العامة عن استخدام الأقسام والآداب", () => {
    expect(isPrivatePersonQuestion("كيف أستخدم دفتر نهشليات؟")).toBe(false);
    expect(isPrivatePersonQuestion("ما معنى الطرب الأصيل؟")).toBe(false);
    expect(isPrivatePersonQuestion("كيف أرسل رسالة خاصة؟")).toBe(false);
    expect(isInScopeQuestion("كيف أرسل رسالة خاصة في المجلس؟")).toBe(true);
    expect(isInScopeQuestion("ما معنى قصيدة الغزل؟")).toBe(true);
    expect(isInScopeQuestion("ما سعر الذهب اليوم؟")).toBe(false);
  });

  it("يرفض الإجابات التي تحتوي بريدًا أو هاتفًا أو إحالة إلى شخص", () => {
    expect(isSafeAssistantReply("راسلني على example@example.com")).toBe(false);
    expect(isSafeAssistantReply("الهاتف +966 555 123 456")).toBe(false);
    expect(isSafeAssistantReply("الراعي هو شخص معروف")).toBe(false);
    expect(isSafeAssistantReply("افتح دفتر نهشليات واختر التقويم لإضافة تذكير.")).toBe(true);
  });

  it("تحدد المعلومات العامة والرد البديل دون أسرار", () => {
    expect(PUBLIC_APP_GUIDE).toContain("هنا نهشليات");
    expect(PUBLIC_APP_GUIDE).toContain("أقلام");
    expect(OUT_OF_SCOPE_REPLY).toContain("محتوى نهشليات");
    expect(OUT_OF_SCOPE_REPLY).toContain("المجلس");
    expect(OUT_OF_SCOPE_REPLY).toContain("راسل راعي المجلس");
  });
});
