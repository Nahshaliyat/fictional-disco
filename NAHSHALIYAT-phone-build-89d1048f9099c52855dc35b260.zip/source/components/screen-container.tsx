import { KeyboardAvoidingView, Platform, StyleSheet, View, type ViewProps } from "react-native";
import { SafeAreaView, type Edge } from "react-native-safe-area-context";

import { COLORS } from "@/constants/nahshaliyat";
import { cn } from "@/lib/utils";

export interface ScreenContainerProps extends ViewProps {
  /**
   * SafeArea edges to apply. Defaults to ["top", "left", "right"].
   * Bottom is typically handled by Tab Bar.
   */
  edges?: Edge[];
  /**
   * Tailwind className for the content area.
   */
  className?: string;
  /**
   * Additional className for the outer container (background layer).
   */
  containerClassName?: string;
  /**
   * Additional className for the SafeAreaView (content layer).
   */
  safeAreaClassName?: string;
}

/**
 * A container component that properly handles SafeArea and background colors.
 *
 * The outer View extends to full screen (including status bar area) with the background color,
 * while the inner SafeAreaView ensures content is within safe bounds.
 *
 * Usage:
 * ```tsx
 * <ScreenContainer className="p-4">
 *   <Text className="text-2xl font-bold text-foreground">
 *     Welcome
 *   </Text>
 * </ScreenContainer>
 * ```
 */
export function ScreenContainer({
  children,
  edges = ["top", "left", "right"],
  className,
  containerClassName,
  safeAreaClassName,
  style,
  ...props
}: ScreenContainerProps) {
  return (
    <View
      className={cn(
        "flex-1",
        "bg-background",
        containerClassName
      )}
      {...props}
    >
      <View pointerEvents="none" style={styles.rainbowBackdrop}>
        <View style={[styles.rainbowOrb, styles.orbPeach]} />
        <View style={[styles.rainbowOrb, styles.orbLavender]} />
        <View style={[styles.rainbowOrb, styles.orbMint]} />
        <View style={[styles.rainbowOrb, styles.orbBlue]} />
        <View style={[styles.rainbowOrb, styles.orbRose]} />
      </View>
      <SafeAreaView
        edges={edges}
        className={cn("flex-1", safeAreaClassName)}
        style={[{ backgroundColor: "transparent" }, style]}
      >
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} className={cn("flex-1", className)}>
          {children}
        </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  rainbowBackdrop: { ...StyleSheet.absoluteFill, backgroundColor: COLORS.paper, overflow: "hidden" },
  rainbowOrb: { borderRadius: 180, height: 270, opacity: 0.3, position: "absolute", width: 270 },
  orbPeach: { backgroundColor: "#FFDCC8", left: -105, top: 70 },
  orbLavender: { backgroundColor: "#E3D8FF", right: -100, top: 210 },
  orbMint: { backgroundColor: "#D8F2E3", left: -120, top: 480 },
  orbBlue: { backgroundColor: "#D7E9FF", right: -120, top: 760 },
  orbRose: { backgroundColor: "#F7D8E5", left: 90, top: 1080 },
});
