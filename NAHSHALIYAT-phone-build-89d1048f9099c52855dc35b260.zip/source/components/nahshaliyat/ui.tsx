import { ActivityIndicator, Pressable, StyleSheet, Text, View } from "react-native";
import type { ReactNode } from "react";

import { COLORS } from "@/constants/nahshaliyat";
import { IconSymbol, type IconSymbolName } from "@/components/ui/icon-symbol";

export function SectionTitle({ kicker, title, action, onAction }: { kicker?: string; title: string; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.titleRow}>
      <View style={styles.titleAccent} />
      <View style={styles.titleCopy}>
        {kicker ? <Text style={styles.kicker}>{kicker}</Text> : null}
        <Text style={styles.title}>{title}</Text>
      </View>
      {action && onAction ? <Pressable onPress={onAction} style={styles.titleAction}><Text style={styles.titleActionText}>{action}</Text></Pressable> : null}
    </View>
  );
}

export function IconTile({ icon, label, tint = COLORS.copper, active = false, onPress }: { icon: IconSymbolName; label: string; tint?: string; active?: boolean; onPress?: () => void }) {
  const content = <><View style={[styles.iconTileCircle, { backgroundColor: active ? tint : `${tint}16` }]}><IconSymbol name={icon} size={21} color={active ? COLORS.white : tint} /></View><Text numberOfLines={2} style={[styles.iconTileLabel, active && { color: tint }]}>{label}</Text></>;
  return onPress ? <Pressable onPress={onPress} style={({ pressed }) => [styles.iconTile, active && styles.iconTileActive, pressed && styles.pressed]}>{content}</Pressable> : <View style={[styles.iconTile, active && styles.iconTileActive]}>{content}</View>;
}

export function StatusPill({ label, tone = "neutral" }: { label: string; tone?: "neutral" | "success" | "warning" | "error" }) {
  const color = tone === "success" ? COLORS.olive : tone === "warning" ? COLORS.copper : tone === "error" ? COLORS.error : COLORS.mutedInk;
  return <View style={[styles.pill, { backgroundColor: `${color}14`, borderColor: `${color}38` }]}><View style={[styles.pillDot, { backgroundColor: color }]} /><Text style={[styles.pillText, { color }]}>{label}</Text></View>;
}

export function NoticeBar({ message, tone = "neutral", onRetry }: { message: string; tone?: "neutral" | "error" | "success"; onRetry?: () => void }) {
  const color = tone === "error" ? COLORS.error : tone === "success" ? COLORS.olive : COLORS.mutedInk;
  return <View style={[styles.notice, { borderColor: `${color}35`, backgroundColor: `${color}0D` }]}><View style={[styles.noticeDot, { backgroundColor: color }]} /><Text style={[styles.noticeText, { color }]}>{message}</Text>{onRetry ? <Pressable onPress={onRetry} style={styles.retry}><Text style={styles.retryText}>إعادة</Text></Pressable> : null}</View>;
}

export function EmptyState({ icon = "auto-awesome", title, body, action, onAction }: { icon?: IconSymbolName; title: string; body?: string; action?: string; onAction?: () => void }) {
  return <View style={styles.empty}><View style={styles.emptyIcon}><IconSymbol name={icon} size={22} color={COLORS.copper} /></View><Text style={styles.emptyTitle}>{title}</Text>{body ? <Text style={styles.emptyBody}>{body}</Text> : null}{action && onAction ? <Pressable onPress={onAction} style={styles.emptyAction}><Text style={styles.emptyActionText}>{action}</Text></Pressable> : null}</View>;
}

export function PrimaryButton({ label, onPress, icon = "arrow-forward", disabled = false, tone = "copper" }: { label: string; onPress: () => void; icon?: IconSymbolName; disabled?: boolean; tone?: "copper" | "ink" | "olive" }) {
  const backgroundColor = tone === "ink" ? COLORS.ink : tone === "olive" ? COLORS.olive : COLORS.copper;
  return <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.primaryButton, { backgroundColor }, disabled && styles.disabled, pressed && styles.pressed]}><Text style={styles.primaryButtonText}>{label}</Text><IconSymbol name={icon} size={17} color={COLORS.white} /></Pressable>;
}

export function LoadingState({ label = "لحظة ونرتب لك المحتوى" }: { label?: string }) {
  return <View style={styles.loading}><ActivityIndicator color={COLORS.copper} /><Text style={styles.loadingText}>{label}</Text></View>;
}

export function SoftCard({ children, style }: { children: ReactNode; style?: object }) {
  return <View style={[styles.softCard, style]}>{children}</View>;
}

export function CardHeader({ icon, title, meta, tint = COLORS.copper }: { icon?: IconSymbolName; title: string; meta?: string; tint?: string }) {
  return <View style={styles.cardHeader}>{icon ? <View style={[styles.cardHeaderIcon, { backgroundColor: `${tint}16` }]}><IconSymbol name={icon} size={17} color={tint} /></View> : null}<View style={styles.cardHeaderCopy}><Text style={styles.cardHeaderTitle}>{title}</Text>{meta ? <Text style={styles.cardHeaderMeta}>{meta}</Text> : null}</View></View>;
}

export function DottedDivider({ color = COLORS.copperLine }: { color?: string }) {
  return <View style={[styles.dottedDivider, { borderColor: color }]} />;
}

const styles = StyleSheet.create({
  titleRow: { alignItems: "center", flexDirection: "row-reverse", gap: 9, marginTop: 20 },
  titleAccent: { backgroundColor: COLORS.copper, borderRadius: 4, height: 27, width: 4 },
  titleCopy: { flex: 1 },
  kicker: { color: COLORS.copper, fontSize: 10, fontWeight: "800", letterSpacing: 0.3, textAlign: "right" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 22, fontWeight: "800", lineHeight: 29, marginTop: 1, textAlign: "right" },
  titleAction: { paddingHorizontal: 5, paddingVertical: 6 },
  titleActionText: { color: COLORS.olive, fontSize: 10, fontWeight: "800" },
  iconTile: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 16, borderWidth: 1, flex: 1, justifyContent: "center", minHeight: 78, paddingHorizontal: 6, paddingVertical: 8 },
  iconTileActive: { backgroundColor: COLORS.copperSoft, borderColor: COLORS.copperLine },
  iconTileCircle: { alignItems: "center", borderRadius: 16, height: 38, justifyContent: "center", width: 38 },
  iconTileLabel: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 11, fontWeight: "800", lineHeight: 16, marginTop: 7, textAlign: "center" },
  pill: { alignItems: "center", borderRadius: 12, borderWidth: 1, flexDirection: "row-reverse", gap: 5, paddingHorizontal: 8, paddingVertical: 5 },
  pillDot: { borderRadius: 4, height: 6, width: 6 },
  pillText: { fontSize: 9, fontWeight: "800" },
  notice: { alignItems: "center", borderRadius: 13, borderWidth: 1, flexDirection: "row-reverse", gap: 8, marginTop: 12, paddingHorizontal: 10, paddingVertical: 9 },
  noticeDot: { borderRadius: 4, height: 7, width: 7 },
  noticeText: { flex: 1, fontSize: 11, lineHeight: 17, textAlign: "right" },
  retry: { borderColor: COLORS.line, borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 5 },
  retryText: { color: COLORS.ink, fontSize: 9, fontWeight: "800" },
  empty: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 18, borderWidth: 1, marginTop: 14, paddingHorizontal: 18, paddingVertical: 25 },
  emptyIcon: { alignItems: "center", backgroundColor: COLORS.copperSoft, borderRadius: 17, height: 42, justifyContent: "center", width: 42 },
  emptyTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 16, fontWeight: "800", marginTop: 10, textAlign: "center" },
  emptyBody: { color: COLORS.mutedInk, fontSize: 11, lineHeight: 17, marginTop: 5, textAlign: "center" },
  emptyAction: { backgroundColor: COLORS.ink, borderRadius: 10, marginTop: 12, paddingHorizontal: 12, paddingVertical: 8 },
  emptyActionText: { color: COLORS.paper, fontSize: 10, fontWeight: "800" },
  primaryButton: { alignItems: "center", borderRadius: 13, flexDirection: "row-reverse", gap: 8, justifyContent: "center", paddingHorizontal: 14, paddingVertical: 11 },
  primaryButtonText: { color: COLORS.white, fontSize: 11, fontWeight: "800" },
  softCard: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 16, borderWidth: 1, shadowColor: COLORS.ink, shadowOffset: { height: 2, width: 0 }, shadowOpacity: 0.035, shadowRadius: 8, elevation: 1 },
  cardHeader: { alignItems: "center", flexDirection: "row-reverse", gap: 8 },
  cardHeaderIcon: { alignItems: "center", borderRadius: 11, height: 30, justifyContent: "center", width: 30 },
  cardHeaderCopy: { flex: 1 },
  cardHeaderTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 15, fontWeight: "800", textAlign: "right" },
  cardHeaderMeta: { color: COLORS.mutedInk, fontSize: 9, marginTop: 2, textAlign: "right" },
  dottedDivider: { borderBottomWidth: 1, borderStyle: "dotted", marginVertical: 10, width: "100%" },
  loading: { alignItems: "center", gap: 8, justifyContent: "center", paddingVertical: 26 },
  loadingText: { color: COLORS.mutedInk, fontSize: 11 },
  disabled: { opacity: 0.5 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
});
