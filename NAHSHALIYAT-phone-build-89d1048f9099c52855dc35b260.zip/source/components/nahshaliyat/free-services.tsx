import AsyncStorage from "@react-native-async-storage/async-storage";
import { CameraView, useCameraPermissions } from "expo-camera";
import { useRouter } from "expo-router";
import * as FileSystem from "expo-file-system/legacy";
import * as ImageManipulator from "expo-image-manipulator";
import * as ImagePicker from "expo-image-picker";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";
import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { COLORS } from "@/constants/nahshaliyat";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { EmptyState, SectionTitle, SoftCard, StatusPill } from "@/components/nahshaliyat/ui";

type ScanPage = { uri: string; width: number; height: number; enhanced?: boolean };
type Expense = { id: string; amount: number; category: string; date: string; note: string; currency: string };
const EXPENSES_KEY = "nahshaliyat_expenses_v1";
const categories = ["طعام", "مواصلات", "فواتير", "تسوق", "أخرى"];
const currencies = ["ر.س", "دولار", "درهم", "جنيه"];

export function FreeServicesSection({ onBack }: { onBack?: () => void } = {}) {
  const router = useRouter();
  const [mode, setMode] = useState<"home" | "scanner" | "expenses">("home");
  if (mode === "scanner") return <DocumentScanner onBack={() => setMode("home")} />;
  if (mode === "expenses") return <ExpenseTracker onBack={() => setMode("home")} />;
  return <ScrollView nestedScrollEnabled contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    {onBack ? <BackHeader title="خدمات مجانية" onBack={onBack} /> : <SectionTitle kicker="أدوات يومية بسيطة" title="خدمات مجانية" />}
    <Text style={styles.lead}>أدوات عملية تعمل من هاتفك، بلا تعقيد وبواجهة عربية واضحة.</Text>
    <Pressable onPress={() => router.push("/(tabs)/ask-me")} style={styles.aiHint}><IconSymbol name="sparkles" size={18} color={COLORS.midnight} /><Text style={styles.aiHintText}>اسألني عن طريقة استخدام أي أداة داخل التطبيق ←</Text></Pressable>
    <Pressable onPress={() => setMode("scanner")} style={({ pressed }) => [styles.serviceCard, pressed && styles.pressed]}>
      <View style={[styles.serviceIcon, { backgroundColor: COLORS.copperSoft }]}><IconSymbol name="camera" size={23} color={COLORS.copper} /></View><View style={styles.serviceCopy}><Text style={styles.serviceTitle}>تصوير المستندات</Text><Text style={styles.serviceBody}>صوّر، حسّن الوضوح، حوّل إلى PDF وشارك الملف.</Text></View><IconSymbol name="arrow-back" size={18} color={COLORS.copper} />
    </Pressable>
    <Pressable onPress={() => setMode("expenses")} style={({ pressed }) => [styles.serviceCard, pressed && styles.pressed]}>
      <View style={[styles.serviceIcon, { backgroundColor: COLORS.oliveSoft }]}><IconSymbol name="receipt-long" size={23} color={COLORS.olive} /></View><View style={styles.serviceCopy}><Text style={styles.serviceTitle}>مصاريف</Text><Text style={styles.serviceBody}>سجّل مصروفك واعرف إجمالي اليوم والشهر والسنة.</Text></View><IconSymbol name="arrow-back" size={18} color={COLORS.olive} />
    </Pressable>
  </ScrollView>;
}

function BackHeader({ title, onBack }: { title: string; onBack: () => void }) {
  return <View style={styles.innerHeader}><Pressable onPress={onBack} style={styles.backButton}><IconSymbol name="arrow-forward" size={17} color={COLORS.copper} /><Text style={styles.backText}>خدمات مجانية</Text></Pressable><Text style={styles.innerTitle}>{title}</Text></View>;
}

function DocumentScanner({ onBack }: { onBack: () => void }) {
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef<CameraView>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [pages, setPages] = useState<ScanPage[]>([]);
  const [busy, setBusy] = useState(false);
  const [savedPdf, setSavedPdf] = useState("");
  const [cameraError, setCameraError] = useState("");

  async function capture() {
    if (!cameraRef.current) return;
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.9, skipProcessing: false });
      if (photo?.uri) setPages((current) => [...current, { uri: photo.uri, width: photo.width || 1200, height: photo.height || 1600 }]);
      setCameraOpen(false);
      setCameraError("");
    } catch {
      setCameraError("تعذر التقاط الصورة من الكاميرا. يمكنك اختيار صورة من الهاتف بدلًا من ذلك.");
    }
  }

  async function openCamera() {
    setCameraError("");
    if (!permission?.granted) {
      const result = await requestPermission();
      if (!result.granted) {
        setCameraError("لم يتم السماح باستخدام الكاميرا. افتح إعدادات الهاتف واسمح لـ NAHSHALIYAT باستخدام الكاميرا.");
        return;
      }
    }
    setCameraOpen(true);
  }

  async function chooseDocumentImage() {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: false, quality: 0.9 });
    if (result.canceled || !result.assets[0]) return;
    const image = result.assets[0];
    setPages((current) => [...current, { uri: image.uri, width: image.width || 1200, height: image.height || 1600 }]);
    setCameraError("");
  }

  async function improve(page: ScanPage) {
    setBusy(true);
    try {
      const width = Math.max(1, page.width);
      const height = Math.max(1, page.height);
      const side = Math.min(width, height);
      const crop = { originX: Math.floor((width - side) / 2), originY: Math.floor((height - side) / 2), width: side, height: side };
      const result = await ImageManipulator.manipulateAsync(page.uri, [{ crop }, { resize: { width: 1500 } }], { compress: 0.9, format: ImageManipulator.SaveFormat.JPEG });
      setPages((current) => current.map((item) => item.uri === page.uri ? { ...item, uri: result.uri, width: result.width, height: result.height, enhanced: true } : item));
    } catch { Alert.alert("تعذر تحسين الصورة", "حاول تصوير المستند مرة أخرى."); } finally { setBusy(false); }
  }

  async function exportPdf() {
    if (!pages.length) return;
    setBusy(true);
    try {
      const images = pages.map((page) => `<section><img src="${page.uri}" /></section>`).join("");
      const result = await Print.printToFileAsync({ html: `<html dir="rtl"><head><meta name="viewport" content="width=device-width" /><style>@page{margin:16px}body{background:#f5f0e7}section{page-break-after:always;text-align:center}img{max-width:100%;max-height:96vh;object-fit:contain}</style></head><body>${images}</body></html>`, base64: false });
      const filename = `nahshaliyat-document-${Date.now()}.pdf`;
      const destination = `${FileSystem.documentDirectory || FileSystem.cacheDirectory || ""}${filename}`;
      if (destination) { await FileSystem.copyAsync({ from: result.uri, to: destination }); setSavedPdf(destination); }
      if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(destination || result.uri, { mimeType: "application/pdf", dialogTitle: "مشاركة مستند نهشليات" });
    } catch { Alert.alert("تعذر إنشاء PDF", "تحقق من وجود صور ثم حاول مرة أخرى."); } finally { setBusy(false); }
  }

  if (cameraOpen) return <View style={styles.cameraPage}><CameraView style={styles.camera} facing="back" ref={cameraRef} onMountError={() => setCameraError("تعذر تشغيل الكاميرا على هذا الجهاز.")} /><View style={styles.cameraControls}>{cameraError ? <Text style={styles.cameraError}>{cameraError}</Text> : null}<Pressable onPress={() => setCameraOpen(false)} style={styles.cameraSecondary}><Text style={styles.cameraSecondaryText}>إلغاء</Text></Pressable><Pressable onPress={() => void capture()} style={styles.shutter}><View style={styles.shutterInner} /></Pressable><Pressable onPress={() => void chooseDocumentImage()} style={styles.cameraSecondary}><Text style={styles.cameraSecondaryText}>اختيار صورة</Text></Pressable></View></View>;
  return <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.flex}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}><BackHeader title="تصوير المستندات" onBack={onBack} /><Text style={styles.lead}>التقط صفحاتك، ثم حسّنها واجمعها في ملف PDF واحد.</Text><Pressable onPress={() => void openCamera()} style={styles.primaryButton}><IconSymbol name="camera" size={18} color={COLORS.white} /><Text style={styles.primaryText}>فتح الكاميرا</Text></Pressable><Pressable onPress={() => void chooseDocumentImage()} style={styles.secondaryButton}><IconSymbol name="photo-camera" size={17} color={COLORS.midnight} /><Text style={styles.secondaryText}>اختيار صورة من الهاتف</Text></Pressable>{cameraError ? <Text style={styles.formError}>{cameraError}</Text> : null}{pages.length ? <View style={styles.pagesBox}><View style={styles.sectionRow}><Text style={styles.boxTitle}>{pages.length} صفحة</Text><Text style={styles.boxMeta}>جاهزة للتحويل</Text></View>{pages.map((page, index) => <View key={`${page.uri}-${index}`} style={styles.pageRow}><Image source={{ uri: page.uri }} style={styles.thumb} /><View style={styles.pageCopy}><Text style={styles.pageTitle}>صفحة {index + 1}</Text><Text style={styles.pageMeta}>{page.enhanced ? "تم القص والتحسين" : "صورة أصلية"}</Text><Pressable disabled={busy} onPress={() => void improve(page)}><Text style={styles.linkText}>قص وتحسين</Text></Pressable></View><Pressable onPress={() => setPages((current) => current.filter((_, itemIndex) => itemIndex !== index))}><Text style={styles.removeText}>حذف</Text></Pressable></View>)}<Pressable disabled={busy} onPress={() => void exportPdf()} style={[styles.primaryButton, busy && styles.disabled]}><IconSymbol name="picture-as-pdf" size={18} color={COLORS.white} /><Text style={styles.primaryText}>{busy ? "جارٍ تجهيز PDF..." : "حفظ ومشاركة PDF"}</Text></Pressable>{savedPdf ? <Text style={styles.savedText}>حُفظ الملف على الهاتف وأصبح جاهزًا للمشاركة.</Text> : null}</View> : <EmptyState icon="camera" title="ابدأ بتصوير مستند" body="يمكنك إضافة أكثر من صفحة ثم تحويلها إلى ملف واحد." />}</ScrollView></KeyboardAvoidingView>;
}

function ExpenseTracker({ onBack }: { onBack: () => void }) {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState(categories[0]);
  const [note, setNote] = useState("");
  const [currency, setCurrency] = useState(currencies[0]);
  const [period, setPeriod] = useState<"day" | "month" | "year">("month");
  const [editingId, setEditingId] = useState<string | null>(null);
  useEffect(() => { AsyncStorage.getItem(EXPENSES_KEY).then((raw) => { if (raw) setExpenses(JSON.parse(raw)); }).catch(() => undefined); }, []);
  async function persist(next: Expense[]) { setExpenses(next); await AsyncStorage.setItem(EXPENSES_KEY, JSON.stringify(next)); }
  function matchesPeriod(date: string) { const now = new Date(); const item = new Date(date); if (period === "day") return item.toDateString() === now.toDateString(); if (period === "year") return item.getFullYear() === now.getFullYear(); return item.getFullYear() === now.getFullYear() && item.getMonth() === now.getMonth(); }
  const filtered = useMemo(() => expenses.filter((item) => matchesPeriod(item.date)).sort((a, b) => b.date.localeCompare(a.date)), [expenses, period]);
  const total = filtered.reduce((sum, item) => sum + item.amount, 0);
  async function saveExpense() { const value = Number(amount.replace(",", ".")); if (!Number.isFinite(value) || value <= 0) return; const nextItem: Expense = { id: editingId || `${Date.now()}`, amount: value, category, note: note.trim(), currency, date: editingId ? (expenses.find((item) => item.id === editingId)?.date || new Date().toISOString()) : new Date().toISOString() }; const next = editingId ? expenses.map((item) => item.id === editingId ? nextItem : item) : [nextItem, ...expenses]; await persist(next); setAmount(""); setNote(""); setEditingId(null); }
  function editExpense(item: Expense) { setEditingId(item.id); setAmount(String(item.amount)); setCategory(item.category); setNote(item.note); setCurrency(item.currency); }
  return <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.flex}><ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}><BackHeader title="مصاريف" onBack={onBack} /><View style={styles.totalCard}><Text style={styles.totalLabel}>إجمالي {period === "day" ? "اليوم" : period === "month" ? "الشهر" : "السنة"}</Text><Text style={styles.total}>{total.toFixed(2)} {filtered[0]?.currency || currency}</Text><View style={styles.periodRow}>{([['day', 'اليوم'], ['month', 'الشهر'], ['year', 'السنة']] as const).map(([id, label]) => <Pressable key={id} onPress={() => setPeriod(id)} style={[styles.periodButton, period === id && styles.periodActive]}><Text style={[styles.periodText, period === id && styles.periodActiveText]}>{label}</Text></Pressable>)}</View></View><View style={styles.expenseForm}><Text style={styles.boxTitle}>{editingId ? "تعديل مصروف" : "إضافة مصروف"}</Text><TextInput keyboardType="decimal-pad" onChangeText={setAmount} placeholder="القيمة" placeholderTextColor={COLORS.mutedInk} style={styles.expenseInput} textAlign="right" value={amount} /><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>{categories.map((item) => <Pressable key={item} onPress={() => setCategory(item)} style={[styles.chip, category === item && styles.chipActive]}><Text style={[styles.chipText, category === item && styles.chipTextActive]}>{item}</Text></Pressable>)}</ScrollView><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>{currencies.map((item) => <Pressable key={item} onPress={() => setCurrency(item)} style={[styles.currencyChip, currency === item && styles.currencyActive]}><Text style={styles.chipText}>{item}</Text></Pressable>)}</ScrollView><TextInput onChangeText={setNote} placeholder="ملاحظة اختيارية" placeholderTextColor={COLORS.mutedInk} style={styles.expenseInput} textAlign="right" value={note} /><Pressable onPress={() => void saveExpense()} style={styles.primaryButton}><Text style={styles.primaryText}>{editingId ? "حفظ التعديل" : "إضافة المصروف"}</Text></Pressable></View>{filtered.length ? <View style={styles.expenseList}>{filtered.map((item) => <View key={item.id} style={styles.expenseRow}><View style={styles.expenseActions}><Pressable onPress={() => editExpense(item)}><Text style={styles.linkText}>تعديل</Text></Pressable><Pressable onPress={() => void persist(expenses.filter((entry) => entry.id !== item.id))}><Text style={styles.removeText}>حذف</Text></Pressable></View><View style={styles.expenseCopy}><Text style={styles.expenseTitle}>{item.amount.toFixed(2)} {item.currency} · {item.category}</Text><Text style={styles.pageMeta}>{item.note || "بدون ملاحظة"} · {new Date(item.date).toLocaleDateString("ar-SA")}</Text></View></View>)}</View> : <EmptyState icon="receipt-long" title="لا توجد مصاريف" body="أضف أول مصروف لتظهر تقاريرك هنا." />}</ScrollView></KeyboardAvoidingView>;
}

const styles = StyleSheet.create({ flex: { flex: 1 }, content: { backgroundColor: COLORS.paper, flexGrow: 1, padding: 16, paddingBottom: 30 }, lead: { color: COLORS.mutedInk, fontSize: 12, lineHeight: 20, marginBottom: 14, textAlign: "right" }, aiHint: { alignItems: "center", backgroundColor: COLORS.midnightSoft, borderRadius: 13, flexDirection: "row-reverse", gap: 8, marginBottom: 12, padding: 10 }, aiHintText: { color: COLORS.midnight, flex: 1, fontSize: 10, lineHeight: 16, textAlign: "right" }, serviceCard: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, flexDirection: "row-reverse", gap: 11, marginTop: 9, padding: 13 }, serviceIcon: { alignItems: "center", borderRadius: 14, height: 42, justifyContent: "center", width: 42 }, serviceCopy: { flex: 1 }, serviceTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 16, fontWeight: "800", textAlign: "right" }, serviceBody: { color: COLORS.mutedInk, fontSize: 10, lineHeight: 16, marginTop: 3, textAlign: "right" }, pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] }, innerHeader: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between", marginBottom: 12 }, innerTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 24, fontWeight: "800", textAlign: "right" }, backButton: { alignItems: "center", flexDirection: "row-reverse", gap: 5 }, backText: { color: COLORS.copper, fontSize: 11, fontWeight: "800" }, primaryButton: { alignItems: "center", backgroundColor: COLORS.midnight, borderRadius: 14, flexDirection: "row-reverse", gap: 8, justifyContent: "center", marginTop: 12, minHeight: 46, paddingHorizontal: 15 }, primaryText: { color: COLORS.white, fontSize: 12, fontWeight: "900" }, secondaryButton: { alignItems: "center", backgroundColor: COLORS.midnightSoft, borderRadius: 14, flexDirection: "row-reverse", gap: 7, justifyContent: "center", marginTop: 8, minHeight: 42, paddingHorizontal: 15 }, secondaryText: { color: COLORS.midnight, fontSize: 11, fontWeight: "900" }, formError: { color: COLORS.error, fontSize: 10, lineHeight: 16, marginTop: 9, textAlign: "right" }, disabled: { opacity: 0.55 }, pagesBox: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, marginTop: 14, padding: 11 }, sectionRow: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between", marginBottom: 7 }, boxTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 16, fontWeight: "800", textAlign: "right" }, boxMeta: { color: COLORS.mutedInk, fontSize: 10 }, pageRow: { alignItems: "center", borderTopColor: COLORS.line, borderTopWidth: 1, flexDirection: "row-reverse", gap: 10, paddingVertical: 9 }, thumb: { backgroundColor: COLORS.paperDeep, borderRadius: 8, height: 60, width: 60 }, pageCopy: { flex: 1 }, pageTitle: { color: COLORS.ink, fontSize: 12, fontWeight: "800", textAlign: "right" }, pageMeta: { color: COLORS.mutedInk, fontSize: 9, marginTop: 3, textAlign: "right" }, linkText: { color: COLORS.midnight, fontSize: 10, fontWeight: "900", marginTop: 5, textAlign: "right" }, removeText: { color: COLORS.error, fontSize: 10, fontWeight: "900" }, savedText: { color: COLORS.olive, fontSize: 10, marginTop: 9, textAlign: "center" }, cameraPage: { backgroundColor: "#101315", flex: 1 }, camera: { flex: 1 }, cameraControls: { alignItems: "center", backgroundColor: "#101315", flexDirection: "row-reverse", justifyContent: "space-around", minHeight: 105, paddingHorizontal: 12 }, cameraSecondary: { padding: 10 }, cameraSecondaryText: { color: COLORS.white, fontSize: 11, fontWeight: "800" }, cameraError: { color: "#FFD7D0", flex: 1, fontSize: 9, lineHeight: 14, textAlign: "center" }, shutter: { alignItems: "center", borderColor: COLORS.white, borderRadius: 34, borderWidth: 4, height: 68, justifyContent: "center", width: 68 }, shutterInner: { backgroundColor: COLORS.copper, borderRadius: 25, height: 50, width: 50 }, cameraHint: { color: COLORS.white, fontSize: 10, textAlign: "center", width: 85 }, totalCard: { backgroundColor: COLORS.midnight, borderRadius: 19, marginBottom: 12, padding: 16 }, totalLabel: { color: "#DCE4EA", fontSize: 10, textAlign: "right" }, total: { color: COLORS.white, fontFamily: "Georgia", fontSize: 29, fontWeight: "800", marginTop: 5, textAlign: "right" }, periodRow: { flexDirection: "row-reverse", gap: 7, marginTop: 14 }, periodButton: { borderColor: "#657989", borderRadius: 9, borderWidth: 1, flex: 1, paddingVertical: 8 }, periodActive: { backgroundColor: COLORS.white, borderColor: COLORS.white }, periodText: { color: "#DCE4EA", fontSize: 10, fontWeight: "800", textAlign: "center" }, periodActiveText: { color: COLORS.midnight }, expenseForm: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, padding: 12 }, expenseInput: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 11, borderWidth: 1, color: COLORS.ink, fontSize: 13, marginTop: 10, minHeight: 43, paddingHorizontal: 12 }, chips: { gap: 7, paddingVertical: 10 }, chip: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 15, borderWidth: 1, paddingHorizontal: 11, paddingVertical: 7 }, chipActive: { backgroundColor: COLORS.copperSoft, borderColor: COLORS.copperLine }, currencyChip: { backgroundColor: COLORS.paperDeep, borderRadius: 15, paddingHorizontal: 11, paddingVertical: 7 }, currencyActive: { backgroundColor: COLORS.oliveSoft }, chipText: { color: COLORS.mutedInk, fontSize: 10, fontWeight: "800" }, chipTextActive: { color: COLORS.copper }, expenseList: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, marginTop: 12, paddingHorizontal: 12 }, expenseRow: { alignItems: "center", borderBottomColor: COLORS.line, borderBottomWidth: 1, flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 11 }, expenseCopy: { flex: 1 }, expenseTitle: { color: COLORS.ink, fontSize: 12, fontWeight: "900", textAlign: "right" }, expenseActions: { flexDirection: "row-reverse", gap: 10, marginLeft: 10 },
});
