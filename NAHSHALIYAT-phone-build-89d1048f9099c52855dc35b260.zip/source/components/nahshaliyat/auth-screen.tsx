import { useState } from "react";
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { BrandMark } from "@/components/nahshaliyat/brand-mark";
import { COLORS } from "@/constants/nahshaliyat";
import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";

export function AuthScreen({ onSuccess }: { onSuccess: () => Promise<void> | void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [method, setMethod] = useState<"email" | "phone">("email");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [dialCode, setDialCode] = useState("+966");
  const [phone, setPhone] = useState("");
  const [phoneCode, setPhoneCode] = useState("");
  const [phoneVerificationSent, setPhoneVerificationSent] = useState(false);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    setBusy(true); setError("");
    try {
      const fullPhone = method === "phone" ? `${dialCode}${phone}` : undefined;
      if (method === "phone" && !phoneVerificationSent) { await Api.requestPhoneCode(fullPhone || ""); setPhoneVerificationSent(true); setError("أرسلنا رمز تحقق إلى هاتفك؛ أدخله ثم اضغط متابعة"); return; }
      if (method === "phone") await Api.verifyPhoneCode(fullPhone || "", phoneCode);
      const result = mode === "login" ? await Api.loginWithEmail(method === "email" ? email : "", password, fullPhone, rememberMe) : await Api.registerWithEmail(name, method === "email" ? email : "", password, fullPhone, rememberMe);
      const user = result.user;
      await Auth.setSessionToken(result.sessionToken);
      await Auth.setUserInfo({ id: user.id, openId: user.openId, name: user.name, email: user.email, phone: user.phone, loginMethod: user.loginMethod, role: user.role, lastSignedIn: new Date(user.lastSignedIn) });
      await onSuccess();
    } catch (submitError) { setError(submitError instanceof Error ? submitError.message : "تعذر الاتصال بالخادم؛ تحقق من الإنترنت وحاول مرة أخرى"); } finally { setBusy(false); }
  }


  return <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}><ScrollView contentContainerStyle={styles.screen} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}><View style={styles.ornamentTop} /><View style={styles.card}><BrandMark /><Text style={styles.kicker}>مساحتك في نهشليات</Text><Text style={styles.title}>{mode === "login" ? "أهلًا بك من جديد" : "أنشئ حسابك"}</Text><Text style={styles.subtitle}>اختر طريقة التسجيل أو الدخول المناسبة لك.</Text><View style={styles.modeRow}><Pressable onPress={() => setMode("login")} style={[styles.modeButton, mode === "login" && styles.modeActive]}><Text style={[styles.modeText, mode === "login" && styles.modeActiveText]}>تسجيل الدخول</Text></Pressable><Pressable onPress={() => setMode("register")} style={[styles.modeButton, mode === "register" && styles.modeActive]}><Text style={[styles.modeText, mode === "register" && styles.modeActiveText]}>حساب جديد</Text></Pressable></View><View style={styles.methodRow}><Pressable onPress={() => { setMethod("email"); setPhoneVerificationSent(false); }} style={[styles.methodButton, method === "email" && styles.methodActive]}><Text style={[styles.methodText, method === "email" && styles.methodActiveText]}>البريد الإلكتروني</Text></Pressable><Pressable onPress={() => { setMethod("phone"); setPhoneVerificationSent(false); }} style={[styles.methodButton, method === "phone" && styles.methodActive]}><Text style={[styles.methodText, method === "phone" && styles.methodActiveText]}>رقم الهاتف</Text></Pressable></View>{mode === "register" ? <TextInput autoCapitalize="words" onChangeText={setName} placeholder="الاسم" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={name} /> : null}{method === "email" ? <TextInput autoCapitalize="none" keyboardType="email-address" onChangeText={setEmail} placeholder="البريد الإلكتروني" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={email} /> : <><View style={styles.phoneRow}><TextInput keyboardType="phone-pad" onChangeText={setDialCode} placeholder="+966" placeholderTextColor="#A59A8D" style={styles.dialInput} textAlign="center" value={dialCode} /><TextInput keyboardType="phone-pad" onChangeText={setPhone} placeholder="رقم الهاتف" placeholderTextColor="#A59A8D" style={styles.phoneInput} textAlign="right" value={phone} /></View>{phoneVerificationSent ? <TextInput keyboardType="number-pad" onChangeText={setPhoneCode} placeholder="رمز التحقق المكون من 6 أرقام" placeholderTextColor="#A59A8D" style={styles.input} textAlign="right" value={phoneCode} /> : null}</>}<View style={styles.passwordRow}><TextInput onChangeText={setPassword} placeholder="كلمة المرور (8 أحرف على الأقل)" placeholderTextColor="#A59A8D" secureTextEntry={!showPassword} style={styles.passwordInput} textAlign="right" value={password} /><Pressable accessibilityLabel={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"} onPress={() => setShowPassword((value) => !value)} style={styles.eyeButton}><MaterialIcons color={COLORS.mutedInk} name={showPassword ? "visibility-off" : "visibility"} size={22} /></Pressable></View><Pressable onPress={() => setRememberMe((value) => !value)} style={styles.remember}><Text style={styles.rememberBox}>{rememberMe ? "✓" : ""}</Text><Text style={styles.rememberText}>تذكرني</Text></Pressable>{error ? <Text style={styles.error}>{error}</Text> : null}<Pressable disabled={busy} onPress={submit} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed, busy && styles.disabled]}>{busy ? <ActivityIndicator color={COLORS.paper} /> : <Text style={styles.primaryText}>{method === "phone" && !phoneVerificationSent ? "إرسال رمز SMS  ←" : mode === "login" ? "دخول إلى نهشليات  ←" : "إنشاء الحساب  ←"}</Text>}</Pressable><Text style={styles.privacy}>بالتسجيل، توافق على حفظ بيانات حسابك وتفضيلاتك داخل تطبيق نهشليات.</Text></View></ScrollView></KeyboardAvoidingView>;
}

const styles = StyleSheet.create({
  screen: { alignItems: "center", backgroundColor: COLORS.paper, flex: 1, justifyContent: "center", padding: 18 },
  ornamentTop: { backgroundColor: COLORS.copper, borderRadius: 120, height: 220, opacity: 0.12, position: "absolute", right: -70, top: -70, width: 220 },
  card: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 26, borderWidth: 1, maxWidth: 440, padding: 22, width: "100%" },
  kicker: { color: COLORS.copper, fontSize: 11, fontWeight: "800", marginTop: 22, textAlign: "right" },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 29, fontWeight: "800", marginTop: 4, textAlign: "right" },
  subtitle: { color: COLORS.mutedInk, fontSize: 12, lineHeight: 20, marginTop: 8, textAlign: "right" },
  modeRow: { backgroundColor: COLORS.paper, borderRadius: 13, flexDirection: "row", gap: 5, marginTop: 20, padding: 4 },
  modeButton: { alignItems: "center", borderRadius: 10, flex: 1, paddingVertical: 10 },
  modeActive: { backgroundColor: COLORS.ink },
  modeText: { color: COLORS.mutedInk, fontSize: 12, fontWeight: "800" },
  modeActiveText: { color: COLORS.paper },
  methodRow: { flexDirection: "row", gap: 8, marginTop: 10 },
  methodButton: { alignItems: "center", borderColor: COLORS.line, borderRadius: 11, borderWidth: 1, flex: 1, paddingVertical: 9 },
  methodActive: { backgroundColor: "#F5E5DA", borderColor: "#D5A186" },
  methodText: { color: COLORS.mutedInk, fontSize: 10, fontWeight: "800" },
  methodActiveText: { color: COLORS.copper },
  input: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, color: COLORS.ink, fontSize: 13, marginTop: 10, paddingHorizontal: 13, paddingVertical: 12 },
  passwordRow: { alignItems: "center", backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, flexDirection: "row-reverse", marginTop: 10 },
  passwordInput: { color: COLORS.ink, flex: 1, fontSize: 13, paddingHorizontal: 13, paddingVertical: 12 },
  eyeButton: { alignItems: "center", justifyContent: "center", paddingHorizontal: 12, paddingVertical: 10 },
  phoneRow: { flexDirection: "row", gap: 8, marginTop: 10 },
  dialInput: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, color: COLORS.ink, fontSize: 13, paddingHorizontal: 8, width: 78 },
  phoneInput: { backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, color: COLORS.ink, flex: 1, fontSize: 13, paddingHorizontal: 13, paddingVertical: 12 },
  remember: { alignItems: "center", flexDirection: "row", gap: 7, justifyContent: "flex-end", marginTop: 11 },
  rememberBox: { alignItems: "center", backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 5, borderWidth: 1, color: COLORS.copper, fontSize: 13, height: 22, textAlign: "center", width: 22 },
  rememberText: { color: COLORS.mutedInk, fontSize: 11 },
  error: { color: "#B45445", fontSize: 11, lineHeight: 17, marginTop: 8, textAlign: "right" },
  primaryButton: { alignItems: "center", backgroundColor: COLORS.copper, borderRadius: 13, marginTop: 13, minHeight: 45, paddingVertical: 13 },
  primaryText: { color: COLORS.paper, fontSize: 12, fontWeight: "800" },
  pressed: { opacity: 0.76 },
  disabled: { opacity: 0.62 },
  divider: { alignItems: "center", flexDirection: "row", gap: 8, marginVertical: 18 },
  line: { backgroundColor: COLORS.line, flex: 1, height: 1 },
  dividerText: { color: COLORS.mutedInk, fontSize: 10 },
  providers: { flexDirection: "row", gap: 8 },
  provider: { alignItems: "center", borderColor: COLORS.line, borderRadius: 12, borderWidth: 1, flex: 1, paddingVertical: 9 },
  providerText: { color: COLORS.copper, fontSize: 17, fontWeight: "900" },
  providerLabel: { color: COLORS.mutedInk, fontSize: 9, marginTop: 3 },
  privacy: { color: COLORS.mutedInk, fontSize: 9, lineHeight: 15, marginTop: 16, textAlign: "center" },
});
