import { Linking, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { useState } from "react";
import { WebView } from "react-native-webview";

import { COLORS } from "@/constants/nahshaliyat";
import { getVideoUrl, normalizeVideoId } from "@/lib/youtube";
import { IconSymbol } from "@/components/ui/icon-symbol";

type Props = { videoId: string; title?: string; compact?: boolean };

export function YouTubePlayer({ videoId, title = "فيديو نهشليات", compact = false }: Props) {
  const [failed, setFailed] = useState(false);
  const id = normalizeVideoId(videoId);
  const embedUrl = `https://www.youtube.com/embed/${encodeURIComponent(id)}?playsinline=1&rel=0&modestbranding=1&controls=1&autoplay=1&origin=https%3A%2F%2Fwww.youtube.com&widget_referrer=https%3A%2F%2Fwww.youtube.com%2F`;
  const openExternal = () => void Linking.openURL(getVideoUrl(id));
  if (!id) return <PlayerFallback onOpen={openExternal} />;
  if (failed) return <PlayerFallback onOpen={openExternal} />;

  if (Platform.OS === "web") {
    return <View style={[styles.frame, compact && styles.compactFrame]}><iframe referrerPolicy="origin-when-cross-origin" src={embedUrl} title={title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen" allowFullScreen style={{ border: 0, height: "100%", width: "100%" }} /></View>;
  }

  return <View style={[styles.frame, compact && styles.compactFrame]}><WebView
    allowsFullscreenVideo
    allowsInlineMediaPlayback
    domStorageEnabled
    javaScriptEnabled
    javaScriptEnabledAndroid
    mediaPlaybackRequiresUserAction={false}
    mixedContentMode="always"
    onError={() => setFailed(true)}
    onHttpError={() => setFailed(true)}
    originWhitelist={["*"]}
    setSupportMultipleWindows={false}
    source={{ headers: { Referer: "https://www.youtube.com/" }, uri: embedUrl }}
    style={styles.webview}
    thirdPartyCookiesEnabled
  /><Pressable accessibilityRole="button" accessibilityLabel="فتح الفيديو في يوتيوب" onPress={openExternal} style={styles.externalButton}><IconSymbol name="arrow-back" size={13} color={COLORS.white} /><Text style={styles.externalText}>فتح في يوتيوب</Text></Pressable></View>;
}

function PlayerFallback({ onOpen }: { onOpen: () => void }) {
  return <View style={styles.fallback}><IconSymbol name="play-circle" size={28} color={COLORS.copper} /><Text style={styles.fallbackTitle}>تعذر تشغيل المشغل</Text><Pressable onPress={onOpen} style={styles.fallbackButton}><Text style={styles.fallbackButtonText}>فتح الفيديو في يوتيوب</Text></Pressable></View>;
}

const styles = StyleSheet.create({
  frame: { backgroundColor: "#111", borderRadius: 16, height: 230, overflow: "hidden", position: "relative", width: "100%" },
  compactFrame: { height: 190 },
  webview: { backgroundColor: "#111", flex: 1 },
  externalButton: { alignItems: "center", backgroundColor: "rgba(20,20,20,0.72)", borderRadius: 12, bottom: 8, flexDirection: "row-reverse", gap: 5, paddingHorizontal: 9, paddingVertical: 6, position: "absolute", right: 8 },
  externalText: { color: COLORS.white, fontSize: 9, fontWeight: "800" },
  fallback: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 16, borderWidth: 1, justifyContent: "center", minHeight: 190, padding: 18 },
  fallbackTitle: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 14, fontWeight: "800", marginTop: 8 },
  fallbackButton: { backgroundColor: COLORS.copper, borderRadius: 10, marginTop: 10, paddingHorizontal: 12, paddingVertical: 8 },
  fallbackButtonText: { color: COLORS.white, fontSize: 10, fontWeight: "800" },
});
