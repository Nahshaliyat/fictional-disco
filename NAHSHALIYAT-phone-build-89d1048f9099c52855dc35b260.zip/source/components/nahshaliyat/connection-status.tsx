import { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";

import * as Api from "@/lib/_core/api";
import { COLORS } from "@/constants/nahshaliyat";

export function ConnectionStatus() {
  const [online, setOnline] = useState<boolean | null>(null);
  useEffect(() => {
    let active = true;
    const check = async () => { const result = await Api.getHealthStatus().then((value) => value.ok).catch(() => false); if (active) setOnline(result); };
    void check();
    const timer = setInterval(() => void check(), 60_000);
    return () => { active = false; clearInterval(timer); };
  }, []);
  const label = online === null ? "جارٍ الفحص" : online ? "متصل" : "وضع عدم الاتصال";
  return <View style={styles.wrap}><View style={[styles.dot, online === true && styles.good, online === false && styles.bad]} /><Text style={styles.text}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  wrap: { alignItems: "center", flexDirection: "row-reverse", gap: 5, paddingHorizontal: 16, paddingTop: 4 },
  dot: { backgroundColor: COLORS.mutedInk, borderRadius: 4, height: 7, width: 7 },
  good: { backgroundColor: COLORS.olive },
  bad: { backgroundColor: COLORS.error },
  text: { color: COLORS.mutedInk, fontSize: 8, fontWeight: "800" },
});
