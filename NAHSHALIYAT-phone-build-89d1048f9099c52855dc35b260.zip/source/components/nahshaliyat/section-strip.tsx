import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { COLORS, topSections, type TopSectionId } from "@/constants/nahshaliyat";
import { IconSymbol } from "@/components/ui/icon-symbol";

type Props = { activeId?: TopSectionId; onSelect: (id: TopSectionId) => void };

export function SectionStrip({ activeId = "hena", onSelect }: Props) {
  return <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.content}>
    {topSections.map((section) => {
      const active = section.id === activeId;
      return <Pressable key={section.id} onPress={() => onSelect(section.id)} style={({ pressed }) => [styles.item, active && styles.activeItem, pressed && styles.pressed]}>
        <View style={[styles.iconWrap, active && styles.iconWrapActive]}><IconSymbol name={section.icon as never} size={18} color={active ? COLORS.white : COLORS.mutedInk} /></View>
        <Text style={[styles.label, active && styles.activeLabel]}>{section.label}</Text>
        {active ? <View style={styles.activeLine} /> : null}
      </Pressable>;
    })}
    <View style={styles.endSpace} />
  </ScrollView>;
}

const styles = StyleSheet.create({
  content: { gap: 8, paddingHorizontal: 16, paddingBottom: 10, paddingTop: 8 },
  item: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 15, borderWidth: 1, flexDirection: "row-reverse", gap: 7, minHeight: 40, paddingHorizontal: 10, position: "relative" },
  activeItem: { backgroundColor: COLORS.copperSoft, borderColor: COLORS.copperLine },
  iconWrap: { alignItems: "center", backgroundColor: COLORS.paper, borderRadius: 10, height: 26, justifyContent: "center", width: 26 },
  iconWrapActive: { backgroundColor: COLORS.copper },
  label: { color: COLORS.mutedInk, fontSize: 11, fontWeight: "800" },
  activeLabel: { color: COLORS.copper },
  activeLine: { backgroundColor: COLORS.copper, borderRadius: 2, bottom: -3, height: 3, left: 13, position: "absolute", width: 22 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.98 }] },
  endSpace: { width: 4 },
});
