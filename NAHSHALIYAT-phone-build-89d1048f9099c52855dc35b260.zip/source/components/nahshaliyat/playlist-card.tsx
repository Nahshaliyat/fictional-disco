import { Pressable, StyleSheet, Text, View } from "react-native";

import type { playlists } from "@/constants/nahshaliyat";
import { COLORS } from "@/constants/nahshaliyat";
import { IconSymbol } from "@/components/ui/icon-symbol";

type Playlist = (typeof playlists)[number];

export function PlaylistCard({ playlist, onSelect, active = false }: { playlist: Playlist; onSelect?: (playlist: Playlist) => void; active?: boolean }) {
  return <Pressable onPress={() => onSelect?.(playlist)} style={({ pressed }) => [styles.card, active && styles.activeCard, pressed && styles.pressed]}>
    <View style={[styles.iconCircle, { backgroundColor: active ? playlist.accent : `${playlist.accent}16` }]}><IconSymbol name={playlist.icon} size={21} color={active ? COLORS.white : playlist.accent} /></View>
    <Text numberOfLines={2} style={[styles.title, active && styles.activeTitle]}>{playlist.title}</Text>
    <Text style={styles.meta}>{playlist.countLabel}</Text>
  </Pressable>;
}

const styles = StyleSheet.create({
  card: { alignItems: "center", backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, flex: 1, justifyContent: "center", minHeight: 106, paddingHorizontal: 4, paddingVertical: 10 },
  activeCard: { backgroundColor: COLORS.copperSoft, borderColor: COLORS.copperLine },
  pressed: { opacity: 0.74, transform: [{ scale: 0.97 }] },
  iconCircle: { alignItems: "center", borderRadius: 17, height: 38, justifyContent: "center", width: 38 },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 11, fontWeight: "800", lineHeight: 16, marginTop: 7, textAlign: "center" },
  activeTitle: { color: COLORS.copper },
  meta: { color: COLORS.mutedInk, fontSize: 9, marginTop: 2, textAlign: "center" },
});
