import { Image, StyleSheet, Text, View } from "react-native";

import { COLORS } from "@/constants/nahshaliyat";

export function BrandMark({ compact = false }: { compact?: boolean }) {
  return <View style={styles.row}>
    <View style={[styles.mark, compact && styles.compactMark]}><Image source={require("@/assets/images/nahshaliyat-mark.png")} style={styles.image} /></View>
    {!compact ? <View style={styles.wordmark}><Text style={styles.kicker}>NAHSHALIYAT</Text><Text style={styles.title}>نهشليات</Text></View> : null}
  </View>;
}

const styles = StyleSheet.create({
  row: { alignItems: "center", flexDirection: "row-reverse", gap: 8 },
  mark: { alignItems: "center", backgroundColor: COLORS.copper, borderColor: COLORS.copperSoft, borderRadius: 16, borderWidth: 3, height: 43, justifyContent: "center", overflow: "hidden", width: 43 },
  compactMark: { borderRadius: 12, height: 35, width: 35 },
  image: { height: "100%", width: "100%" },
  wordmark: { alignItems: "flex-end" },
  kicker: { color: COLORS.copper, fontSize: 8, fontWeight: "900", letterSpacing: 1.8 },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 20, fontWeight: "800", lineHeight: 23 },
});
