import { Image, Pressable, StyleSheet, Text, View } from "react-native";
import { useState } from "react";
import { router } from "expo-router";

import { COLORS } from "@/constants/nahshaliyat";
import { getVideoThumbnail } from "@/lib/youtube";
import * as Api from "@/lib/_core/api";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { rememberWatchedVideo } from "@/lib/watch-history";

type Video = { id: string; title: string; meta: string; tag: string };

export function VideoCard({ video, compact = false, grid = false, onPlay }: { video: Video; compact?: boolean; grid?: boolean; onPlay?: (video: Video) => void }) {
  const [liked, setLiked] = useState(false);
  const [saving, setSaving] = useState(false);
  const [imageFailed, setImageFailed] = useState(false);
  async function toggleFavorite() {
    if (saving) return;
    const next = !liked;
    setLiked(next); setSaving(true);
    try { if (next) await Api.createFavorite({ videoId: video.id, title: video.title, meta: video.meta, tag: video.tag }); else await Api.removeFavorite(video.id); } catch { setLiked(!next); } finally { setSaving(false); }
  }
  return <View style={[styles.card, compact && styles.compactCard, grid && styles.gridCard]}>
    <Pressable onPress={() => { void rememberWatchedVideo(video); if (onPlay) onPlay(video); else router.push({ pathname: "/video/[videoId]", params: { videoId: video.id } }); }} style={({ pressed }) => [styles.content, grid && styles.gridContent, pressed && styles.pressed]}>
      <View style={[styles.thumbnailWrap, compact && styles.compactThumbnail, grid && styles.gridThumbnail]}>
        {imageFailed ? <View style={styles.fallbackThumb}><IconSymbol name="play-circle" size={25} color={COLORS.copper} /><Text style={styles.fallbackText}>فيديو نهشليات</Text></View> : <Image onError={() => setImageFailed(true)} source={{ uri: getVideoThumbnail(video.id) }} style={styles.thumbnail} />}
        <View style={styles.playBadge}><IconSymbol name="play-circle" size={15} color={COLORS.white} /></View>
      </View>
      <View style={styles.copy}><View style={styles.tagRow}><Text style={styles.tag}>{video.tag}</Text><Text style={styles.meta}>{video.meta}</Text></View><Text numberOfLines={2} style={styles.title}>{video.title}</Text><Text style={styles.watch}>تشغيل داخل التطبيق  ←</Text></View>
    </Pressable>
    <Pressable accessibilityLabel={liked ? "إزالة من المحفوظات" : "حفظ في محفوظاتي"} onPress={toggleFavorite} style={({ pressed }) => [styles.favorite, liked && styles.favoriteActive, pressed && styles.pressed]}><IconSymbol name={liked ? "favorite" : "favorite-border"} size={18} color={liked ? COLORS.copper : COLORS.mutedInk} /></Pressable>
  </View>;
}

const styles = StyleSheet.create({
  card: { backgroundColor: COLORS.white, borderColor: COLORS.line, borderRadius: 17, borderWidth: 1, minHeight: 104, overflow: "hidden", position: "relative", width: 310 },
  compactCard: { width: "100%" },
  gridCard: { minHeight: 160 },
  content: { alignItems: "center", flexDirection: "row-reverse", gap: 10, padding: 9 },
  gridContent: { flexDirection: "column", gap: 6, padding: 7 },
  pressed: { opacity: 0.76 },
  thumbnailWrap: { backgroundColor: COLORS.paperDeep, borderRadius: 12, height: 84, overflow: "hidden", position: "relative", width: 120 },
  compactThumbnail: { height: 88, width: 126 },
  gridThumbnail: { height: 72, width: "100%" },
  thumbnail: { height: "100%", width: "100%" },
  fallbackThumb: { alignItems: "center", flex: 1, justifyContent: "center", padding: 5 },
  fallbackText: { color: COLORS.mutedInk, fontSize: 8, marginTop: 4 },
  playBadge: { alignItems: "center", backgroundColor: "rgba(34,32,29,0.72)", borderRadius: 14, bottom: 6, left: 6, height: 25, justifyContent: "center", position: "absolute", width: 25 },
  copy: { flex: 1, justifyContent: "center", paddingRight: 2 },
  tagRow: { alignItems: "center", flexDirection: "row-reverse", justifyContent: "space-between" },
  tag: { color: COLORS.copper, fontSize: 10, fontWeight: "800" },
  meta: { color: COLORS.mutedInk, fontSize: 9 },
  title: { color: COLORS.ink, fontFamily: "Georgia", fontSize: 13, fontWeight: "800", lineHeight: 19, marginTop: 5, textAlign: "right" },
  watch: { color: COLORS.olive, fontSize: 9, fontWeight: "800", marginTop: 6, textAlign: "right" },
  favorite: { alignItems: "center", backgroundColor: COLORS.paper, borderColor: COLORS.line, borderRadius: 13, borderWidth: 1, bottom: 8, height: 27, justifyContent: "center", left: 8, position: "absolute", width: 27 },
  favoriteActive: { backgroundColor: COLORS.copperSoft, borderColor: COLORS.copperLine },
});
