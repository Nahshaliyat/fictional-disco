// Cross-platform icon wrapper using Material Icons on Android and web.
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "arrow-forward": "arrow-forward",
  "arrow-back": "arrow-back",
  "music-note": "music-note",
  "headphones": "headphones",
  "graphic-eq": "graphic-eq",
  "menu-book": "menu-book",
  "edit-note": "edit-note",
  "bookmark-border": "bookmark-border",
  "mail-outline": "mail-outline",
  "business-center": "business-center",
  "bookshelf": "collections-bookmark",
  "library-books": "library-books",
  "edit": "edit",
  "forum": "forum",
  "groups": "groups",
  "chat": "chat-bubble-outline",
  "support-agent": "support-agent",
  "help-outline": "help-outline",
  "auto-awesome": "auto-awesome",
  "calendar": "calendar-month",
  "notifications": "notifications-none",
  "refresh": "refresh",
  "search": "search",
  "wifi-off": "wifi-off",
  "person": "person-outline",
  "logout": "logout",
  "admin-panel-settings": "admin-panel-settings",
  "shield": "shield",
  "lock": "lock-outline",
  "favorite": "favorite",
  "favorite-border": "favorite-border",
  "play-circle": "play-circle-outline",
  "check-circle": "check-circle-outline",
  "warning-amber": "warning-amber",
  "more-horiz": "more-horiz",
  "close": "close",
  "photo-camera": "photo-camera",
  "camera": "photo-camera",
  "sparkles": "auto-awesome",
  "receipt-long": "receipt-long",
  "picture-as-pdf": "picture-as-pdf",
  "cloud-done": "cloud-done",
} as const;

export type IconSymbolName = keyof typeof MAPPING;
type MaterialIconName = ComponentProps<typeof MaterialIcons>["name"];

export function IconSymbol({ name, size = 24, color, style }: { name: IconSymbolName; size?: number; color: string | OpaqueColorValue; style?: StyleProp<TextStyle>; weight?: SymbolWeight }) {
  return <MaterialIcons color={color} size={Math.max(14, size - 2)} name={MAPPING[name] as MaterialIconName} style={style} />;
}
