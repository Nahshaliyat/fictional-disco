import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "music-note": "music-note",
  "edit-note": "edit-note",
  "bookmark-border": "bookmark-border",
  "mail-outline": "mail-outline",
  "business-center": "business-center",
  "bookshelf": "collections-bookmark",
  "edit": "edit",
  "forum": "forum",
  "help-outline": "help-outline",
  "calendar": "calendar-month",
  "notifications": "notifications-none",
} as const;

type IconSymbolName = keyof typeof MAPPING;
type MaterialIconName = ComponentProps<typeof MaterialIcons>["name"];

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
}) {
  return (
    <MaterialIcons
      color={color}
      size={size}
      name={MAPPING[name] as MaterialIconName}
      style={style}
    />
  );
}
