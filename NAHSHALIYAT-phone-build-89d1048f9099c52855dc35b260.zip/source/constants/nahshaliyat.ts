export const CHANNEL_HANDLE = "@Nahshaliyat";
export const CHANNEL_URL = "https://youtube.com/@nahshaliyat";
export const CHANNEL_ARTWORK_URL = "/manus-storage/async-images/RltjHF91sZNeuX31Bzky5z/image-1.webp";

export const COLORS = {
  paper: "rgba(245,240,231,0.88)",
  paperDeep: "rgba(233,224,212,0.88)",
  ink: "#24221F",
  mutedInk: "#777066",
  copper: "#A95E3F",
  copperSoft: "#F3E1D6",
  copperLine: "#D6A990",
  olive: "#65715C",
  oliveSoft: "#E5E9DF",
  midnight: "#394B5A",
  midnightSoft: "#E4E9ED",
  line: "#DED5CA",
  white: "rgba(255,253,248,0.94)",
  error: "#A94B42",
};

export const topSections = [
  { id: "hena", label: "هنا نهشليات", icon: "music-note", description: "طرب، قصائد، وشيلات نهشليات" },
  { id: "diary", label: "دفتر نهشليات", icon: "edit-note", description: "تنبيهاتك ومواعيدك في مكان واحد" },
  { id: "services", label: "خدماتنا", icon: "business-center", description: "اطلب خدمة تناسب فكرتك ومناسبتك" },
] as const;
export type TopSectionId = (typeof topSections)[number]["id"];

export const playlists = [
  { id: "tarab", title: "طرب نهشليات", sourceTitle: "طرب نهشليات", countLabel: "مقاطع طربية", playlistId: "PLXioqOdT6ZAk", featuredVideoId: "ZCB4H4t_uwg", description: "أغانٍ طربية أصيلة بصوت نهشليات.", accent: COLORS.copper, icon: "headphones" as const },
  { id: "sheilat", title: "شيلات نهشليات", sourceTitle: "شيلات نهشلية", countLabel: "شيلات مختارة", playlistId: "PLW0vB9fiTiXs", featuredVideoId: "Zx2o2DIhgG8", description: "شيلات مختارة من أرشيف نهشليات.", accent: COLORS.olive, icon: "graphic-eq" as const },
  { id: "qasayed", title: "قصائد نهشليات", sourceTitle: "قصائد نهشليات", countLabel: "قصائد صوتية", playlistId: "PLdB1aJ-b9O9M", featuredVideoId: "ibXJl6YIL58", description: "قصائد تحمل الحرف والحنين.", accent: "#876A53", icon: "menu-book" as const },
] as const;

export const featuredVideos = [
  { id: "CxcPUViaqzU", title: "أَتَيْتُكِ وَالأَنْفَاسُ يَأْكُلُهَا التَعَبُ", meta: "جديد · 3:05", tag: "قصائد" },
  { id: "cm9DENgP86w", title: "لَسْتُ مِمَّنْ يَرْتَضِي فِي الحُبِّ وُدِّي", meta: "منذ يوم · 2:44", tag: "قصائد" },
  { id: "ibXJl6YIL58", title: "تَرَاكَمَ الخَوْفُ فِي صَدْرِي، فَأَوْجَعَنِي", meta: "منذ أسبوع · 4:05", tag: "قصائد" },
  { id: "ggrI4cJqb-4", title: "تَعِبْتُ أُفَتِّشُ عَنْكِ، أَفِرُّ إِلَى لَيَالِيكِ الرَّقِيقَةْ", meta: "منذ 8 أيام · 3:20", tag: "طرب" },
  { id: "ttSCRiTGTCc", title: "كَأَنَّ الْحَرْفَ يَعْجَزُ إِذْ يَرَاكِي", meta: "منذ 10 أيام · 4:44", tag: "قصائد" },
  { id: "3PeqEz94xkw", title: "رسمت الحب محرابا لقلبي", meta: "منذ 12 يومًا · 4:05", tag: "طرب" },
] as const;
export const playlistVideos = { tarab: [featuredVideos[3], featuredVideos[5]], sheilat: [{ id: "Zx2o2DIhgG8", title: "شيلات نهشليات", meta: "شيلة · تشغيل داخل التطبيق", tag: "شيلات" }], qasayed: [featuredVideos[0], featuredVideos[1], featuredVideos[2], featuredVideos[4]] } as const;
export const savedVideos = [featuredVideos[4], featuredVideos[5]];
export const dailyMessages = [
  { text: "حين يصدق الصوت، يجد الحرف طريقه إلى القلب قبل أن يكتمل البيت.", sourceId: "CxcPUViaqzU", sourceTitle: "أَتَيْتُكِ وَالأَنْفَاسُ يَأْكُلُهَا التَعَبُ" },
  { text: "خذ من القصيدة هدوءها، ومن الطرب نافذة تعيد ترتيب يومك.", sourceId: "ggrI4cJqb-4", sourceTitle: "تَعِبْتُ أُفَتِّشُ عَنْكِ" },
  { text: "كل شيلة تحمل موعدًا مع ذاكرة لا تريد أن تُنسى.", sourceId: "Zx2o2DIhgG8", sourceTitle: "شيلات نهشليات" },
  { text: "قد يكون البيت الذي تسمعه اليوم هو الرسالة التي انتظرتها طويلًا.", sourceId: "ibXJl6YIL58", sourceTitle: "تَرَاكَمَ الخَوْفُ فِي صَدْرِي" },
];
