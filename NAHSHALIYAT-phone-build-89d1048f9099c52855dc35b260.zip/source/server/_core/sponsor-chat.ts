import express, { type Express, type Request, type Response } from "express";
import { createSponsorMessage, getSponsorAccount, getUserById, listSponsorMessages, listSponsorThreads } from "../db";
import { authenticateAnyRequest } from "./password-auth";
import { canReadSponsorThread, isValidConversationMember } from "./private-chat-access";
import { broadcastCouncilToUsers } from "./council-ws";

export function registerSponsorChatRoutes(app: Express) {
  app.get("/api/council/sponsor/threads", async (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    const viewer = await authenticateAnyRequest(req);
    const sponsor = await getSponsorAccount();
    if (!viewer || !sponsor || viewer.id !== sponsor.id) {
      res.status(403).json({ error: "المحادثات للراعي فقط" }); return;
    }
    try { res.json({ threads: await listSponsorThreads() }); }
    catch { res.status(503).json({ error: "تعذر تحميل المحادثات" }); }
  });

  app.get("/api/council/sponsor/messages", async (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    const viewer = await authenticateAnyRequest(req);
    if (!viewer) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const sponsor = await getSponsorAccount();
    if (!sponsor) { res.status(503).json({ error: "مراسلة الراعي غير متاحة حاليًا" }); return; }
    if (viewer.role === "admin" && viewer.id !== sponsor.id) { res.status(403).json({ error: "هذه المحادثة خاصة" }); return; }
    const memberId = viewer.id === sponsor.id ? Number(req.query.memberId) : viewer.id;
    if (!isValidConversationMember(memberId, sponsor.id) || !canReadSponsorThread(viewer.id, memberId, sponsor.id)) {
      res.status(403).json({ error: "هذه المحادثة خاصة" }); return;
    }
    try { res.json({ messages: await listSponsorMessages(memberId) }); }
    catch { res.status(503).json({ error: "تعذر تحميل المحادثة" }); }
  });

  app.post("/api/council/sponsor/messages", express.json({ limit: "8kb" }), async (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    const viewer = await authenticateAnyRequest(req);
    if (!viewer) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const sponsor = await getSponsorAccount();
    if (!sponsor) { res.status(503).json({ error: "مراسلة الراعي غير متاحة حاليًا" }); return; }
    if (viewer.role === "admin" && viewer.id !== sponsor.id) { res.status(403).json({ error: "هذه المحادثة خاصة" }); return; }
    const memberId = viewer.id === sponsor.id ? Number(req.body?.memberId) : viewer.id;
    if (!isValidConversationMember(memberId, sponsor.id) || !canReadSponsorThread(viewer.id, memberId, sponsor.id)) {
      res.status(403).json({ error: "هذه المحادثة خاصة" }); return;
    }
    const body = typeof req.body?.body === "string" ? req.body.body.trim() : "";
    if (!body || body.length > 1000) { res.status(400).json({ error: "اكتب رسالة لا تتجاوز 1000 حرف" }); return; }
    try {
      if (viewer.id === sponsor.id) {
        const recipient = await getUserById(memberId);
        if (!recipient || recipient.role !== "user") { res.status(400).json({ error: "المحادثة غير صالحة" }); return; }
      }
      await createSponsorMessage({ memberId, senderId: viewer.id, body });
      broadcastCouncilToUsers([memberId, sponsor.id]);
      res.json({ success: true });
    } catch { res.status(503).json({ error: "تعذر إرسال الرسالة" }); }
  });
}
