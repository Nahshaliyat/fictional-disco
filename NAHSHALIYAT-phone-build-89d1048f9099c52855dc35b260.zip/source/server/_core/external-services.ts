import crypto from "node:crypto";

export type OAuthProvider = "google" | "microsoft" | "facebook";

export function externalServiceStatus() {
  return {
    google: Boolean(process.env.NAHSHALIYAT_GOOGLE_CLIENT_ID && process.env.NAHSHALIYAT_GOOGLE_CLIENT_SECRET),
    microsoft: Boolean(process.env.NAHSHALIYAT_MICROSOFT_CLIENT_ID && process.env.NAHSHALIYAT_MICROSOFT_CLIENT_SECRET),
    facebook: Boolean(process.env.NAHSHALIYAT_FACEBOOK_APP_ID && process.env.NAHSHALIYAT_FACEBOOK_APP_SECRET),
    sms: Boolean(process.env.NAHSHALIYAT_TWILIO_ACCOUNT_SID && process.env.NAHSHALIYAT_TWILIO_AUTH_TOKEN && process.env.NAHSHALIYAT_TWILIO_FROM_NUMBER),
    email: Boolean(process.env.NAHSHALIYAT_RESEND_API_KEY && process.env.NAHSHALIYAT_RESEND_FROM),
    youtube: Boolean(process.env.NAHSHALIYAT_YOUTUBE_API_KEY),
  };
}

export function hashVerificationCode(code: string) {
  return crypto.createHash("sha256").update(code).digest("hex");
}

export function createVerificationCode() {
  return String(crypto.randomInt(100000, 1000000));
}

export async function sendSmsCode(phone: string, code: string) {
  const status = externalServiceStatus();
  if (!status.sms) throw new Error("خدمة SMS غير مهيأة؛ أضف مفاتيح Twilio من إعدادات الأسرار");
  const sid = process.env.NAHSHALIYAT_TWILIO_ACCOUNT_SID!;
  const token = process.env.NAHSHALIYAT_TWILIO_AUTH_TOKEN!;
  const body = new URLSearchParams({ To: phone, From: process.env.NAHSHALIYAT_TWILIO_FROM_NUMBER!, Body: `رمز تحقق نهشليات: ${code}` });
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, { method: "POST", headers: { Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`, "Content-Type": "application/x-www-form-urlencoded" }, body });
  if (!response.ok) throw new Error("تعذر إرسال رمز التحقق عبر SMS");
}

export async function sendServiceEmail(input: { to: string; subject: string; text: string }) {
  const status = externalServiceStatus();
  if (!status.email) return { sent: false, reason: "email_provider_not_configured" };
  const response = await fetch("https://api.resend.com/emails", { method: "POST", headers: { Authorization: `Bearer ${process.env.NAHSHALIYAT_RESEND_API_KEY!}`, "Content-Type": "application/json" }, body: JSON.stringify({ from: process.env.NAHSHALIYAT_RESEND_FROM!, to: [input.to], subject: input.subject, text: input.text }) });
  if (!response.ok) throw new Error("تعذر إرسال البريد من الخادم");
  return { sent: true };
}

export function getOAuthProviderConfig(provider: OAuthProvider) {
  if (provider === "google") return { clientId: process.env.NAHSHALIYAT_GOOGLE_CLIENT_ID, authorizeUrl: "https://accounts.google.com/o/oauth2/v2/auth", scope: "openid email profile" };
  if (provider === "microsoft") return { clientId: process.env.NAHSHALIYAT_MICROSOFT_CLIENT_ID, authorizeUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize", scope: "openid email profile User.Read" };
  return { clientId: process.env.NAHSHALIYAT_FACEBOOK_APP_ID, authorizeUrl: "https://www.facebook.com/v20.0/dialog/oauth", scope: "email,public_profile" };
}

export async function syncYouTubePlaylists() {
  const key = process.env.NAHSHALIYAT_YOUTUBE_API_KEY;
  if (!key) throw new Error("YouTube Data API غير مهيأ؛ أضف المفتاح من إعدادات الأسرار");
  const channelResponse = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=%40Nahshaliyat&key=${encodeURIComponent(key)}`);
  if (!channelResponse.ok) throw new Error("تعذر العثور على قناة نهشليات");
  const channelData = await channelResponse.json() as { items?: Array<{ id: string }> };
  const channelId = channelData.items?.[0]?.id;
  if (!channelId) throw new Error("لم تُرجع YouTube معرف قناة نهشليات");
  const playlistsResponse = await fetch(`https://www.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&channelId=${channelId}&maxResults=50&key=${encodeURIComponent(key)}`);
  if (!playlistsResponse.ok) throw new Error("تعذر مزامنة قوائم تشغيل نهشليات");
  const data = await playlistsResponse.json() as { items?: Array<{ id: string; snippet?: { title?: string; thumbnails?: { medium?: { url?: string } } }; contentDetails?: { itemCount?: number } }> };
  return (data.items ?? []).map((item) => ({ playlistId: item.id, title: item.snippet?.title ?? "قائمة نهشليات", thumbnailUrl: item.snippet?.thumbnails?.medium?.url, itemCount: item.contentDetails?.itemCount ?? 0 }));
}

export async function fetchYouTubePlaylistVideos(playlistId: string) {
  if (!/^[A-Za-z0-9_-]+$/.test(playlistId)) throw new Error("معرّف قائمة يوتيوب غير صالح");
  const response = await fetch(`https://www.youtube.com/playlist?list=${playlistId}`, { headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/128 Safari/537.36", Accept: "text/html,application/xhtml+xml" } });
  if (!response.ok) throw new Error("تعذر جلب فيديوهات قائمة نهشليات");
  const html = await response.text();
  const initialData = html.match(/var ytInitialData = (\{.*?\});<\/script>/s)?.[1] ?? html.match(/<script[^>]*>ytInitialData\s*=\s*(\{.*?\});<\/script>/s)?.[1];
  if (!initialData) throw new Error("لم تُرجع يوتيوب محتوى القائمة");
  const data = JSON.parse(initialData) as unknown;
  const videos: Array<{ id: string; title: string; meta: string; tag: string }> = [];
  const seen = new Set<string>();
  const textContent = (value: unknown): string => {
    if (!value || typeof value !== "object") return "";
    const record = value as Record<string, unknown>;
    if (typeof record.content === "string") return record.content.trim();
    if (typeof record.simpleText === "string") return record.simpleText.trim();
    if (Array.isArray(record.runs)) return record.runs.map((run) => textContent(run)).join("").trim();
    return "";
  };
  const visit = (value: unknown) => {
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) { value.forEach(visit); return; }
    const record = value as Record<string, unknown>;
    const lockup = record.lockupViewModel as Record<string, unknown> | undefined;
    if (lockup && typeof lockup.contentId === "string" && lockup.contentType === "LOCKUP_CONTENT_TYPE_VIDEO" && !seen.has(lockup.contentId)) {
      const metadata = lockup.metadata as Record<string, unknown> | undefined;
      const lockupMetadata = metadata?.lockupMetadataViewModel as Record<string, unknown> | undefined;
      const title = textContent(lockupMetadata?.title) || "فيديو نهشليات";
      const accessibility = (lockup.rendererContext as Record<string, unknown> | undefined)?.accessibilityContext as Record<string, unknown> | undefined;
      const label = typeof accessibility?.label === "string" ? accessibility.label : "";
      const duration = label.match(/(\d+\s+(?:second|seconds|minute|minutes|hour|hours))/i)?.[1] ?? "";
      seen.add(lockup.contentId);
      videos.push({ id: lockup.contentId, title, meta: duration || "من قائمة نهشليات", tag: "نهشليات" });
    }
    const renderer = record.playlistVideoRenderer as Record<string, unknown> | undefined;
    if (renderer && typeof renderer.videoId === "string" && !seen.has(renderer.videoId)) {
      const title = textContent(renderer.title);
      const length = (renderer.lengthText as { simpleText?: string } | undefined)?.simpleText ?? "";
      seen.add(renderer.videoId);
      videos.push({ id: renderer.videoId, title: title || "فيديو نهشليات", meta: length || "من قائمة نهشليات", tag: "نهشليات" });
    }
    Object.values(record).forEach(visit);
  };
  visit(data);
  return videos;
}
