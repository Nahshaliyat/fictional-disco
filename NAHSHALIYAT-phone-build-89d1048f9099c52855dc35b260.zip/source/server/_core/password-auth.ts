import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import {
  addFavorite,
  createBook,
  createCouncilMessage,
  updateCouncilMessage,
  createPasswordUser,
  createPenPost,
  createServiceRequest,
  deleteBook,
  deleteCouncilMessage,
  deleteSession,
  deletePenPost,
  getUserByEmail,
  getUserByPhone,
  getUserBySession,
  getPasswordHash,
  getPenPost,
  getLatestPenPostByUser,
  listFavorites,
  listBooks,
  listCouncilMessages,
  listMembers,
  listAllMembers,
  updateUserRole,
  listAllCouncilMessages,
  listCouncilReports,
  createAuditLog,
  listAuditLogs,
  updateUserAvatar,
  updateServiceRequestStatus,
  deleteServiceRequest,
  updatePasswordHash,
  listPenPosts,
  listServiceRequests,
  listServiceRequestsByUser,
  saveSession,
  updateLastSignedIn,
  updateBook,
  updatePenPost,
  createReminder,
  listReminders,
  reportCouncilMessage,
  blockCouncilUser,
  upsertYouTubePlaylists,
  listSyncedYouTubePlaylists,
} from "../db";
import { getSessionCookieOptions } from "./cookies";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { broadcastCouncilMessage } from "./council-ws";
import { fetchYouTubePlaylistVideos, sendServiceEmail, syncYouTubePlaylists } from "./external-services";
import { isPhoneRecentlyVerified } from "./external-auth";

export const CUSTOM_SESSION_COOKIE = "nahshaliyat_session";
// تبقى جلسة الهاتف فعالة حتى يختار العضو تسجيل الخروج، مع إمكانية إبطالها خادميًا.
const SESSION_MAX_AGE = 1000 * 60 * 60 * 24 * 3650;

function normalizeEmail(value: unknown) {
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

function normalizePhone(value: unknown) {
  return typeof value === "string" ? value.replace(/[\s()-]/g, "").trim() : "";
}

function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, stored: string) {
  const [salt, expected] = stored.split(":");
  if (!salt || !expected) return false;
  const actual = scryptSync(password, salt, 64);
  return timingSafeEqual(actual, Buffer.from(expected, "hex"));
}

function hashSession(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function tokenFromRequest(req: Request) {
  const auth = req.headers.authorization;
  if (typeof auth === "string" && auth.startsWith("Bearer ")) return auth.slice(7).trim();
  return parseCookieHeader(req.headers.cookie ?? "")[CUSTOM_SESSION_COOKIE];
}

export async function authenticateCustomRequest(req: Request) {
  const token = tokenFromRequest(req);
  return token ? getUserBySession(hashSession(token)) : undefined;
}

export async function authenticateAnyRequest(req: Request) {
  const customUser = await authenticateCustomRequest(req);
  if (customUser) return customUser;
  try {
    return await sdk.authenticateRequest(req);
  } catch {
    return undefined;
  }
}

function userResponse(user: User) {
  return {
    id: user.id,
    openId: user.openId,
    name: user.name,
    email: user.email,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    loginMethod: user.loginMethod,
    role: user.role,
    lastSignedIn: user.lastSignedIn.toISOString(),
  };
}

async function issueSession(req: Request, res: Response, user: User, rememberMe = true) {
  const token = randomBytes(32).toString("hex");
  await saveSession(hashSession(token), user.id, new Date(Date.now() + SESSION_MAX_AGE));
  res.cookie(CUSTOM_SESSION_COOKIE, token, { ...getSessionCookieOptions(req), ...(rememberMe ? { maxAge: SESSION_MAX_AGE } : {}) });
  return { sessionToken: token, user: userResponse(user) };
}

function requireFields(body: Record<string, unknown>, fields: string[]) {
  return fields.every((field) => typeof body[field] === "string" && String(body[field]).trim().length > 0);
}

function bookAssetFields(body: Record<string, unknown>) {
  const sourceUrl = typeof body.sourceUrl === "string" ? body.sourceUrl.trim() : undefined;
  const coverUrl = typeof body.coverUrl === "string" ? body.coverUrl.trim() : undefined;
  const fileKey = typeof body.fileKey === "string" ? body.fileKey.trim() : undefined;
  const mimeType = typeof body.mimeType === "string" ? body.mimeType.trim().toLowerCase() : undefined;
  const fileSize = typeof body.fileSize === "number" ? body.fileSize : undefined;
  const allowed = ["text/plain", "application/pdf", "application/epub+zip", "application/octet-stream"];
  if (sourceUrl && !/^https:\/\//i.test(sourceUrl)) throw new Error("رابط المصدر يجب أن يبدأ بـ HTTPS");
  if (coverUrl && !/^https:\/\//i.test(coverUrl)) throw new Error("رابط الغلاف يجب أن يبدأ بـ HTTPS");
  if (fileKey && (fileKey.includes("..") || fileKey.startsWith("/") || fileKey.length > 500)) throw new Error("مسار الملف غير آمن");
  if (mimeType && !allowed.includes(mimeType)) throw new Error("نوع الملف غير مسموح؛ استخدم PDF أو EPUB أو TXT");
  if (fileSize !== undefined && (!Number.isInteger(fileSize) || fileSize < 1 || fileSize > 10 * 1024 * 1024)) throw new Error("حجم الكتاب يجب ألا يتجاوز 10MB");
  return { sourceUrl, coverUrl, fileKey, mimeType, fileSize };
}

export function registerPasswordAuthRoutes(app: Express) {
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    const body = req.body as Record<string, unknown>;
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = normalizeEmail(body.email);
    const phone = normalizePhone(body.phone);
    const password = typeof body.password === "string" ? body.password : "";
    const usingPhone = Boolean(phone);
    if (!requireFields(body, ["name", "password"]) || name.length < 2 || (!email.includes("@") && (!phone.startsWith("+") || phone.replace(/\D/g, "").length < 8)) || password.length < 8) {
      res.status(400).json({ error: "أدخل الاسم والبريد أو رقم الهاتف مع فتح الخط وكلمة مرور من 8 أحرف على الأقل" });
      return;
    }
    try {
      if (usingPhone && !isPhoneRecentlyVerified(phone)) { res.status(403).json({ error: "تحقق من رقم الهاتف برمز SMS أولًا" }); return; }
      if ((email && await getUserByEmail(email)) || (usingPhone && await getUserByPhone(phone))) {
        res.status(409).json({ error: "بيانات التسجيل مسجلة مسبقًا" });
        return;
      }
      const user = await createPasswordUser({ name, email: email || undefined, phone: phone || undefined, passwordHash: hashPassword(password) });
      if (!user) throw new Error("User was not created");
      res.json(await issueSession(req, res, user, body.rememberMe !== false));
    } catch (error) {
      console.error("[Auth] Registration failed", error);
      res.status(500).json({ error: "تعذر إنشاء الحساب الآن" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    const body = req.body as Record<string, unknown>;
    const email = normalizeEmail(body.email);
    const phone = normalizePhone(body.phone);
    const password = typeof body.password === "string" ? body.password : "";
    if ((!email && !phone) || !password) {
      res.status(400).json({ error: "أدخل البريد أو رقم الهاتف وكلمة المرور" });
      return;
    }
    try {
      if (phone && !isPhoneRecentlyVerified(phone)) { res.status(403).json({ error: "تحقق من رقم الهاتف برمز SMS أولًا" }); return; }
      const user = email ? await getUserByEmail(email) : await getUserByPhone(phone);
      const passwordHash = user ? await getPasswordHash(user.id) : undefined;
      if (!user || !passwordHash || !verifyPassword(password, passwordHash)) {
        res.status(401).json({ error: "البريد أو كلمة المرور غير صحيحة" });
        return;
      }
      await updateLastSignedIn(user.id);
      const updated = { ...user, lastSignedIn: new Date() };
      res.json(await issueSession(req, res, updated, body.rememberMe !== false));
    } catch (error) {
      console.error("[Auth] Login failed", error);
      res.status(500).json({ error: "تعذر تسجيل الدخول الآن" });
    }
  });

  app.post("/api/auth/password-logout", async (req: Request, res: Response) => {
    const token = tokenFromRequest(req);
    if (token) await deleteSession(hashSession(token));
    res.clearCookie(CUSTOM_SESSION_COOKIE, getSessionCookieOptions(req));
    res.json({ success: true });
  });

  app.post("/api/favorites", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const body = req.body as Record<string, unknown>;
    if (!requireFields(body, ["videoId", "title"])) { res.status(400).json({ error: "بيانات المقطع ناقصة" }); return; }
    await addFavorite(user.id, { videoId: String(body.videoId), title: String(body.title), meta: typeof body.meta === "string" ? body.meta : undefined, tag: typeof body.tag === "string" ? body.tag : undefined });
    res.json({ success: true });
  });

  app.delete("/api/favorites/:videoId", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const { removeFavorite } = await import("../db");
    await removeFavorite(user.id, req.params.videoId);
    res.json({ success: true });
  });

  app.get("/api/favorites", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ favorites: await listFavorites(user.id) });
  });

  app.post("/api/service-requests", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const body = req.body as Record<string, unknown>;
    if (!requireFields(body, ["name", "requestType", "details", "phone", "email"])) { res.status(400).json({ error: "أكمل جميع حقول الطلب" }); return; }
    const requestNumber = `NH-${Date.now().toString(36).toUpperCase()}-${randomBytes(2).toString("hex").toUpperCase()}`;
    const request = { requestNumber, userId: user?.id, name: String(body.name).trim(), requestType: String(body.requestType).trim(), details: String(body.details).trim(), phone: String(body.phone).trim(), email: normalizeEmail(body.email) };
    await createServiceRequest(request);
    const emailResult = await sendServiceEmail({ to: "nahshaliyat@gmail.com", subject: `طلب خدمة نهشليات ${requestNumber}`, text: `رقم الطلب: ${requestNumber}\nالاسم: ${request.name}\nالنوع: ${request.requestType}\nالهاتف: ${request.phone}\nالبريد: ${request.email}\n\n${request.details}` }).catch((error) => ({ sent: false, reason: error instanceof Error ? error.message : "email_failed" }));
    res.json({ requestNumber, emailSent: emailResult.sent });
  });

  app.get("/api/service-requests/mine", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const requests = await listServiceRequestsByUser(user.id);
    res.json({ requests });
  });

  app.get("/api/admin/requests", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "هذه الصفحة للمدير فقط" }); return; }
    res.json({ requests: await listServiceRequests() });
  });

  app.delete("/api/admin/requests/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "حذف الطلبات للراعي فقط" }); return; }
    await deleteServiceRequest(Number(req.params.id));
    res.json({ success: true });
  });

  app.get("/api/admin/users", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "هذه الصفحة للراعي فقط" }); return; }
    res.json({ users: await listAllMembers() });
  });

  app.put("/api/admin/users/:id/role", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const requestedRole = (req.body as Record<string, unknown>).role;
    if (!user || user.role !== "admin") { res.status(403).json({ error: "تعديل الصلاحيات للراعي فقط" }); return; }
    if (Number(req.params.id) === user.id || (requestedRole !== "user" && requestedRole !== "admin")) { res.status(400).json({ error: "لا يمكن تغيير صلاحية الراعي الحالي" }); return; }
    await updateUserRole(Number(req.params.id), requestedRole);
    await createAuditLog({ actorId: user.id, action: "تغيير صلاحية عضو", entityType: "user", entityId: req.params.id, details: String(requestedRole) });
    res.json({ success: true });
  });

  app.get("/api/admin/content", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "محتوى الإدارة للراعي فقط" }); return; }
    res.json({ books: await listBooks(), pens: await listPenPosts(), messages: await listAllCouncilMessages(), reports: await listCouncilReports() });
  });

  app.get("/api/youtube/playlists", async (req: Request, res: Response) => {
    if (!(await authenticateAnyRequest(req))) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ playlists: await listSyncedYouTubePlaylists(), liveSyncConfigured: Boolean(process.env.NAHSHALIYAT_YOUTUBE_API_KEY) });
  });

  app.get("/api/youtube/playlists/:playlistId/videos", async (req: Request, res: Response) => {
    if (!(await authenticateAnyRequest(req))) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    try { res.json({ videos: await fetchYouTubePlaylistVideos(req.params.playlistId) }); }
    catch (error) { res.status(503).json({ error: error instanceof Error ? error.message : "تعذرت قراءة فيديوهات القائمة" }); }
  });

  app.post("/api/admin/youtube/sync", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "المزامنة للراعي فقط" }); return; }
    try { const playlists = await syncYouTubePlaylists(); await upsertYouTubePlaylists(playlists); res.json({ playlists, syncedAt: new Date().toISOString() }); }
    catch (error) { res.status(503).json({ error: error instanceof Error ? error.message : "تعذرت مزامنة YouTube" }); }
  });

  app.get("/api/books", async (req: Request, res: Response) => {
    if (!(await authenticateAnyRequest(req))) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ books: await listBooks() });
  });

  app.post("/api/books", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "رفع الكتب للراعي فقط" }); return; }
    const body = req.body as Record<string, unknown>;
    if (!requireFields(body, ["title", "content"]) || String(body.content).length > 10 * 1024 * 1024) { res.status(400).json({ error: "أدخل عنوان الكتاب ومحتواه بحد أقصى 10MB" }); return; }
    try { const asset = bookAssetFields(body); const book = await createBook({ title: String(body.title).trim(), author: typeof body.author === "string" ? String(body.author).trim() : undefined, content: String(body.content), ...asset, uploadedBy: user.id }); res.json({ book }); }
    catch (error) { res.status(400).json({ error: error instanceof Error ? error.message : "بيانات الملف غير صالحة" }); return; }
  });

  app.put("/api/books/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "تعديل الكتب للراعي فقط" }); return; }
    const body = req.body as Record<string, unknown>;
    if (!requireFields(body, ["title", "content"]) || String(body.content).length > 10 * 1024 * 1024) { res.status(400).json({ error: "أدخل عنوان الكتاب ومحتواه بحد أقصى 10MB" }); return; }
    try { const asset = bookAssetFields(body); await updateBook(Number(req.params.id), { title: String(body.title).trim(), author: typeof body.author === "string" ? String(body.author).trim() : undefined, content: String(body.content), ...asset }); res.json({ success: true }); }
    catch (error) { res.status(400).json({ error: error instanceof Error ? error.message : "بيانات الملف غير صالحة" }); }
  });

  app.delete("/api/books/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "حذف الكتب للراعي فقط" }); return; }
    await deleteBook(Number(req.params.id));
    res.json({ success: true });
  });

  app.get("/api/pens", async (req: Request, res: Response) => {
    if (!(await authenticateAnyRequest(req))) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ posts: await listPenPosts() });
  });

  app.post("/api/pens", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const body = req.body as Record<string, unknown>;
    const text = typeof body.body === "string" ? body.body.trim() : "";
    if (!text || text.length > 300) { res.status(400).json({ error: "المشاركة مطلوبة وبحد أقصى 300 حرف" }); return; }
    const latest = await getLatestPenPostByUser(user.id);
    if (latest && latest.createdAt.toDateString() === new Date().toDateString()) { res.status(409).json({ error: "يمكنك نشر مشاركة واحدة فقط كل يوم" }); return; }
    await createPenPost(user.id, text);
    res.json({ success: true });
  });

  app.put("/api/pens/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const post = await getPenPost(Number(req.params.id));
    const body = req.body as Record<string, unknown>;
    const text = typeof body.body === "string" ? body.body.trim() : "";
    const withinWindow = post?.createdAt && Date.now() - post.createdAt.getTime() <= 15 * 60 * 1000;
    if (!post || !text || text.length > 300) { res.status(400).json({ error: "بيانات المشاركة غير صحيحة" }); return; }
    if (user.role !== "admin" && (post.userId !== user.id || post.editCount > 0 || !withinWindow)) { res.status(403).json({ error: "يسمح بتعديل المشاركة مرة واحدة خلال أول 15 دقيقة" }); return; }
    await updatePenPost(post.id, text);
    res.json({ success: true });
  });

  app.delete("/api/pens/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "حذف المشاركات للراعي فقط" }); return; }
    await deletePenPost(Number(req.params.id));
    res.json({ success: true });
  });

  app.get("/api/council/members", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ members: await listMembers(user.id) });
  });

  app.get("/api/council/messages", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ messages: await listCouncilMessages(user.id) });
  });

  app.post("/api/council/messages", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const body = req.body as Record<string, unknown>;
    const text = typeof body.body === "string" ? body.body.trim() : "";
    if (!text || text.length > 1000) { res.status(400).json({ error: "اكتب رسالة بين 1 و1000 حرف" }); return; }
    await createCouncilMessage({ senderId: user.id, recipientId: body.recipientId ? Number(body.recipientId) : undefined, body: text });
    broadcastCouncilMessage();
    res.json({ success: true });
  });

  app.delete("/api/council/messages/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "مراقبة وحذف رسائل المجلس للراعي فقط" }); return; }
    await deleteCouncilMessage(Number(req.params.id));
    res.json({ success: true });
  });

  app.put("/api/council/messages/:id", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const text = typeof (req.body as Record<string, unknown>).body === "string" ? String((req.body as Record<string, unknown>).body).trim() : "";
    if (!user || user.role !== "admin") { res.status(403).json({ error: "تعديل رسائل المجلس للراعي فقط" }); return; }
    if (!text || text.length > 1000) { res.status(400).json({ error: "اكتب رسالة بين 1 و1000 حرف" }); return; }
    await updateCouncilMessage(Number(req.params.id), text);
    broadcastCouncilMessage();
    res.json({ success: true });
  });

  app.get("/api/reminders", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    res.json({ reminders: await listReminders(user.id) });
  });

  app.post("/api/reminders", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const body = req.body as Record<string, unknown>;
    const title = typeof body.title === "string" ? body.title.trim() : "";
    const remindAt = typeof body.remindAt === "string" ? new Date(body.remindAt) : new Date("invalid");
    if (!title || title.length > 180 || Number.isNaN(remindAt.getTime())) { res.status(400).json({ error: "بيانات التذكير غير صحيحة" }); return; }
    res.json({ reminder: await createReminder({ userId: user.id, title, remindAt }) });
  });

  app.post("/api/council/reports", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const body = req.body as Record<string, unknown>;
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    if (!Number(body.messageId) || typeof body.reason !== "string" || !body.reason.trim()) { res.status(400).json({ error: "سبب التبليغ مطلوب" }); return; }
    await reportCouncilMessage({ messageId: Number(body.messageId), reporterId: user.id, reason: body.reason.trim().slice(0, 300) });
    res.json({ success: true });
  });

  app.post("/api/council/blocks", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const body = req.body as Record<string, unknown>;
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    if (!Number(body.userId) || Number(body.userId) === user.id) { res.status(400).json({ error: "العضو غير صالح" }); return; }
    await blockCouncilUser({ userId: Number(body.userId), blockedBy: user.id });
    res.json({ success: true });
  });

  app.get("/api/admin/audit-logs", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    if (!user || user.role !== "admin") { res.status(403).json({ error: "السجل للراعي فقط" }); return; }
    res.json({ logs: await listAuditLogs() });
  });

  app.put("/api/profile/avatar", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const avatarUrl = (req.body as Record<string, unknown>).avatarUrl;
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    if (typeof avatarUrl !== "string" || !avatarUrl.startsWith("data:image/") || avatarUrl.length > 2_000_000) { res.status(400).json({ error: "الصورة غير صالحة أو كبيرة جدًا" }); return; }
    await updateUserAvatar(user.id, avatarUrl);
    res.json({ success: true, avatarUrl });
  });

  app.put("/api/admin/requests/:id/status", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const status = (req.body as Record<string, unknown>).status;
    if (!user || user.role !== "admin") { res.status(403).json({ error: "تحديث الطلبات للراعي فقط" }); return; }
    if (!["new", "reviewing", "contacted", "completed"].includes(String(status))) { res.status(400).json({ error: "حالة الطلب غير صحيحة" }); return; }
    await updateServiceRequestStatus(Number(req.params.id), status as "new" | "reviewing" | "contacted" | "completed");
    await createAuditLog({ actorId: user.id, action: "تحديث حالة طلب", entityType: "service_request", entityId: req.params.id, details: String(status) });
    res.json({ success: true });
  });

  app.put("/api/profile/password", async (req: Request, res: Response) => {
    const user = await authenticateAnyRequest(req);
    const body = req.body as Record<string, unknown>;
    const currentPassword = typeof body.currentPassword === "string" ? body.currentPassword : "";
    const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
    if (!user) { res.status(401).json({ error: "يلزم تسجيل الدخول" }); return; }
    const existing = await getPasswordHash(user.id);
    if (!existing || !verifyPassword(currentPassword, existing)) { res.status(401).json({ error: "كلمة المرور الحالية غير صحيحة" }); return; }
    if (newPassword.length < 8) { res.status(400).json({ error: "كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل" }); return; }
    await updatePasswordHash(user.id, hashPassword(newPassword));
    res.json({ success: true });
  });
}
