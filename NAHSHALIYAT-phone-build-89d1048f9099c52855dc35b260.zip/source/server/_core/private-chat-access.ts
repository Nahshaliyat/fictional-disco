export function canReadAskMeHistory(viewerId: number, ownerId: number, sponsorId?: number): boolean {
  return viewerId === ownerId || (sponsorId !== undefined && viewerId === sponsorId);
}

export function canReadSponsorThread(viewerId: number, memberId: number, sponsorId?: number): boolean {
  return viewerId === memberId || (sponsorId !== undefined && viewerId === sponsorId);
}

export function isValidConversationMember(memberId: number, sponsorId: number): boolean {
  return Number.isSafeInteger(memberId) && memberId > 0 && memberId !== sponsorId;
}
