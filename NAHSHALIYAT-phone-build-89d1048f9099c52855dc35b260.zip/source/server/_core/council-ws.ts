import crypto from "node:crypto";
import type { IncomingMessage, Server } from "node:http";
import { WebSocketServer, type WebSocket } from "ws";
import { getUserBySession } from "../db";

const clients = new Map<WebSocket, number>();

function hashSession(token: string) { return crypto.createHash("sha256").update(token).digest("hex"); }
function tokenFromRequest(req: IncomingMessage) { const url = new URL(req.url ?? "/", "http://localhost"); return url.searchParams.get("token") || req.headers.authorization?.replace(/^Bearer\s+/i, ""); }

export function broadcastCouncilMessage(payload: Record<string, unknown> = { type: "council.invalidate" }) {
  const encoded = JSON.stringify(payload);
  for (const socket of clients.keys()) if (socket.readyState === socket.OPEN) socket.send(encoded);
}

export function broadcastCouncilToUsers(userIds: number[]) {
  const encoded = JSON.stringify({ type: "council.sponsor.invalidate" });
  for (const [socket, id] of clients) {
    if (userIds.includes(id) && socket.readyState === socket.OPEN) socket.send(encoded);
  }
}

export function registerCouncilWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws/council" });
  wss.on("connection", async (socket, req) => {
    const token = tokenFromRequest(req);
    const user = token ? await getUserBySession(hashSession(token)) : undefined;
    if (!user) { socket.close(1008, "Authentication required"); return; }
    clients.set(socket, user.id);
    socket.send(JSON.stringify({ type: "council.connected" }));
    socket.on("close", () => clients.delete(socket));
    socket.on("error", () => clients.delete(socket));
  });
  return wss;
}
