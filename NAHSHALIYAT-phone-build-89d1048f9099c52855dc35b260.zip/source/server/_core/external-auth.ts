import crypto from "node:crypto";
import type { Express, Request, Response } from "express";
import { createPhoneVerification, getLatestPhoneVerification, consumePhoneVerification, incrementPhoneVerificationAttempts } from "../db";
import { createVerificationCode, externalServiceStatus, getOAuthProviderConfig, hashVerificationCode, sendSmsCode, type OAuthProvider } from "./external-services";

const recentlyVerifiedPhones = new Map<string, number>();
export function isPhoneRecentlyVerified(phone: string) {
  const expiry = recentlyVerifiedPhones.get(phone) ?? 0;
  if (expiry < Date.now()) { recentlyVerifiedPhones.delete(phone); return false; }
  return true;
}

function normalizePhone(value: unknown) { return typeof value === "string" ? value.replace(/[\s()-]/g, "").trim() : ""; }

export function registerExternalAuthRoutes(app: Express) {
  app.get("/api/auth/providers", (_req, res) => res.json({ providers: externalServiceStatus() }));

  app.post("/api/auth/phone/request-code", async (req: Request, res: Response) => {
    const phone = normalizePhone((req.body as Record<string, unknown>).phone);
    if (!/^\+[1-9]\d{7,14}$/.test(phone)) { res.status(400).json({ error: "أدخل رقم الهاتف مع رمز فتح الخط بصيغة دولية" }); return; }
    try {
      const code = createVerificationCode();
      await sendSmsCode(phone, code);
      await createPhoneVerification(phone, hashVerificationCode(code), new Date(Date.now() + 5 * 60 * 1000));
      res.json({ success: true, expiresInSeconds: 300 });
    } catch (error) { res.status(503).json({ error: error instanceof Error ? error.message : "خدمة SMS غير متاحة" }); }
  });

  app.post("/api/auth/phone/verify-code", async (req: Request, res: Response) => {
    const body = req.body as Record<string, unknown>;
    const phone = normalizePhone(body.phone);
    const code = typeof body.code === "string" ? body.code.trim() : "";
    if (!phone || !/^\d{6}$/.test(code)) { res.status(400).json({ error: "أدخل رقم الهاتف والرمز المكون من 6 أرقام" }); return; }
    const record = await getLatestPhoneVerification(phone);
    if (!record || record.expiresAt.getTime() < Date.now() || record.attempts >= 5) { res.status(400).json({ error: "رمز التحقق منتهي أو غير صالح" }); return; }
    if (hashVerificationCode(code) !== record.codeHash) { await incrementPhoneVerificationAttempts(record.id); res.status(400).json({ error: "رمز التحقق غير صحيح" }); return; }
    await consumePhoneVerification(record.id);
    recentlyVerifiedPhones.set(phone, Date.now() + 10 * 60 * 1000);
    res.json({ verified: true, phone });
  });

  app.get("/api/auth/oauth/:provider/start", (req: Request, res: Response) => {
    const provider = req.params.provider as OAuthProvider;
    if (!["google", "microsoft", "facebook"].includes(provider)) { res.status(404).json({ error: "مزود غير معروف" }); return; }
    const config = getOAuthProviderConfig(provider);
    if (!config.clientId) { res.status(503).json({ error: `تسجيل الدخول عبر ${provider} غير مهيأ بعد` }); return; }
    const origin = typeof req.query.origin === "string" ? req.query.origin : `${req.protocol}://${req.get("host")}`;
    const redirectUri = `${origin}/api/auth/oauth/${provider}/callback`;
    const state = Buffer.from(JSON.stringify({ provider, origin, nonce: crypto.randomUUID() })).toString("base64url");
    const url = new URL(config.authorizeUrl);
    url.searchParams.set("client_id", config.clientId);
    url.searchParams.set("redirect_uri", redirectUri);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", config.scope);
    url.searchParams.set("state", state);
    res.json({ url: url.toString() });
  });

  app.get("/api/auth/oauth/:provider/callback", (_req, res) => res.status(501).send("OAuth callback exchange is pending provider credentials and callback verification configuration."));
}
