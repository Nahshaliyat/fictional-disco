import { and, desc, eq, isNull, notInArray, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  authSessions,
  books,
  councilMessages,
  favorites,
  InsertUser,
  passwordCredentials,
  penPosts,
  serviceRequests,
  reminders,
  phoneVerifications,
  councilReports,
  councilBlocks,
  youtubePlaylists,
  users,
  auditLogs,
  askMeMessages,
  sponsorMessages,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch {
      console.warn("[Database] Failed to connect");
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "phone", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  for (const field of textFields) {
    const value = user[field];
    if (value !== undefined) {
      values[field] = value ?? null;
      updateSet[field] = value ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId || user.email?.toLowerCase() === "nahshaliyat@gmail.com") {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email.toLowerCase())).limit(1);
  return result[0];
}

export async function getUserByPhone(phone: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
  return result[0];
}

export async function createPasswordUser(input: { name: string; email?: string; phone?: string; passwordHash: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const email = input.email?.toLowerCase() || null;
  const phone = input.phone || null;
  const role = email === "nahshaliyat@gmail.com" ? "admin" : "user";
  const openId = email ? `email:${email}` : `phone:${phone}`;
  await db.insert(users).values({
    openId,
    name: input.name,
    email,
    phone,
    loginMethod: phone ? "phone" : "email",
    role,
    lastSignedIn: new Date(),
  });
  const user = await getUserByOpenId(openId);
  if (!user) return undefined;
  await db.insert(passwordCredentials).values({ userId: user.id, passwordHash: input.passwordHash });
  return user;
}

export async function getPasswordHash(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select({ passwordHash: passwordCredentials.passwordHash })
    .from(passwordCredentials)
    .where(eq(passwordCredentials.userId, userId))
    .limit(1);
  return result[0]?.passwordHash;
}

export async function updateLastSignedIn(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, userId));
}

export async function saveSession(tokenHash: string, userId: number, expiresAt: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(authSessions).values({ tokenHash, userId, expiresAt });
}

export async function getUserBySession(tokenHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select({ user: users, session: authSessions })
    .from(authSessions)
    .innerJoin(users, eq(authSessions.userId, users.id))
    .where(eq(authSessions.tokenHash, tokenHash))
    .limit(1);
  const row = result[0];
  if (!row || row.session.expiresAt.getTime() <= Date.now()) return undefined;
  return row.user;
}

export async function deleteSession(tokenHash: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(authSessions).where(eq(authSessions.tokenHash, tokenHash));
}

export async function addFavorite(userId: number, favorite: { videoId: string; title: string; meta?: string; tag?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(favorites).values({ userId, ...favorite }).onDuplicateKeyUpdate({ set: { title: favorite.title, meta: favorite.meta, tag: favorite.tag } });
}

export async function removeFavorite(userId: number, videoId: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(favorites).where(and(eq(favorites.userId, userId), eq(favorites.videoId, videoId)));
}

export async function listFavorites(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(favorites).where(eq(favorites.userId, userId)).orderBy(desc(favorites.createdAt));
}

export async function createServiceRequest(input: Omit<typeof serviceRequests.$inferInsert, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(serviceRequests).values(input);
}

export async function listServiceRequests() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(serviceRequests).orderBy(desc(serviceRequests.createdAt));
}

export async function listServiceRequestsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(serviceRequests).where(eq(serviceRequests.userId, userId)).orderBy(desc(serviceRequests.createdAt));
}

export async function listBooks() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(books).orderBy(desc(books.createdAt));
}

export async function upsertYouTubePlaylists(items: Array<{ playlistId: string; title: string; thumbnailUrl?: string; itemCount: number }>) {
  const db = await getDb();
  if (!db || !items.length) return;
  for (const item of items) await db.insert(youtubePlaylists).values(item).onDuplicateKeyUpdate({ set: { title: item.title, thumbnailUrl: item.thumbnailUrl, itemCount: item.itemCount, updatedAt: new Date() } });
}

export async function listSyncedYouTubePlaylists() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(youtubePlaylists).orderBy(desc(youtubePlaylists.updatedAt));
}

export async function createReminder(input: { userId: number; title: string; remindAt: Date }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(reminders).values(input);
  return (await db.select().from(reminders).where(eq(reminders.userId, input.userId)).orderBy(desc(reminders.id)).limit(1))[0];
}

export async function listReminders(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(reminders).where(eq(reminders.userId, userId)).orderBy(reminders.remindAt);
}

export async function createPhoneVerification(phone: string, codeHash: string, expiresAt: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(phoneVerifications).values({ phone, codeHash, expiresAt });
}

export async function getLatestPhoneVerification(phone: string) {
  const db = await getDb();
  if (!db) return undefined;
  return (await db.select().from(phoneVerifications).where(and(eq(phoneVerifications.phone, phone), isNull(phoneVerifications.consumedAt))).orderBy(desc(phoneVerifications.id)).limit(1))[0];
}

export async function consumePhoneVerification(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(phoneVerifications).set({ consumedAt: new Date() }).where(eq(phoneVerifications.id, id));
}

export async function incrementPhoneVerificationAttempts(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(phoneVerifications).set({ attempts: sql`${phoneVerifications.attempts} + 1` }).where(eq(phoneVerifications.id, id));
}

export async function reportCouncilMessage(input: { messageId: number; reporterId: number; reason: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(councilReports).values(input);
}

export async function blockCouncilUser(input: { userId: number; blockedBy: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(councilBlocks).values(input);
}

export async function createBook(input: { title: string; author?: string; content: string; sourceUrl?: string; coverUrl?: string; fileKey?: string; mimeType?: string; fileSize?: number; uploadedBy: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(books).values(input);
  const result = await db.select().from(books).where(eq(books.uploadedBy, input.uploadedBy)).orderBy(desc(books.id)).limit(1);
  return result[0];
}

export async function updateBook(id: number, input: { title: string; author?: string; content: string; sourceUrl?: string; coverUrl?: string; fileKey?: string; mimeType?: string; fileSize?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(books).set(input).where(eq(books.id, id));
}

export async function deleteBook(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(books).where(eq(books.id, id));
}

export async function listPenPosts() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ post: penPosts, userName: users.name, userEmail: users.email })
    .from(penPosts).innerJoin(users, eq(penPosts.userId, users.id))
    .where(isNull(penPosts.deletedAt)).orderBy(desc(penPosts.createdAt));
}

export async function createPenPost(userId: number, body: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(penPosts).values({ userId, body });
}

export async function getLatestPenPostByUser(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(penPosts).where(eq(penPosts.userId, userId)).orderBy(desc(penPosts.createdAt)).limit(1);
  return result[0];
}

export async function updatePenPost(id: number, body: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(penPosts).set({ body, editCount: 1, lastEditedAt: new Date() }).where(eq(penPosts.id, id));
}

export async function deletePenPost(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(penPosts).set({ deletedAt: new Date() }).where(eq(penPosts.id, id));
}

export async function getPenPost(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(penPosts).where(eq(penPosts.id, id)).limit(1);
  return result[0];
}

export async function listCouncilMessages(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const blocked = await db.select({ userId: councilBlocks.userId }).from(councilBlocks).where(eq(councilBlocks.blockedBy, userId));
  const blockedIds = blocked.map((item) => item.userId);
  return db.select({ message: councilMessages, userName: users.name, userEmail: users.email })
    .from(councilMessages).innerJoin(users, eq(councilMessages.senderId, users.id))
    .where(and(isNull(councilMessages.deletedAt), blockedIds.length ? notInArray(councilMessages.senderId, blockedIds) : undefined, or(isNull(councilMessages.recipientId), eq(councilMessages.senderId, userId), eq(councilMessages.recipientId, userId)))).orderBy(desc(councilMessages.createdAt));
}

export async function createCouncilMessage(input: { senderId: number; recipientId?: number; body: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(councilMessages).values(input);
}

export async function deleteCouncilMessage(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(councilMessages).set({ deletedAt: new Date() }).where(eq(councilMessages.id, id));
}

export async function updateCouncilMessage(id: number, body: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(councilMessages).set({ body, updatedAt: new Date() }).where(eq(councilMessages.id, id));
}

export async function listMembers(currentUserId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: users.id, name: users.name, email: users.email, role: users.role })
    .from(users).where(sql`${users.id} <> ${currentUserId}`).orderBy(users.name);
}

export async function listAllMembers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: users.id, name: users.name, email: users.email, phone: users.phone, role: users.role, loginMethod: users.loginMethod, createdAt: users.createdAt, lastSignedIn: users.lastSignedIn })
    .from(users).orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "admin") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function listAllCouncilMessages() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ message: councilMessages, userName: users.name, userEmail: users.email })
    .from(councilMessages).innerJoin(users, eq(councilMessages.senderId, users.id))
    .orderBy(desc(councilMessages.createdAt));
}

export async function listCouncilReports() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ report: councilReports, reporterName: users.name, reporterEmail: users.email })
    .from(councilReports).innerJoin(users, eq(councilReports.reporterId, users.id))
    .orderBy(desc(councilReports.createdAt));
}


export async function updateUserAvatar(userId: number, avatarUrl: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(users).set({ avatarUrl }).where(eq(users.id, userId));
}

export async function createAuditLog(input: { actorId: number; action: string; entityType: string; entityId?: string; details?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values(input);
}

export async function listAuditLogs() {
  const db = await getDb();
  if (!db) return [];
  return db.select({ log: auditLogs, actorName: users.name, actorEmail: users.email })
    .from(auditLogs).innerJoin(users, eq(auditLogs.actorId, users.id)).orderBy(desc(auditLogs.createdAt)).limit(100);
}

export async function updateServiceRequestStatus(id: number, status: "new" | "reviewing" | "contacted" | "completed") {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(serviceRequests).set({ status }).where(eq(serviceRequests.id, id));
}

export async function deleteServiceRequest(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(serviceRequests).where(eq(serviceRequests.id, id));
}


export async function updatePasswordHash(userId: number, passwordHash: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(passwordCredentials).set({ passwordHash, updatedAt: new Date() }).where(eq(passwordCredentials.userId, userId));
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return (await db.select().from(users).where(eq(users.id, id)).limit(1))[0];
}

export async function getSponsorAccount() {
  const sponsor = await getUserByEmail("nahshaliyat@gmail.com");
  return sponsor?.role === "admin" ? sponsor : undefined;
}

export async function createAskMeMessage(input: { userId: number; question: string; answer: string; inScope: boolean }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(askMeMessages).values({ ...input, inScope: input.inScope ? 1 : 0 });
}

export async function listAskMeMessages(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(askMeMessages).where(eq(askMeMessages.userId, userId)).orderBy(askMeMessages.id);
}

export async function listAskMeThreads() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ memberId: askMeMessages.userId, memberName: users.name, lastId: sql<number>`max(${askMeMessages.id})`.mapWith(Number) })
    .from(askMeMessages)
    .innerJoin(users, eq(askMeMessages.userId, users.id))
    .groupBy(askMeMessages.userId, users.name)
    .orderBy(desc(sql`max(${askMeMessages.id})`));
}

export async function createSponsorMessage(input: { memberId: number; senderId: number; body: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(sponsorMessages).values(input);
}

export async function listSponsorMessages(memberId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(sponsorMessages).where(eq(sponsorMessages.memberId, memberId)).orderBy(sponsorMessages.id);
}

export async function listSponsorThreads() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select({ memberId: sponsorMessages.memberId, memberName: users.name, lastId: sql<number>`max(${sponsorMessages.id})`.mapWith(Number) })
    .from(sponsorMessages)
    .innerJoin(users, eq(sponsorMessages.memberId, users.id))
    .groupBy(sponsorMessages.memberId, users.name)
    .orderBy(desc(sql`max(${sponsorMessages.id})`));
}
