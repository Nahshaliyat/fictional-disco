import { index, int, longtext, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  avatarUrl: varchar("avatarUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const passwordCredentials = mysqlTable("password_credentials", {
  userId: int("userId").primaryKey(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const authSessions = mysqlTable("auth_sessions", {
  tokenHash: varchar("tokenHash", { length: 128 }).primaryKey(),
  userId: int("userId").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const favorites = mysqlTable("favorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  videoId: varchar("videoId", { length: 32 }).notNull(),
  title: text("title").notNull(),
  meta: varchar("meta", { length: 128 }),
  tag: varchar("tag", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userVideo: uniqueIndex("favorites_user_video_unique").on(table.userId, table.videoId),
}));

export const serviceRequests = mysqlTable("service_requests", {
  id: int("id").autoincrement().primaryKey(),
  requestNumber: varchar("requestNumber", { length: 32 }).notNull().unique(),
  userId: int("userId"),
  name: varchar("name", { length: 160 }).notNull(),
  requestType: varchar("requestType", { length: 160 }).notNull(),
  details: text("details").notNull(),
  phone: varchar("phone", { length: 64 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  status: mysqlEnum("status", ["new", "reviewing", "contacted", "completed"]).default("new").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const books = mysqlTable("books", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  author: varchar("author", { length: 160 }),
  category: varchar("category", { length: 120 }),
  content: longtext("content").notNull(),
  sourceUrl: varchar("sourceUrl", { length: 500 }),
  coverUrl: varchar("coverUrl", { length: 500 }),
  fileKey: varchar("fileKey", { length: 500 }),
  mimeType: varchar("mimeType", { length: 120 }),
  fileSize: int("fileSize"),
  uploadedBy: int("uploadedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const penPosts = mysqlTable("pen_posts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  body: varchar("body", { length: 300 }).notNull(),
  editCount: int("editCount").default(0).notNull(),
  lastEditedAt: timestamp("lastEditedAt"),
  deletedAt: timestamp("deletedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const councilMessages = mysqlTable("council_messages", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  recipientId: int("recipientId"),
  body: varchar("body", { length: 1000 }).notNull(),
  deletedAt: timestamp("deletedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const askMeMessages = mysqlTable("ask_me_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  question: varchar("question", { length: 500 }).notNull(),
  answer: text("answer").notNull(),
  inScope: int("inScope").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ userHistory: index("ask_me_user_history_idx").on(table.userId, table.id) }));

export const sponsorMessages = mysqlTable("sponsor_messages", {
  id: int("id").autoincrement().primaryKey(),
  memberId: int("memberId").notNull(),
  senderId: int("senderId").notNull(),
  body: varchar("body", { length: 1000 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ memberHistory: index("sponsor_member_history_idx").on(table.memberId, table.id) }));

export const reminders = mysqlTable("reminders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  remindAt: timestamp("remindAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const phoneVerifications = mysqlTable("phone_verifications", {
  id: int("id").autoincrement().primaryKey(),
  phone: varchar("phone", { length: 32 }).notNull(),
  codeHash: varchar("codeHash", { length: 128 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  attempts: int("attempts").default(0).notNull(),
  consumedAt: timestamp("consumedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const councilReports = mysqlTable("council_reports", {
  id: int("id").autoincrement().primaryKey(),
  messageId: int("messageId").notNull(),
  reporterId: int("reporterId").notNull(),
  reason: varchar("reason", { length: 300 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const councilBlocks = mysqlTable("council_blocks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  blockedBy: int("blockedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const youtubePlaylists = mysqlTable("youtube_playlists", {
  id: int("id").autoincrement().primaryKey(),
  playlistId: varchar("playlistId", { length: 64 }).notNull().unique(),
  title: varchar("title", { length: 240 }).notNull(),
  thumbnailUrl: varchar("thumbnailUrl", { length: 500 }),
  itemCount: int("itemCount").default(0).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  actorId: int("actorId").notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  entityType: varchar("entityType", { length: 80 }).notNull(),
  entityId: varchar("entityId", { length: 80 }),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Favorite = typeof favorites.$inferSelect;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type Book = typeof books.$inferSelect;
export type PenPost = typeof penPosts.$inferSelect;
export type CouncilMessage = typeof councilMessages.$inferSelect;
export type AskMeMessage = typeof askMeMessages.$inferSelect;
export type SponsorMessage = typeof sponsorMessages.$inferSelect;
export type Reminder = typeof reminders.$inferSelect;
export type PhoneVerification = typeof phoneVerifications.$inferSelect;
