CREATE TABLE `council_blocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`blockedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `council_blocks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `council_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`messageId` int NOT NULL,
	`reporterId` int NOT NULL,
	`reason` varchar(300) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `council_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `phone_verifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phone` varchar(32) NOT NULL,
	`codeHash` varchar(128) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`attempts` int NOT NULL DEFAULT 0,
	`consumedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `phone_verifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reminders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`remindAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reminders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `youtube_playlists` (
	`id` int AUTO_INCREMENT NOT NULL,
	`playlistId` varchar(64) NOT NULL,
	`title` varchar(240) NOT NULL,
	`thumbnailUrl` varchar(500),
	`itemCount` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `youtube_playlists_id` PRIMARY KEY(`id`),
	CONSTRAINT `youtube_playlists_playlistId_unique` UNIQUE(`playlistId`)
);
--> statement-breakpoint
ALTER TABLE `books` ADD `coverUrl` varchar(500);--> statement-breakpoint
ALTER TABLE `books` ADD `fileKey` varchar(500);--> statement-breakpoint
ALTER TABLE `books` ADD `mimeType` varchar(120);--> statement-breakpoint
ALTER TABLE `books` ADD `fileSize` int;