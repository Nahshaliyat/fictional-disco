CREATE TABLE `ask_me_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`question` varchar(500) NOT NULL,
	`answer` text NOT NULL,
	`inScope` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ask_me_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sponsor_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`memberId` int NOT NULL,
	`senderId` int NOT NULL,
	`body` varchar(1000) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `sponsor_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `ask_me_user_history_idx` ON `ask_me_messages` (`userId`,`id`);--> statement-breakpoint
CREATE INDEX `sponsor_member_history_idx` ON `sponsor_messages` (`memberId`,`id`);