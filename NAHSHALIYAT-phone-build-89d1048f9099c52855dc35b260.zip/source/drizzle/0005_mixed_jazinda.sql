CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorId` int NOT NULL,
	`action` varchar(120) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` varchar(80),
	`details` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `books` ADD `category` varchar(120);--> statement-breakpoint
ALTER TABLE `service_requests` ADD `status` enum('new','reviewing','contacted','completed') DEFAULT 'new' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` varchar(500);