# الملفات المطلوبة

| الملف أو المجلد | الاستخدام |
|---|---|
| `source/` | المشروع الكامل |
| `source/.github/workflows/android-apk.yml` | البناء الآلي من الهاتف |
| `source/app.config.ts` | اسم التطبيق ومعرّف Android |
| `source/package.json` | الاعتمادات والأوامر |
| `source/pnpm-lock.yaml` | تثبيت نسخ الاعتمادات |
| `source/assets/` | الشعار والأصول |
| `source/app/` | شاشات التطبيق |
| `source/server/` | الخادم وواجهات API |
